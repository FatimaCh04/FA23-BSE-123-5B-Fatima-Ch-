<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <p>{!! $data !!}</p>
</body>

</html>