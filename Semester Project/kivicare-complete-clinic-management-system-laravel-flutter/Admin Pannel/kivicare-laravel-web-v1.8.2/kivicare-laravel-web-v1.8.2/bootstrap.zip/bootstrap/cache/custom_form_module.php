<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomForm\\Providers\\CustomFormServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomForm\\Providers\\CustomFormServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);