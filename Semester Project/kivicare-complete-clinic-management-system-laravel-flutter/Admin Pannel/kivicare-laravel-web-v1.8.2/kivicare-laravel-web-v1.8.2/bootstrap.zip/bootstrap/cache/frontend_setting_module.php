<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FrontendSetting\\Providers\\FrontendSettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FrontendSetting\\Providers\\FrontendSettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);