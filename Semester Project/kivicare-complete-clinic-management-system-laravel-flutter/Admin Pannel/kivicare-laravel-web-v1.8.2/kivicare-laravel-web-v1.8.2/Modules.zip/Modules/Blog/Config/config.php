<?php

return [
    'name' => 'Blog',
];
