<?php

return [
    'name' => 'Commission',
];
