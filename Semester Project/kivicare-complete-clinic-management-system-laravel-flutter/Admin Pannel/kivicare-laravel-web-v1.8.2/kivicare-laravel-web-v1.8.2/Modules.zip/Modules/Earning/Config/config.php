<?php

return [
    'name' => 'Earning',
];
