<?php

return [
    'name' => 'Clinic',
];
