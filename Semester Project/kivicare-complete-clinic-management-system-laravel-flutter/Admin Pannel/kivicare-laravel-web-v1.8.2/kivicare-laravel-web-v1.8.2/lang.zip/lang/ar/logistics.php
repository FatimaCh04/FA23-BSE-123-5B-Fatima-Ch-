<?php

return [
    'title' => 'اللوجستيات',

];
