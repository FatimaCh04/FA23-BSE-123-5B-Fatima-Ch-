<?php

return [
    'title' => 'الضريبة',
];
