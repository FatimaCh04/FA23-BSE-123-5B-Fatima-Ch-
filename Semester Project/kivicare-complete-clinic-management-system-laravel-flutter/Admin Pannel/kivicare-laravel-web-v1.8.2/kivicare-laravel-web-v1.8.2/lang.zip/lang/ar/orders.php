<?php

return [
    'title' => 'الطلبات',
];
