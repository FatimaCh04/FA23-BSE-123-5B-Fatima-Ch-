<?php

return [
    'title' => 'وسم',
];
