<?php

return [
    'title' => 'الموقع',

];
