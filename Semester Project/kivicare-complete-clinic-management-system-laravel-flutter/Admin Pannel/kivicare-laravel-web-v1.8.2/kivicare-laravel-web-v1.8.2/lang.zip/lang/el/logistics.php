<?php

return [
    'title' => 'Λογιστικά',
];
