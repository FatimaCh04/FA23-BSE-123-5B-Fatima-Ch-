<?php

return [
    'title' => 'Υποκατηγορίες',

];
