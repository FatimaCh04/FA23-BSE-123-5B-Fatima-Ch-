<?php

return [
    'title' => 'Ετικέτα',
];
