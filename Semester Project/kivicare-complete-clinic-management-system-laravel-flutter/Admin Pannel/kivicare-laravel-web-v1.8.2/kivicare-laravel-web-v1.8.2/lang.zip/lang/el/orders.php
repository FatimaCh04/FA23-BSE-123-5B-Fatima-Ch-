<?php

return [
    'title' => 'Σειρά',
];
