<?php

return [
    'title' => 'Τοποθεσία',

];
