<?php

return [
    'title' => 'Φόρος',
];
