<?php

return [
    'title' => 'Bestellungen',
];
