<?php

return [
    'title' => 'Logistik',

];
