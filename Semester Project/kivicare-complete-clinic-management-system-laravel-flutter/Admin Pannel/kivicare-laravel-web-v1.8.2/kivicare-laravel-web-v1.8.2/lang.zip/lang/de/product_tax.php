<?php

return [
    'title' => 'Steuern',
];
