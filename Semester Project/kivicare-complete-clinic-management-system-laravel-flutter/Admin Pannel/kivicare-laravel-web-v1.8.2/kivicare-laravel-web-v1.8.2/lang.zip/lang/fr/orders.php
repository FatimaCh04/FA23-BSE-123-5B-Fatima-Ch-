<?php

return [
    'title' => 'Commandes',
];
