<?php

return [
    'title' => 'Logistique',

];
