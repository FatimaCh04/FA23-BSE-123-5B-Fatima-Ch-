<?php

return [
    'title' => 'Taxe',
];
