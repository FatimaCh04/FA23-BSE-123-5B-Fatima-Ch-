<?php

return [
    'title' => 'Logistics',

];
