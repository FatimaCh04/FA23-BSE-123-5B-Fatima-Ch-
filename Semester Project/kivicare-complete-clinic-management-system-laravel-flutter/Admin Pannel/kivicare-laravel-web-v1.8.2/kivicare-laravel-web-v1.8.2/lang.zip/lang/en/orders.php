<?php

return [
    'title' => 'Orders',
];
