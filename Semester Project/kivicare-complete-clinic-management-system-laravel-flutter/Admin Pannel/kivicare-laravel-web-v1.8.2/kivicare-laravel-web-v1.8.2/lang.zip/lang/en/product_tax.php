<?php

return [
    'title' => 'Tax',
];
