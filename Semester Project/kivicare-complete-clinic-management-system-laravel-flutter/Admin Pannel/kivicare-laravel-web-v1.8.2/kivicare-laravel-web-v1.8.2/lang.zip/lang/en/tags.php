<?php

return [
    'title' => 'Tag',
];
