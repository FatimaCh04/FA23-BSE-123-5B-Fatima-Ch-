<?php

return [
    'title' => 'Location',
];
