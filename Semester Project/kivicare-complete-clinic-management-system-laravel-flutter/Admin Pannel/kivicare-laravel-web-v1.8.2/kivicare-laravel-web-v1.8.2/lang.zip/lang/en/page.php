<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'title' => 'Pages',
    'lbl_title' => 'Title',
    'lbl_description' => 'Description',
    'lbl_sequence' => 'Sequence',
    'lbl_status' => 'Status',
    'lbl_action' => 'Action',
    'lbl_name' => 'Name',
    'lbl_more_permission' => 'Add More Permissions',
    'lbl_role' => 'Role',
    'lbl_import' => 'Import From Role',
    'lbl_page'=>'Page',
    'lbl_page_url'=>'Copy Page Url'

];
