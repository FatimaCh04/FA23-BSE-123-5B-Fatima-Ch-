<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Constant\Models\Constant;

class PakistanPaymentMethodsSeeder extends Seeder
{
    public function run(): void
    {
        $methods = [
            ['name' => 'jazzcash', 'type' => 'PAYMENT_METHODS', 'value' => 'JazzCash', 'status' => 1],
            ['name' => 'easypaisa', 'type' => 'PAYMENT_METHODS', 'value' => 'Easypaisa', 'status' => 1],
        ];

        foreach ($methods as $method) {
            Constant::updateOrCreate(
                ['name' => $method['name'], 'type' => $method['type']],
                $method
            );
        }
    }
}

