<?php $__env->startSection('title'); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-content mb-5">
    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="d-flex flex-wrap gap-3">
            <?php if(auth()->user()->can('edit_encounter') || auth()->user()->can('delete_encounter')): ?>
            <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route('backend.encounter.bulk_action')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('backend.encounter.bulk_action')).'']); ?>
                <div class="">
                    <select name="action_type" class="select2 form-select col-12" id="quick-action-type" style="width:100%">
                        <option value=""><?php echo e(__('messages.no_action')); ?></option>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_encounter')): ?>
                        <option value="change-status"><?php echo e(__('messages.status')); ?></option>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_encounter')): ?>
                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="select-status d-none quick-action-field" id="change-status-action">
                    <select name="status" class="select2 form-select" id="status" style="width:100%">
                        <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
                        <option value="1"><?php echo e(__('messages.open')); ?></option>
                        <option value="0"><?php echo e(__('messages.close')); ?></option>
                    </select>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
            <?php endif; ?>
            <div>
                <button type="button" class="btn btn-primary" data-modal="export">
                <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

                </button>
                
                
                
            </div>
        </div>
         <?php $__env->slot('toolbar', null, []); ?> 

            <div>
                <div class="datatable-filter">
                    <select name="column_status" id="column_status" class="select2 form-select" data-filter="select" style="width: 100%">
                        <option value=""><?php echo e(__('messages.all')); ?></option>
                        <option value="0" <?php echo e($filter['status'] == '0' ? 'selected' : ''); ?>>
                            <?php echo e(__('appointment.close')); ?>

                        </option>
                        <option value="1" <?php echo e($filter['status'] == '1' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.open')); ?>

                        </option>
                    </select>
                </div>
            </div>

            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..." aria-describedby="addon-wrapping">
            </div>
            <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"><i class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?></button>

            <?php if(Auth::user()->can('add_encounter')): ?>
            <?php if (isset($component)) { $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.offcanvas','data' => ['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__($module_title)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__($module_title)).'']); ?>
            <?php echo e(__('messages.new')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $attributes = $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $component = $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
            <?php endif; ?>

         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
    <table id="datatable" class="table table-responsive">
    </table>
</div>
<div data-render="app">

    <patient-encounter-offcanvas create-title="<?php echo e(__('messages.create')); ?> <?php echo e(__($module_title)); ?>" edit-title="<?php echo e(__('messages.edit')); ?> <?php echo e(__($module_title)); ?>">
    </patient-encounter-offcanvas>

    <patient-encounter-dashboard  create-title="<?php echo e(__('appointment.encouter_dashboard')); ?>" >
    </patient-encounter-dashboard>

    <appointment-customform>
    </appointment-customform>

</div>
<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
     <?php $__env->endSlot(); ?>
    <div class="form-group datatable-filter">
    <label for="patient_name"><?php echo e(__('clinic.patient')); ?></label>
    <div class="col-12">
        <select name="patient_name" id="patient_name" class="select2 form-select" data-filter="select"
            data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'customers'])); ?>"
            data-ajax--cache="true" placeholder="Select a patient">
            <option value="" disabled selected><?php echo e(__('clinic.lbl_select_patient')); ?></option>
        </select>
    </div>
</div>

<div class="form-group datatable-filter">
    <label for="form-label"> <?php echo e(__('clinic.lbl_clinic')); ?></label>
    <div class="col-12">
        <select id="clinic_name" name="clinic_name" data-filter="select"
            class="select2 form-select"
            data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'clinic_name'])); ?>"
            data-ajax--cache="true" placeholder="Select a clinic">
            <option value="" disabled selected><?php echo e(__('clinic.lbl_select_clinic')); ?></option>
        </select>
    </div>
</div>

<div class="form-group datatable-filter">
    <label for="form-label"> <?php echo e(__('clinic.doctors')); ?></label>
    <div class="col-12">
        <select id="doctor_name" name="doctor_name" data-filter="select"
            class="select2 form-select"
            data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'doctors'])); ?>"
            data-ajax--cache="true" placeholder="Select a doctor">
            <option value="" disabled selected><?php echo e(__('clinic.lbl_select_doctor')); ?></option>
        </select>
    </div>
</div>

    <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('appointment.reset')); ?></button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<link rel="stylesheet" href="<?php echo e(mix('modules/appointment/style.css')); ?>">
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/appointment/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>

<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
    const columns = [{
            name: 'check',
            data: 'check',
            title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
            width: '0%',
            exportable: false,
            orderable: false,
            searchable: false,
        },

        {
            data: 'encounter_id',
            name: 'encounter_id',
            title: "<?php echo e(__('sidebar.id')); ?>"
        },
        {
            data: 'appointment_id',
            name: 'appointment_id',
            title: "<?php echo e(__('sidebar.appoitment_id')); ?>",
            className: 'text-center'
        },

        {
            data: 'user_id',
            name: 'user_id',
            title: "<?php echo e(__('sidebar.patient')); ?>"
        },
        {
            data: 'encounter_date',
            name: 'encounter_date',
            title: "<?php echo e(__('appointment.date_time')); ?>",
        },

        <?php if (! (auth()->user()->hasRole('receptionist'))): ?>
        {
            data: 'clinic_id',
            name: 'clinic_id',
            title: "<?php echo e(__('appointment.lbl_clinic')); ?>",
            orderable: true,
            searchable: true,
        },
        <?php endif; ?>
        <?php if (! (auth()->user()->hasRole('doctor'))): ?>
        {
            data: 'doctor_id',
            name: 'doctor_id',
            title: "<?php echo e(__('appointment.lbl_doctor')); ?>",
            orderable: true,
            searchable: true,
        },
        <?php endif; ?>
        {
            data: 'updated_at',
            name: 'updated_at',
            title: "<?php echo e(__('appointment.lbl_update_at')); ?>",
            orderable: true,
            visible: false,
        },
        {
            data: 'status',
            name: 'status',
            orderable: true,
            searchable: true,
            title: "<?php echo e(__('appointment.lbl_status')); ?>",
            width: '5%'
        },


    ]


    const actionColumn = [{
        data: 'action',
        name: 'action',
        orderable: false,
        searchable: false,
        title: "<?php echo e(__('appointment.lbl_action')); ?>",
        width: '5%'
    }]



    let finalColumns = [
        ...columns,
        ...actionColumn
    ]

    document.addEventListener('DOMContentLoaded', (event) => {
        console.log($('#user_id').val());
        initDatatable({
            url: '<?php echo e(route("backend.$module_name.index_data")); ?>',
            finalColumns,
            orderColumn:  <?php if(auth()->user()->hasRole('doctor')): ?>
                            [[4, "desc"]]
                        <?php else: ?>
                            [[5, "desc"]]
                        <?php endif; ?>,
            advanceFilter: () => {
                return {
                    patient_name: $('#patient_name').val(),
                    clinic_name: $('#clinic_name').val(),
                    doctor_name: $('#doctor_name').val(),
                }
                },
            drawCallback: () => {
                // Reinitialize select2 for dynamically created elements in DataTable
                $('.change-select').each(function() {
                    if (!$(this).hasClass('select2-hidden-accessible')) {
                        $(this).select2({
                            width: '100%',
                            minimumResultsForSearch: -1
                        });
                    }
                });
            }
        });
        $('#reset-filter').on('click', function(e) {
            $('#patient_name').val('');
            $('#clinic_name').val('');
            $('#doctor_name').val('');
            window.renderedDataTable.ajax.reload(null, false);
        });
    })


    function resetQuickAction() {
            const actionValue = $('#quick-action-type').val();
            if (actionValue != '') {
                $('#quick-action-apply').removeAttr('disabled');

                if (actionValue == 'change-status') {
                    $('.quick-action-field').addClass('d-none');
                    $('#change-status-action').removeClass('d-none');
                } else {
                    $('.quick-action-field').addClass('d-none');
                }
            } else {
                $('#quick-action-apply').attr('disabled', true);
                $('.quick-action-field').addClass('d-none');
            }
        }

        $('#quick-action-type').change(function() {
            resetQuickAction()
        });
        $(document).ready(function() {
    $('.select2').select2({
        placeholder: function(){
            $(this).data('placeholder');
        },
        allowClear: true,
        tags: true

    });
});

function dispatchCustomEvent(button) {
    const event = new CustomEvent('custom_form_assign', {
        detail: {
        appointment_type: button.getAttribute('data-appointment-type'),
        appointment_id: button.getAttribute('data-appointment-id'),
        form_id: button.getAttribute('data-form-id')
        }
    });

    document.dispatchEvent(event);

    const offcanvasSelector = button.getAttribute('data-assign-target');
    const offcanvasElement = document.querySelector(offcanvasSelector);
    if(offcanvasElement){
        const offcanvas = new bootstrap.Offcanvas(offcanvasElement);
        offcanvas.show();
    }
}

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/patient_encounter/index_datatable.blade.php ENDPATH**/ ?>