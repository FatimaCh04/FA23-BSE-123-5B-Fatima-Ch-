<div class="text-end d-flex gap-3 align-items-center">
    <?php
    $appointmentDate = Carbon\Carbon::parse($data->appointment_date);
    $googleMeetSetting = App\Models\Setting::where('name', 'google_meet_method')->first();
    $googleMeetEnabled = $googleMeetSetting ? $googleMeetSetting->val == 1 : false;

    $zoomSetting = App\Models\Setting::where('name', 'is_zoom')->first();
    $zoomEnabled = $zoomSetting ? $zoomSetting->val == 1 : false;
    $pay_status = optional($data->payment)->payment_status;
    ?>

    



    <?php if(!in_array($data->status, ['pending', 'confirm', 'cancel']) && $data->status !== null): ?>
    <?php if($data->patientEncounter !=null): ?>
    <a href="<?php echo e(route('backend.encounter.encounter-detail-page', ['id' => $data->patientEncounter->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('appointment.patient_encounter')); ?>"><i class="icon ph ph-squares-four align-middle"></i></a>
    <?php endif; ?>
    <?php endif; ?>


    <?php if(optional($data->clinicservice)->is_video_consultancy == 1 && $appointmentDate->isToday()): ?>
    <?php if($googleMeetEnabled && $data->meet_link != null): ?>
    <a href="<?php echo e(route("backend.google_connect", ['id' => $data->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('clinic.google_meet')); ?>"><i class="fa-solid fa-video"></i></a>
    <?php endif; ?>

    <?php if($zoomEnabled && $data->start_video_link != null): ?>
    <a href="<?php echo e(route("backend.zoom_connect", ['id' => $data->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('clinic.zoom_meet')); ?>"><i class="fa-solid fa-video"></i></a>
    <?php endif; ?>
    <?php endif; ?>
    <!-- <?php if(setting('view_patient_soap') == 1): ?>
    <a href="<?php echo e(route("backend.patient-record", ['id' => $data->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('clinic.appointment_patient_records')); ?>"><i class="fa-solid fa-notepad"></i></a>
    <?php endif; ?> -->

    <!-- <button type='button' data-assign-module="<?php echo e($data->id); ?>" data-assign-target='#appointment-offcanvas' data-assign-event='appointment-details' class='btn text-primary p-0 fs-5' data-bs-toggle='tooltip' title='Clinic Session'><i class="fa-solid fa-eye"></i></a> -->
    </button>
    <?php if($pay_status == 1 && $data->status == 'checkout'): ?>
    <a href="<?php echo e(route('backend.appointments.invoice_detail', ['id' => $data->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('clinic.invoice_detail')); ?>">
    <i class="ph ph-file-pdf"></i>
    </a>
    <?php endif; ?>
    <?php if (! (auth()->user()->hasRole('doctor'))): ?>
    <?php if(Auth::user()->can('delete_clinic_appointment_list')): ?>
    <a href="<?php echo e(route('backend.appointment.destroy', $data->id)); ?>"
       id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>"
       class="btn text-danger p-0 fs-5"
       data-type="ajax"
       data-method="DELETE"
       data-token="<?php echo e(csrf_token()); ?>"
       data-bs-toggle="tooltip"
       title="<?php echo e(__('messages.delete')); ?>"
       data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->user->full_name ?? default_user_name()), 'module' => __('appointment.singular_title')])); ?>">
       <i class="ph ph-trash"></i>
    </a>
    <?php endif; ?>
<?php endif; ?>


<?php if($customform): ?>

    <?php $__currentLoopData = $customform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
        $formdata=json_decode($form->formdata);
        $appointment_status= json_decode($form->appointment_status);

        // Normalize the appointment status and adjust 'confirm' to 'confirmed'
        $AppointmentStatus = array_map(function ($status) {
            return strtolower(trim($status)) === 'confirm' ? 'confirmed' : strtolower(trim($status));
        }, (array) $appointment_status);
        ?>

        <?php if(in_array(strtolower($data->status), $AppointmentStatus) && $data->status !== null): ?>

        <button type="button"
                data-assign-target="#appointment-customform"
                data-assign-event="custom_form_assign"
                data-appointment-type="appointment"
                data-appointment-id="<?php echo e($data->id); ?>"
                data-form-id="<?php echo e($form->id); ?>"
                class="btn text-info p-0 fs-5"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="<?php echo e($formdata->form_title); ?>"
                onclick="dispatchCustomEvent(this)">
                <i class="icon ph ph-file align-middle"></i>
            </button>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/clinic_appointment/datatable/action_column.blade.php ENDPATH**/ ?>