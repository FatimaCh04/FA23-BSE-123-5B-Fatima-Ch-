

<footer class="footer pr-hide sticky <?php echo e(getCustomizationSetting('footer_style')); ?>">
  <div class="footer-body">
      <div class="left-panel">
          <a href="<?php echo e(route('backend.home')); ?>"><?php echo e(setting('app_name')); ?></a>.
          <?php echo e(setting('copyright_text')); ?>

      </div>
      <div class="center-panel">
          <?php echo setting('footer_text'); ?>

      </div>
      <div class="end-panel">
        <?php echo setting('ui_text'); ?>

      </div>
  </div>
</footer>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>