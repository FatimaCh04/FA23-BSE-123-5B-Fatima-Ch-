<?php if($data->status): ?> 

<span class="badge booking-status bg-success-subtle p-2"><?php echo e(__('appointment.open')); ?> </span>
                  
<?php else: ?>

<span class="badge booking-status bg-danger-subtle p-2"><?php echo e(__('appointment.close')); ?> </span>

<?php endif; ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/patient_encounter/verify_action.blade.php ENDPATH**/ ?>