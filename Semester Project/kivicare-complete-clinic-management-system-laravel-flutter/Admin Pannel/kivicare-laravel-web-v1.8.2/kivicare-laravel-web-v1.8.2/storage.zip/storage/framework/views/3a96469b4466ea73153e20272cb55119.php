<?php $__env->startSection('title'); ?>
   <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-styles'); ?>
<link rel="stylesheet" href="<?php echo e(mix('modules/service/style.css')); ?>">
<style>
    .offcanvas.offcanvas-w-40 { --bs-offcanvas-width: 40vw; }
    @media (max-width: 576px) {
        .offcanvas.offcanvas-w-40 { --bs-offcanvas-width: 100vw; }
    }
    @media (min-width: 576px) and (max-width: 992px) {
        .offcanvas.offcanvas-w-40 { --bs-offcanvas-width: 60vw; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-content mb-5">
    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="d-flex flex-wrap gap-3">
            <?php if(auth()->user()->can('edit_clinics_service') ||
            auth()->user()->can('delete_clinics_service')): ?>
            <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route('backend.services.bulk_action')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('backend.services.bulk_action')).'']); ?>
                <div class="">
                    <select name="action_type" class="select2 form-select col-12" id="quick-action-type" style="width:100%">
                        <option value=""><?php echo e(__('messages.no_action')); ?></option>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_clinics_service')): ?>
                        <option value="change-status"><?php echo e(__('messages.status')); ?></option>

                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_clinics_service')): ?>
                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="select-status d-none quick-action-field" id="change-status-action">
                    <select name="status" class="select2 form-select" id="status" style="width:100%">
                        <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
                        <option value="1"><?php echo e(__('messages.active')); ?></option>
                        <option value="0"><?php echo e(__('messages.inactive')); ?></option>
                    </select>
                </div>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
            <?php endif; ?>
            <div>
                <button type="button" class="btn btn-primary" data-modal="export">
                    <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

                </button>
            </div>
        </div>
         <?php $__env->slot('toolbar', null, []); ?> 

            <div>
                <div class="datatable-filter">
                    <select name="column_status" id="column_status" class="select2 form-select" data-filter="select" style="width: 100%">
                        <option value=""><?php echo e(__('messages.all')); ?></option>
                        <option value="0" <?php echo e($filter['status'] == '0' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.inactive')); ?>

                        </option>
                        <option value="1" <?php echo e($filter['status'] == '1' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.active')); ?>

                        </option>
                    </select>
                </div>
            </div>

            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..." aria-label="Search" aria-describedby="addon-wrapping">
            </div>
            <div class="d-flex align-items-center gap-2">
                <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                    <i class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?>

                </button>
                
                <?php if(Auth::user()->can('add_clinics_service')): ?>
                <button 
                    class="btn btn-primary d-flex align-items-center gap-1" 
                    type="button"
                    data-bs-toggle="offcanvas" 
                    data-bs-target="#createServiceForm" 
                    aria-controls="createServiceForm"
                >
                    <i class="ph ph-plus-circle"></i> <?php echo e(__('messages.new')); ?>

                </button>
                <?php endif; ?>

                <div class="offcanvas offcanvas-end offcanvas-w-40" tabindex="-1" id="createServiceForm">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title"><?php echo e(__('clinic.create_service')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                    </div>
                    <div class="offcanvas-body">
                        <?php echo $__env->make('clinic::backend.services.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>  
                    </div>
                </div>
                
                
            </div>

         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
    <table id="datatable" class="table table-responsive">
    </table>
</div>
<div data-render="app">
    



    
    <assign-doctor-form-offcanvas></assign-doctor-form-offcanvas>
    <assign-service-provider-form-offcanvas></assign-service-provider-form-offcanvas>
    <gallery-form-offcanvas></gallery-form-offcanvas>
</div>
<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
     <?php $__env->endSlot(); ?>
   
    <div class="form-group datatable-filter">
        <label class="form-label" for="price_range"><?php echo e(__('service.lbl_price')); ?></label>
        <select name="price_range" id="price_range" class="select2 form-select" data-filter="select"
            data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'price_range'])); ?>"
            data-ajax--cache="true" placeholder="<?php echo e(__('clinic.select_price_range')); ?>">
            <option value="" disabled selected><?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_price')); ?></option>
        </select>
    </div>
    <div class="form-group datatable-filter">
        <label class="form-label" for="column_category"><?php echo e(__('service.lbl_category')); ?></label>
        <select name="column_category" id="column_category" class="select2 form-select" data-filter="select">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_category')); ?></option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" data-parent="<?php echo e($category->parent_id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group datatable-filter d-none" id="subcategory-group">
        <label class="form-label" for="column_subcategory"><?php echo e(__('service.lbl_subcategory')); ?></label>
        <select name="column_subcategory" id="column_subcategory" class="select2 form-select" data-filter="select">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_subcategory')); ?></option>
        </select>
    </div>

    <?php if (! (auth()->user()->hasRole('doctor'))): ?>
    <div class="form-group datatable-filter">
        <label class="form-label" for="doctor"><?php echo e(__('service.lbl_doctor')); ?></label>
        <select name="doctor_id" id="doctor_id" class="select2 form-select" data-filter="select">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_doctor')); ?></option>
            <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($doctors->id); ?>"><?php echo e($doctors->full_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>
    <?php if (! (auth()->user()->hasRole('receptionist'))): ?>
    <div class="form-group datatable-filter">
        <label class="form-label" for="clinic"><?php echo e(__('service.lbl_clinic')); ?></label>
        <select name="clinic" id="clinic" class="select2 form-select" data-filter="select">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_clinic')); ?></option>
            <?php $__currentLoopData = $clinic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($clinics->id); ?>"><?php echo e($clinics->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php endif; ?>
    <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
        <div class="form-group datatable-filter">
            <label for="form-label"><?php echo e(__('clinic.clinic_admin')); ?></label>
            <select  id="column_clinic_admin" name="column_clinic_admin" data-filter="select"
                class="select2 form-select"
                data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'clinic_admin'])); ?>"
                data-ajax--cache="true">
                <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('clinic.clinic_admin')); ?></option>
            </select>
        </div>
    <?php endif; ?>
    <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('messages.reset')); ?></button>
    <div class="form-group custom-range">
        <div class="filter-slider slider-secondary"></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<!-- Select2 CSS -->

<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/clinic/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>

<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
    const columns = [
        <?php if (! (auth()->user()->hasRole('doctor'))): ?>
        {
            name: 'check',
            data: 'check',
            title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
            width: '0%',
            exportable: false,
            orderable: false,
            searchable: false,
        },
        <?php endif; ?>
        {
            data: 'name',
            name: 'name',
            title: "<?php echo e(__('service.lbl_name')); ?>"
        },
        {
            data: 'charges',
            name: 'charges',
            title: "<?php echo e(__('service.lbl_price')); ?>",
            searchable: false,
            orderable: true,
        },
        {
            data: 'duration_min',
            name: 'duration_min',
            title: "<?php echo e(__('service.lbl_duration')); ?>"
        },

        {
            data: 'category_id',
            name: 'category_id',
            title: "<?php echo e(__('service.lbl_category_id')); ?>"
        },
        <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
        {
            data: 'vendor_id',
            name: 'vendor_id',
            title: "<?php echo e(__('multivendor.singular_title')); ?>"
        },
        <?php endif; ?>
        {
            data: 'doctor',
            name: 'doctor',
            title: "<?php echo e(auth()->user()->hasRole('doctor') ? __('clinic.price_change') : __('service.lbl_doctor')); ?>",
            searchable: false,
            orderable: false,
        },
        <?php if( auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin') || auth()->user()->hasRole('vendor') || auth()->user()->hasRole('receptionist') ): ?>
        {
            data: 'status',
            name: 'status',
            orderable: false,
            searchable: true,
            title: "<?php echo e(__('service.lbl_status')); ?>",
            width: '5%'
        },
        <?php endif; ?>

        {
            data: 'updated_at',
            name: 'updated_at',
            title: "<?php echo e(__('service.lbl_update_at')); ?>",
            orderable: true,
            visible: false,
        },

    ]


    const actionColumn = [
    <?php if (! ( auth()->user()->hasRole('doctor'))): ?>
    {
        data: 'action',
        name: 'action',
        orderable: false,
        searchable: false,
        title: "<?php echo e(__('service.lbl_action')); ?>",
        width: '5%'
    }
    <?php endif; ?>
]

    const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)

    let finalColumns = [
        ...columns,
        ...customFieldColumns,
        ...actionColumn
    ]

    document.addEventListener('DOMContentLoaded', (event) => {
        // Initialize Select2 for all select elements
        $('#quick-action-type').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        $('#status').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        $('#column_status').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        $('#price_range').select2({
            width: '100%',
            placeholder: "<?php echo e(__('clinic.select_price_range')); ?>",
            ajax: {
                url: "<?php echo e(route('backend.get_search_data', ['type' => 'price_range'])); ?>",
                dataType: 'json',
                delay: 250,
                cache: true,
                processResults: function(data) {
                    return {
                        results: data
                    };
                }
            }
        });

        $('#column_category').select2({
            width: '100%',
            placeholder: "<?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_category')); ?>",
        });

        $('#column_subcategory').select2({
            width: '100%',
            placeholder: "<?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_subcategory')); ?>",
        });

        $('#doctor_id').select2({
            width: '100%',
            placeholder: "<?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_doctor')); ?>",
        });

        $('#clinic').select2({
            width: '100%',
            placeholder: "<?php echo e(__('service.all')); ?> <?php echo e(__('service.lbl_clinic')); ?>",
        });

        <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
        $('#column_clinic_admin').select2({
            width: '100%',
            placeholder: "<?php echo e(__('service.all')); ?> <?php echo e(__('clinic.clinic_admin')); ?>",
            ajax: {
                url: "<?php echo e(route('backend.get_search_data', ['type' => 'clinic_admin'])); ?>",
                dataType: 'json',
                delay: 250,
                cache: true,
                processResults: function(data) {
                    return {
                        results: data
                    };
                }
            }
        });
        <?php endif; ?>

        initDatatable({
            url: '<?php echo e(route("backend.$module_name.index_data", ["doctor_id" => $doctor_id ])); ?>',
            finalColumns,
            orderColumn: [
                <?php if(auth()->user()->hasRole('doctor')): ?>
                [5, "desc"]
                <?php elseif(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
                [8, "desc"]
                <?php else: ?>
                [7, "desc"]
                <?php endif; ?>
            ],
            advanceFilter: () => {
                return {
                    service_id: $('#service_name').val(),
                    price: $('#price_range').val(),
                    category_id: $('#column_category').val(),
                    sub_category_id: $('#column_subcategory').val(),
                    doctor_id: $('#doctor_id').val(),
                    clinic_id: $('#clinic').val(),
                    clinic_admin: $('#column_clinic_admin').val(),
                }
            }
        });

        $('#reset-filter').on('click', function(e) {
            $('#column_category').val('').trigger('change');
            $('#column_subcategory').val('').trigger('change');
            $('#service_name').val('');
            $('#price_range').val(null).trigger('change');
            $('#doctor_id').val('').trigger('change');
            $('#clinic').val('').trigger('change');
            $('#column_clinic_admin').val(null).trigger('change');

            window.renderedDataTable.ajax.reload(null, false);
        });

        // filterSubcategories($('#column_category').val());
    });

    $('#column_category').on('change', function() {
        var selectedCategoryId = $(this).val();
        var subcategoryGroup = $('#subcategory-group');
        var subcategorySelect = $('#column_subcategory');

        subcategorySelect.html('<option value="">All Sub Categories</option>');

        if (selectedCategoryId !== "") {
            var subcategories = <?php echo $subcategories->toJson(); ?>;
            var hasSubcategories = subcategories.some(function(subcategory) {
                return subcategory.parent_id == selectedCategoryId;
            });

            if (hasSubcategories) {
                subcategoryGroup.removeClass('d-none');
                subcategories.forEach(function(subcategory) {
                    if (subcategory.parent_id == selectedCategoryId) {
                        $('<option></option>').attr('value', subcategory.id).text(subcategory.name).appendTo(subcategorySelect);
                    }
                });
            } else {
                subcategoryGroup.addClass('d-none');
            }
        } else {
            subcategoryGroup.addClass('d-none');
        }
    });



    function resetQuickAction() {
        const actionValue = $('#quick-action-type').val();
        if (actionValue != '') {
            $('#quick-action-apply').removeAttr('disabled');

            if (actionValue == 'change-status') {
                $('.quick-action-field').addClass('d-none');
                $('#change-status-action').removeClass('d-none');

            } else {
                $('.quick-action-field').addClass('d-none');
            }
        } else {
            $('#quick-action-apply').attr('disabled', true);
            $('.quick-action-field').addClass('d-none');
        }
    }

    $('#quick-action-type').change(function() {
        resetQuickAction()
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', ['isNoUISlider' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/services/index_datatable.blade.php ENDPATH**/ ?>