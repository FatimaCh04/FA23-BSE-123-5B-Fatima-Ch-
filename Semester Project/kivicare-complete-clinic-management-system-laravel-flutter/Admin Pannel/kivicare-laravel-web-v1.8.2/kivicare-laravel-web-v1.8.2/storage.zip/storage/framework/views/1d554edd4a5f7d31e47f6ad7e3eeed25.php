    

    <?php $__env->startSection('title'); ?>
        <?php echo e(__($module_title)); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="table-content mb-5">
            <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="d-flex flex-wrap gap-3">
                    <?php if(auth()->user()->can('delete_clinic_appointment_list')): ?>
                        <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route('backend.appointments.bulk_action')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('backend.appointments.bulk_action')).'']); ?>
                            <div class="">
                                <select name="action_type" class="select2 form-select col-12" id="quick-action-type"
                                    style="width:100%">
                                    <option value=""><?php echo e(__('messages.no_action')); ?></option>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_clinic_appointment_list')): ?>
                                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <div>
                        <button type="button" class="btn btn-primary" data-modal="export">
                            <i class="ph ph-export me-1"></i><?php echo e(__('messages.export')); ?>

                        </button>
                        
                    </div>
                </div>
                 <?php $__env->slot('toolbar', null, []); ?> 

                    <div>
                        <div class="datatable-filter status-filter">
                            <select name="column_status" id="column_status" class="select2 form-select" data-filter="select"
                                style="width: 100%">
                                <option value=""><?php echo e(__('messages.all')); ?></option>
                                <option value="pending" <?php echo e($filter['status'] == 'pending' ? 'selected' : ''); ?>>
                                    <?php echo e(__('appointment.pending')); ?>

                                </option>
                                <option value="confirmed" <?php echo e($filter['status'] == 'confirmed' ? 'selected' : ''); ?>>
                                    <?php echo e(__('appointment.confirmed')); ?>

                                </option>
                                <option value="check_in" <?php echo e($filter['status'] == 'check_in' ? 'selected' : ''); ?>>
                                    <?php echo e(__('appointment.check_in')); ?>

                                </option>
                                <option value="checkout" <?php echo e($filter['status'] == 'checkout' ? 'selected' : ''); ?>>
                                    <?php echo e(__('appointment.checkout')); ?>

                                </option>
                                <option value="cancelled" <?php echo e($filter['status'] == 'cancelled' ? 'selected' : ''); ?>>
                                    <?php echo e(__('appointment.cancelled')); ?>

                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="input-group flex-nowrap">
                        <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-magnifying-glass"></i></span>
                        <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..."
                            aria-label="Search" aria-describedby="addon-wrapping">
                    </div>
                    <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"><i
                            class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?></button>

                    
                    
                    <?php if(Auth::user()->can('add_clinic_appointment_list')): ?>
                        
                        <button type="button"
                            class="btn btn-primary"
                            data-bs-toggle="offcanvas"
                            data-bs-target="#form-offcanvas"
                            aria-controls="form-offcanvas">
                            <i class="ph ph-plus-circle me-1"></i><?php echo e(__('messages.new')); ?>

                        </button>

                        
                        <div class="offcanvas offcanvas-end offcanvas-w-40" tabindex="-1" id="form-offcanvas" aria-labelledby="formOffcanvasLabel">
                            <div class="offcanvas-header border-bottom">
                                <h6 class="m-0 h5" id="formOffcanvasLabel">
                                    <?php echo e(__('messages.create')); ?> <?php echo e(__($module_title)); ?>

                                </h6>
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>

                            <div class="offcanvas-body">
                                
                                <?php echo $__env->make('appointment::backend.clinic_appointment.new_appoitment', [
                                    'customers' => $customer,   // <- rename while passing
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
            <table id="datatable" class="table position-relative">
            </table>
        </div>
        <div data-render="app">
            <clinic-appointment-offcanvas create-title="<?php echo e(__('messages.create')); ?> <?php echo e(__($module_title)); ?>"
                edit-title="<?php echo e(__('messages.edit')); ?> <?php echo e(__($module_title)); ?>"
                :customefield="<?php echo e(json_encode($customefield)); ?>" :role="<?php echo e(json_encode(auth()->user()->role)); ?>"
                :user-id="<?php echo e(auth()->user()->id); ?>">
            </clinic-appointment-offcanvas>

            <patient-encounter-dashboard create-title="<?php echo e(__('appointment.encouter_dashboard')); ?>">
            </patient-encounter-dashboard>
            <appointment-offcanvas>
            </appointment-offcanvas>

            <appointment-customform>
            </appointment-customform>
        </div>

        <?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('title', null, []); ?> 
                <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
             <?php $__env->endSlot(); ?>
            <div class="form-group datatable-filter">
                <label class="form-label" for="patient_name"><?php echo e(__('clinic.patient')); ?></label>
                <select name="patient_name" id="patient_name" class="select2 form-select" data-filter="select">
                    <option value=""><?php echo e(__('messages.select_patient')); ?></option>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($patient->id); ?>">
                            <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?>

                            <?php if($patient->otherPatients->count() > 0): ?>
                                (<?php echo e($patient->otherPatients->count()); ?> <?php echo e(__('appointment.other_patients')); ?>)
                            <?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group datatable-filter d-none" id="other_patient_div">
                <label class="form-label" for="other_patient"><?php echo e(__('messages.other_patient')); ?></label>
                <select name="other_patient" id="other_patient" class="select2 form-select" data-filter="select">
                    <option value=""><?php echo e(__('messages.select_other_patient')); ?></option>
                </select>
            </div>
            <div class="form-group datatable-filter">
                <label class="form-label" for="service_name"><?php echo e(__('service.singular_title')); ?></label>
                <select name="service_name" id="service_name" class="select2 form-select" data-filter="select">
                    <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('service.singular_title')); ?></option>
                    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="datatable-filter">
                <label class="form-label" for="other_patient"><?php echo e(__('messages.status')); ?></label>
                <select name="Status" id="appointment_status" class="select2 form-select" data-filter="select">
                    <option value=""><?php echo e(__('messages.all')); ?></option>
                    <option value="pending"><?php echo e(__('appointment.pending')); ?></option>
                    <option value="confirmed"><?php echo e(__('appointment.confirmed')); ?></option>
                    <option value="check_in"><?php echo e(__('appointment.check_in')); ?></option>
                    <option value="checkout"><?php echo e(__('appointment.checkout')); ?></option>
                    <option value="cancelled"><?php echo e(__('appointment.cancelled')); ?></option>
                </select>
            </div>
            
        
            <?php if (! (auth()->user()->hasRole('doctor'))): ?>
                <div class="form-group datatable-filter">
                    <label class="form-label" for="doctor_id"><?php echo e(__('clinic.doctor_title')); ?></label>
                    <select name="doctor_id" id="doctor_id" class="select2 form-select" data-filter="select">
                        <option value=""><?php echo e(__('service.lbl_doctor')); ?> </option>
                        <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($doctor->doctor_id); ?>"><?php echo e(optional($doctor->user)->full_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
            <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('appointment.reset')); ?></button>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('after-styles'); ?>
        <link rel="stylesheet" href="<?php echo e(mix('modules/appointment/style.css')); ?>">
        <!-- DataTables Core and Extensions -->
        <link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <style>
        .disabled-cell {
            background-color: #e9ecef;
            pointer-events: none;
            opacity: 0.5;
        }
    </style>
    <?php $__env->startPush('after-scripts'); ?>
        <script src="<?php echo e(mix('modules/appointment/script.js')); ?>"></script>
        <script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>

        <!-- DataTables Core and Extensions -->
        <script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>
        <script>
            const userRoles = <?php echo json_encode(auth()->user()->roles->pluck('name')->toArray(), 15, 512) ?>;
        </script>
        <script type="text/javascript" defer>
            const columns = [
                <?php if (! (auth()->user()->hasRole('doctor') || auth()->user()->hasRole('receptionist') || auth()->user()->hasRole('user'))): ?>
                    {
                        name: 'check',
                        data: 'check',
                        title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
                        width: '0%',
                        exportable: false,
                        orderable: false,
                        searchable: false,
                    },
                <?php endif; ?> {
                    data: 'id',
                    name: 'id',
                    title: "<?php echo e(__('appointment.lbl_id')); ?>",
                    searchable: false,
                    orderable: true,

                },
                {
                    data: 'user_id',
                    name: 'user_id',
                    title: "<?php echo e(__('sidebar.patient')); ?>",
                    orderable: true,
                    searchable: true,
                },
                {
                    data: 'start_date_time',
                    name: 'start_date_time',
                    title: "<?php echo e(__('appointment.lbl_date_time')); ?>",
                    orderable: true,
                },
                {
                    data: 'services',
                    name: 'services',
                    title: "<?php echo e(__('appointment.lbl_service')); ?>",
                    orderable: true,
                    searchable: true,
                    width: '10%'
                },
                {
                    data: 'service_amount',
                    name: 'service_amount',
                    title: "<?php echo e(__('appointment.price')); ?>",
                    orderable: true,
                    searchable: true,
                },
                <?php if (! (auth()->user()->hasRole('doctor'))): ?>
                    {
                        data: 'doctor_id',
                        name: 'doctor_id',
                        title: "<?php echo e(__('appointment.lbl_doctor')); ?>",
                        orderable: true,
                        searchable: true,
                    },
                <?php endif; ?>
                 {
                    data: 'updated_at',
                    name: 'updated_at',
                    title: "<?php echo e(__('appointment.lbl_update_at')); ?>",
                    orderable: true,
                    visible: false,
                },
                {
                    data: 'status',
                    name: 'status',
                    orderable: true,
                    searchable: true,
                    title: "<?php echo e(__('appointment.lbl_status')); ?>",
                    width: '5%',
                    createdCell: function(td, cellData, rowData, row, col) {
                        if (userRoles.includes('user')) {
                            $(td).addClass('disabled-cell');
                            $(td).attr('title', '<?php echo e(__('messages.no_permission_edit_field')); ?>');
                        }
                    }
                },
                {
                    data: 'payment_status',
                    name: 'payment_status',
                    orderable: false,
                    searchable: false,
                    title: "<?php echo e(__('appointment.lbl_payment_status')); ?>",
                    width: '10%',
                    createdCell: function(td, cellData, rowData, row, col) {
                        if (userRoles.includes('user')) {
                            $(td).addClass('disabled-cell');
                            $(td).attr('title', '<?php echo e(__('messages.no_permission_edit_field')); ?>');
                        }
                    }
                },

            ]


            const actionColumn = [
                <?php if (! (auth()->user()->hasRole('user'))): ?>
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false,
                        title: "<?php echo e(__('appointment.lbl_action')); ?>",
                        width: '5%'
                    }
                <?php endif; ?>
            ]


            const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)

            let finalColumns = [
                ...columns,
                ...customFieldColumns,
                ...actionColumn
            ]

            document.addEventListener('DOMContentLoaded', (event) => {
                // Initialize datatable first
                initDatatable({
                    url: '<?php echo e(route("backend.$module_name.index_data", ['user_id' => $user_id, 'doctor_id' => $doctor_id, 'clinic_id' => $clinic_id])); ?>',
                    finalColumns,
                    orderColumn: <?php if(auth()->user()->hasRole('doctor')): ?>
                        [
                            [5, "desc"]
                        ]
                    <?php else: ?>
                        [
                            [7, "desc"]
                        ]
                    <?php endif; ?> ,
                    advanceFilter: () => {
                        return {
                            doctor_id: $('#doctor_id').val(),
                            service_id: $('#service_name').val(),
                            other_patient_id: $('#other_patient').val(),
                            patient_id: $('#patient_name').val(),
                            status: $('#appointment_status').val()
                        }
                    },
                    drawCallback: () => {
                        // Reinitialize select2 for dynamically created elements in DataTable
                        $('.change-select').each(function() {
                            if (!$(this).hasClass('select2-hidden-accessible')) {
                                $(this).select2({
                                    width: '100%',
                                    minimumResultsForSearch: -1
                                });
                            }
                        });
                    }
                });

                // Add change event listeners for all filter dropdowns
                $('#patient_name, #doctor_id, #service_name, #appointment_status, #other_patient').on('change', function() {
                    if (window.renderedDataTable) {
                        window.renderedDataTable.ajax.reload(null, false);
                    }
                });

                // Reset filter functionality
                $('#reset-filter').on('click', function(e) {
                    e.preventDefault();
                    $('#doctor_id, #patient_name, #service_name, #appointment_status').val('').trigger('change');
                    $('#other_patient').val('').trigger('change');
                    $('#other_patient_div').addClass('d-none');
                    if (window.renderedDataTable) {
                        window.renderedDataTable.ajax.reload(null, false);
                    }
                });
            });

            function resetQuickAction() {
                const actionValue = $('#quick-action-type').val();
                if (actionValue != '') {
                    $('#quick-action-apply').removeAttr('disabled');

                    if (actionValue == 'change-status') {
                        $('.quick-action-field').addClass('d-none');
                        $('#change-status-action').removeClass('d-none');
                    } else {
                        $('.quick-action-field').addClass('d-none');
                    }
                } else {
                    $('#quick-action-apply').attr('disabled', true);
                    $('.quick-action-field').addClass('d-none');
                }
            }

            $('#quick-action-type').change(function() {
                resetQuickAction()
            });

            function dispatchCustomEvent(button) {
                const event = new CustomEvent('custom_form_assign', {
                    detail: {
                        appointment_type: button.getAttribute('data-appointment-type'),
                        appointment_id: button.getAttribute('data-appointment-id'),
                        form_id: button.getAttribute('data-form-id')
                    }
                });

                document.dispatchEvent(event);

                const offcanvasSelector = button.getAttribute('data-assign-target');
                const offcanvasElement = document.querySelector(offcanvasSelector);
                if (offcanvasElement) {
                    const offcanvas = new bootstrap.Offcanvas(offcanvasElement);
                    offcanvas.show();
                }
            }
        </script>
        
        <script>
            $(document).ready(function() {
                // Initialize select2
                $('.select2').select2();
                // Handle patient selection change
                $('#patient_name').on('change', function() {
                    const patientId = $(this).val();
                    const $otherPatientDiv = $('#other_patient_div');
                    const $otherPatientSelect = $('#other_patient');

                    if (!patientId) {
                        $otherPatientDiv.addClass('d-none');
                        $otherPatientSelect.empty();
                        return;
                    }

                    // Fetch other patients for selected patient
                    $.ajax({
                        url: '<?php echo e(route('backend.appointment.other_patientlist')); ?>',
                        method: 'GET',
                        data: {
                            patient_id: patientId
                        },
                        success: function(response) {
                            $otherPatientSelect.empty().append(
                                '<option value=""><?php echo e(__('messages.select_other_patient')); ?></option>'
                            );

                            if (response && response.length > 0) {
                                $otherPatientSelect.append(`
                                        <option value=""><?php echo e(__('messages.all_patients')); ?></option>
                                        <option value="you"><?php echo e(__('messages.you')); ?></option>
                                    `);
                                response.forEach(function(patient) {
                                    // Create the option with image and name
                                    const option = `
                                                                        <option value="${patient.id}" >
                                            ${patient.first_name}
                                        </option>
                                    `;
                                    $otherPatientSelect.append(option);
                                });

                                // Initialize Select2 with custom template
                                $otherPatientSelect.select2({
                                    templateResult: formatPatient,
                                    templateSelection: formatPatient
                                });

                                $otherPatientDiv.removeClass('d-none');
                            } else {
                                $otherPatientDiv.addClass('d-none');
                            }
                        },
                        error: function() {
                            console.error('Failed to fetch other patients');
                            $otherPatientDiv.addClass('d-none');
                        }
                    });
                });

                // Add custom format function
                function formatPatient(patient) {
                    if (!patient.id) {
                        return patient.text;
                    }

                    const $container = $(
                        `<div class="select2-patient-option d-flex align-items-center gap-2">
                            <img src="${$(patient.element).data('image')}" class="patient-avatar" style="width: 30px; height: 30px; border-radius: 50%;"/>
                            <span>${patient.text}</span>
                        </div>`
                    );

                    return $container;
                }
            });
        </script>
        <script>
            let previousStatus = null;
            let currentSelect = null;
            let selectedStatus = null;
            let appointmentId = null;
            let token = null;
            let cancellation_charge = <?php echo json_encode(setting('cancellation_charge'), 15, 512) ?>;
            let cancelltion_Type = <?php echo json_encode(setting('cancellation_type'), 15, 512) ?>;

            $(document).on('focus', '.change-select', function () {
                previousStatus = $(this).val();
            });

            // Handle Select2 change events
            $(document).on('select2:select', '.change-select', function (e) {
                currentSelect = $(this);
                selectedStatus = currentSelect.val();
                appointmentId = currentSelect.data('id');
                token = currentSelect.data('token');

                if (selectedStatus === 'cancelled') {
                let charge = currentSelect.data('charge');

                if (charge > 0) {
                    $('#cancel_charge_info').html(`<?php echo e(__('messages.cancellation_charges_applied')); ?>: <strong>${currencyFormat(charge)}</strong>`);
                } else {
                    $('#cancel_charge_info').html(`<?php echo e(__('messages.no_cancellation_charge')); ?>`);
                }
                $('#cancelModal').css('display', 'flex');
                $('#cancelModal').fadeIn();
                } else {
                updateStatus(selectedStatus);
                }
            });

            // Fallback for regular change events (in case Select2 is not initialized)
            $(document).on('change', '.change-select', function (e) {
                // Only handle if Select2 is not initialized
                if (!$(this).hasClass('select2-hidden-accessible')) {
                currentSelect = $(this);
                selectedStatus = currentSelect.val();
                appointmentId = currentSelect.data('id');
                token = currentSelect.data('token');

                if (selectedStatus === 'cancelled') {
                    let charge = currentSelect.data('charge');

                    if (charge > 0) {
                    $('#cancel_charge_info').html(`<?php echo e(__('messages.cancellation_charges_applied')); ?>: <strong>${currencyFormat(charge)}</strong>`);
                    } else {
                    $('#cancel_charge_info').html(`<?php echo e(__('messages.no_cancellation_charge')); ?>`);
                    }
                    $('#cancelModal').css('display', 'flex');
                    e.preventDefault();
                    currentSelect.blur();
                    $('#cancelModal').fadeIn();
                } else {
                    updateStatus(selectedStatus);
                }
                }
            });

            function updateStatus(status, reason = null, charge = 0) {


                let url = "<?php echo e(route('backend.appointments.updateStatus', ['id' => '__id__', 'action_type' => 'update-status'])); ?>".replace('__id__', appointmentId);

                $.ajax({
                type: 'POST',
                url: url,
                headers: { 'X-CSRF-TOKEN': token },
                data: {
                    value: status,
                    ...(status === 'cancelled' ? {
                    reason: reason,
                    cancellation_charge_amount: charge,
                    cancellation_type: cancelltion_Type,
                    cancellation_charge: cancellation_charge
                    } : {})
                },
                success: function (res) {
                    window.successSnackbar(res.message);
                    closeCancelModal();
                    $('#datatable').DataTable().ajax.reload();
                },
                error: function () {
                    console.error('<?php echo e(__('messages.something_went_wrong')); ?>');
                }
                });
            }

            function closeCancelModal() {
                $('#cancelModal').hide();
                $('#cancel_reason').val('');
            }

            function cancelAbort() {
                closeCancelModal();
                $('#datatable').DataTable().ajax.reload();
            }

            function submitCancellation() {
                const reason = $('#cancel_reason').val();
                let charge = currentSelect.data('charge');

                $('#cancel_reason').removeClass('is-invalid');
                $('#cancel_reason_error').remove();

                if (!reason) {
                $('#cancel_reason').addClass('is-invalid');
                $('#cancel_reason').after('<div id="cancel_reason_error" class="invalid-feedback d-block"><?php echo e(__("messages.please_enter_reason")); ?></div>');
                return;
                }

                $('#confirm_btn').html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span><?php echo e(__('appointment.loading')); ?>');

                updateStatus('cancelled', reason, charge);
            }

            // Expose cancel and submit functions globally if needed
            window.cancelAbort = cancelAbort;
            window.submitCancellation = submitCancellation;

            // Use global Select2 system - no custom initialization needed
            // The global system in backend-custom.js will handle .select2 elements automatically

        </script>

    <?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/clinic_appointment/index_datatable.blade.php ENDPATH**/ ?>