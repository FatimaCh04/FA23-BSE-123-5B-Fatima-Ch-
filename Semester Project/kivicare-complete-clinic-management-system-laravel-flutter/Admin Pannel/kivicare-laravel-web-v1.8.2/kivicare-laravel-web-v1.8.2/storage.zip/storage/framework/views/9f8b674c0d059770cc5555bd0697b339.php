<div class="text-end d-flex gap-3 align-items-center">
<button type="button" class="btn text-success p-0 fs-5" data-crud-id="<?php echo e($data->id); ?>" title="<?php echo e(__('messages.edit')); ?> " data-bs-toggle="tooltip"> <i class="ph ph-pencil-simple-line align-middle"></i></button>




<a href="<?php echo e(route('backend.encounter.encounter-detail-page', ['id' => $data->id])); ?>" data-type="ajax" class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('appointment.patient_encounter')); ?>"><i class="icon ph ph-squares-four align-middle"></i></a>

<?php if(setting('view_patient_soap') == 1): ?>
    <a href="<?php echo e(route("backend.patient-record", ['id' => $data->id])); ?>" data-type="ajax"  class='btn text-info p-0 fs-5'  data-bs-toggle="tooltip" title="<?php echo e(__('clinic.appointment_patient_records')); ?>"><i class="ph ph-notepad align-middle"></i></a>
<?php endif; ?>
    <a href="<?php echo e(route("backend.appointments.destroy", $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="btn text-danger p-0 fs-5" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->user->full_name ?? default_user_name()), 'module' => __('appointment.patient_encounter')])); ?>"><i class="ph ph-trash align-middle"></i></a>


<?php if($customform): ?>

    <?php $__currentLoopData = $customform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $formdata=json_decode($form->formdata);
            $appointment_status= json_decode($form->appointment_status);

        ?>

        

            <button type="button"
                data-assign-target="#appointment-customform"
                data-assign-event="custom_form_assign"
                data-appointment-type="appointment"
                data-appointment-id="<?php echo e($data->id); ?>"
                data-form-id="<?php echo e($form->id); ?>"
                class="btn text-info p-0 fs-5"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="<?php echo e($formdata->form_title); ?>"
                onclick="dispatchCustomEvent(this)">
                <i class="icon ph ph-file align-middle"></i>
            </button>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/patient_encounter/datatable/action_column.blade.php ENDPATH**/ ?>