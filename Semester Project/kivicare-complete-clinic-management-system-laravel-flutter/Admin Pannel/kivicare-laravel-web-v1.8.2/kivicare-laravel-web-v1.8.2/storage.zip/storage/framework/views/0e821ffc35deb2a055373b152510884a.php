<form action="<?php echo e($url ?? ''); ?>" id="quick-action-form" class="form-disabled d-flex gap-3 align-items-stretch">
  <?php echo csrf_field(); ?>
  <?php echo e($slot); ?>

  <input type="hidden" name="message_change-featured" value="<?php echo e(__('messages.are_you_sure_you_want_to_perform_this_action')); ?>">
  <input type="hidden" name="message_change-status" value="<?php echo e(__('messages.are_you_sure_you_want_to_perform_this_action')); ?>">
  <input type="hidden" name="message_delete" value="<?php echo e(__('messages.are_you_sure_you_want_to_delete_it')); ?>">
  <button class="btn btn-gray" id="quick-action-apply"><?php echo e(__('messages.apply')); ?></button>
</form>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\resources\views/components/backend/quick-action.blade.php ENDPATH**/ ?>