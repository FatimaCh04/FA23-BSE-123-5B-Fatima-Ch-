<?php $__env->startSection('title'); ?>
  <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-styles'); ?>
<link rel="stylesheet" href="<?php echo e(mix('modules/constant/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="table-content mb-5">
  <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex flex-wrap gap-3">
      <?php if(auth()->user()->can('edit_clinic_receptionist_list') || auth()->user()->can('delete_clinic_receptionist_list')): ?>
      <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route("backend.$module_name.bulk_action")).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route("backend.$module_name.bulk_action")).'']); ?>
        <div class="">
          <select name="action_type" class="select2 form-select col-12" id="quick-action-type" style="width:100%">
            <option value=""><?php echo e(__('messages.no_action')); ?></option>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_clinic_receptionist_list')): ?>
            <option value="change-status"><?php echo e(__('messages.status')); ?></option>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_clinic_receptionist_list')): ?>
          <option value="delete"><?php echo e(__('messages.delete')); ?></option>
          <?php endif; ?>
          </select>
        </div>
        <div class="select-status d-none quick-action-field" id="change-status-action">
          <select name="status" class="select2 form-select" id="status" style="width:100%">
              <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
            <option value="1"><?php echo e(__('messages.active')); ?></option>
            <option value="0"><?php echo e(__('messages.inactive')); ?></option>
          </select>
        </div>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
      <?php endif; ?>
      <div>
        <button type="button" class="btn btn-primary" data-modal="export">
        <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

        </button>

      </div>
    </div>

     <?php $__env->slot('toolbar', null, []); ?> 
      <div class="input-group flex-nowrap">
        <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-magnifying-glass"></i></span>
        <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..." aria-label="Search"
          aria-describedby="addon-wrapping">
      </div>
      <?php if(Auth::user()->can('add_clinic_receptionist_list')): ?>
        <?php if (isset($component)) { $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.offcanvas','data' => ['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__($module_title)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__($module_title)).'']); ?><?php echo e(__('messages.new')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $attributes = $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $component = $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
      <?php endif; ?>
     <?php $__env->endSlot(); ?>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
  <table id="datatable" class="table table-responsive">
  </table>
</div>
<div data-render="app">
  <receptionist-offcanvas default-image="<?php echo e(default_file_url()); ?>" create-title="<?php echo e(__('messages.create')); ?> <?php echo e(__('messages.new')); ?> <?php echo e(__('receptionist.singular_title')); ?>"
    edit-title="<?php echo e(__('messages.edit')); ?> <?php echo e(__('receptionist.singular_title')); ?>" :customefield="<?php echo e(json_encode($customefield)); ?>">
  </receptionist-offcanvas>
  <receptionist-change-password create-title="<?php echo e(__('messages.change_password')); ?>"></receptionist-change-password>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/clinic/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>

<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
  const columns = [{
        name: 'check',
        data: 'check',
        title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
        width: '0%',
        exportable: false,
        orderable: false,
        searchable: false,
      },
      {
          data: 'receptionist_id',
          name: 'receptionist_id',
          title: "<?php echo e(__('customer.lbl_name')); ?>",
          orderable: true,
          searchable: true,
      },
      
      {
        data: 'mobile',
        name: 'mobile',
        orderable: false,
        searchable: true,
        title: "<?php echo e(__('customer.lbl_phone_number')); ?>"
      },
      {
          data: 'clinic_id',
          name: 'clinic_id',
          title: "<?php echo e(__('clinic.singular_title')); ?>",
          orderable: false,
          searchable: false,
      },
      
      {
            data: 'email_verified_at',
            name: 'email_verified_at',
            orderable: false,
            searchable: false,
            title: "<?php echo e(__('clinic.lbl_verification_status')); ?>"
      },

     <?php if(auth()->user()->can('edit_clinic_receptionist_list')): ?>

      {
        data: 'status',
        name: 'status',
        orderable: false,
        searchable: true,
        title: "<?php echo e(__('customer.lbl_status')); ?>"
      },
      <?php endif; ?>
      {
        data: 'updated_at',
        name: 'updated_at',
        title: "<?php echo e(__('customer.lbl_update_at')); ?>",
        orderable: true,
        visible: false,
       },
    ]

    const actionColumn = [{
      data: 'action',
      name: 'action',
      orderable: false,
      searchable: false,
      title: "<?php echo e(__('customer.lbl_action')); ?>"
    }]

    const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)

    let finalColumns = [
      ...columns,
      ...customFieldColumns,
      ...actionColumn
    ]

    document.addEventListener('DOMContentLoaded', (event) => {
      // Initialize Select2
      if (typeof $.fn.select2 !== 'undefined') {
        $('.select2').select2({
          width: '100%'
        });
      }

      initDatatable({
        url: '<?php echo e(route("backend.$module_name.index_data")); ?>',
        finalColumns,
        orderColumn: [[ 4, "desc" ]],

      })
    })

    function resetQuickAction() {
      const actionValue = $('#quick-action-type').val();
      if (actionValue != '') {
        $('#quick-action-apply').removeAttr('disabled');

        if (actionValue == 'change-status') {
          $('.quick-action-field').addClass('d-none');
          $('#change-status-action').removeClass('d-none');
        } else {
          $('.quick-action-field').addClass('d-none');
        }
      } else {
        $('#quick-action-apply').attr('disabled', true);
        $('.quick-action-field').addClass('d-none');
      }
    }

    $('#quick-action-type').change(function() {
      resetQuickAction()
    });

    $(document).on('update_quick_action', function() {
      // resetActionButtons()
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/receptionist/index.blade.php ENDPATH**/ ?>