<div class="d-flex gap-3 align-items-center">
  <?php if(Auth::user()->can('edit_clinics_category')): ?>
      <button type="button" class="btn text-success p-0 fs-5" onclick="editCategory(<?php echo e($data->id); ?>, <?php echo e($data->parent_id ?? 'null'); ?>)" data-bs-toggle="tooltip" title="<?php echo e(__('messages.edit')); ?>"><i class="ph ph-pencil-simple-line align-middle"></i></button>
  <?php endif; ?>
  <?php if(Auth::user()->can('delete_clinics_category')): ?>
  <a href="<?php echo e(route("backend.$module_name.destroy", $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="btn text-danger p-0 fs-5" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>"  data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->name) ?? __('Unknown'), 'module' => __('category.title')])); ?>"><i class="ph ph-trash align-middle"></i></a>
  <?php endif; ?>
</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/categories/action_column.blade.php ENDPATH**/ ?>