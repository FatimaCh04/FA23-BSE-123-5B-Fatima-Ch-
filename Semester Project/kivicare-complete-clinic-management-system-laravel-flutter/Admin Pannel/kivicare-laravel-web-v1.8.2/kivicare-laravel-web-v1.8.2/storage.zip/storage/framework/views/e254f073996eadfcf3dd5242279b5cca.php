<div class="d-flex gap-3 align-items-center">
    
<?php if(Auth::user()->can('customer_password')): ?>
<button type='button' data-assign-module="<?php echo e($data->id); ?>" data-assign-target='#receptionist_change_password' data-assign-event='receptionist_assign' class='btn text-info p-0 fs-5' data-bs-toggle="tooltip" title="<?php echo e(__('messages.change_password')); ?>"><i class="ph ph-key"></i></button>
<?php endif; ?>

<?php if(Auth::user()->can('edit_clinic_receptionist_list')): ?>
        <button type="button" class="btn text-primary p-0 fs-5" data-crud-id="<?php echo e($data->id); ?>" title="<?php echo e(__('messages.edit')); ?> " data-bs-toggle="tooltip"> <i class="ph ph-pencil-simple-line"></i></button>
    <?php endif; ?>
    <?php if(Auth::user()->can('delete_clinic_receptionist_list')): ?>
        <a href="<?php echo e(route("backend.$module_name.destroy", $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="btn text-danger p-0 fs-5" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->full_name) ?? __('Unknown'), 'module' => __('receptionist.singular_title')])); ?>"> <i class="ph ph-trash"></i></a>
    <?php endif; ?>
</div>



<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/receptionist/action_column.blade.php ENDPATH**/ ?>