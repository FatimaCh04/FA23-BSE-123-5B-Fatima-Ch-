<?php $__env->startSection('title'); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<meta name="setting_local" content="none">
<input type="hidden" name="admin-profile" value="<?php echo e(asset('img/avatar/avatar.webp')); ?>">
<input type="hidden" name="logo" value="<?php echo e(asset('img/logo/logo.webp')); ?>">
<input type="hidden" name="mini-logo" value="<?php echo e(asset('img/logo/mini_logo.webp')); ?>">
<input type="hidden" name="dark-logo" value="<?php echo e(asset('img/logo/dark_logo.png')); ?>">
<input type="hidden" name="dark-mini-logo" value="<?php echo e(asset('img/logo/dark_mini_logo.webp')); ?>">
<input type="hidden" name="favicon" value="<?php echo e(asset('img/logo/mini_logo.webp')); ?>">

<div id="setting-app"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
  <style>
    .modal-backdrop {
      --bs-backdrop-zindex: 1030;
    }
  </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(asset('js/setting-vue.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\resources\views/backend/settings/index.blade.php ENDPATH**/ ?>