<?php if(isset($data->user) || $data->user || $data->user !== null): ?>
<a href="<?php echo e(route('backend.customers.patient_detail', optional($data->user)->id)); ?>" class="text-reset">
<div class="d-flex gap-3 align-items-center">
  <img src="<?php echo e(optional($data->user)->profile_image ?? default_user_avatar()); ?>" alt="avatar" class="avatar avatar-40 rounded-pill">
  <div class="text-start">
    <h6 class="m-0"><?php echo e(optional($data->user)->full_name ?? default_user_name()); ?></h6>
    <span><?php echo e(optional($data->user)->email ?? '--'); ?></span>
  </div>
</div>
</a>
<?php else: ?>
<p>-</p>
<?php endif; ?>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/clinic_appointment/user_id.blade.php ENDPATH**/ ?>