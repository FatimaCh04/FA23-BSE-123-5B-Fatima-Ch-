<?php if($data->status == 'pending'): ?>
    <span class="badge bg-warning text-dark text-capitalize p-2" style="min-width: 85px;">
        <?php echo e(__('appointment.pending')); ?>

    </span>
    <select name="branch_for" 
            class="form-select form-select-sm change-select select2"
            data-placeholder="<?php echo e(__('messages.select_status')); ?>"
            data-token="<?php echo e(csrf_token()); ?>"
            data-id="<?php echo e($data->id); ?>"
            data-charge="<?php echo e($data->getCancellationCharges() ?? 0); ?>"
            style="width: 40px; margin-left: 5px;">
        <option value=""></option>
        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->name); ?>" <?php echo e($data->status == $value->name ? 'selected' : ''); ?>>
                <?php echo e(__('appointment.' . $value->name)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php elseif($data->status == 'confirmed'): ?>
    <span class="badge bg-primary text-white text-capitalize p-2" style="min-width: 85px;">
        <?php echo e(__('appointment.confirmed')); ?>

    </span>
    <select name="branch_for" 
            class="form-select form-select-sm change-select select2"
            data-placeholder="<?php echo e(__('messages.select_status')); ?>"
            data-token="<?php echo e(csrf_token()); ?>"
            data-id="<?php echo e($data->id); ?>"
            data-charge="<?php echo e($data->getCancellationCharges() ?? 0); ?>"
            style="width: 40px; margin-left: 5px;">
        <option value=""></option>
        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->name); ?>" <?php echo e($data->status == $value->name ? 'selected' : ''); ?>>
                <?php echo e(__('appointment.' . $value->name)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php elseif($data->status == 'cancelled'): ?>
    <span class="badge bg-danger text-white text-capitalize p-2" style="min-width: 85px;">
        <?php echo e(__('appointment.cancelled')); ?>

    </span>
<?php elseif($data->status == 'check_in'): ?>
    <span class="badge bg-success text-white text-capitalize p-2" style="min-width: 85px;">
        <?php echo e(__('appointment.check_in')); ?>

    </span>
<?php elseif($data->status == 'checkout'): ?>
    <span class="badge bg-info text-white text-capitalize p-2" style="min-width: 85px;">
        <?php echo e(__('appointment.checkout')); ?>

    </span>
<?php else: ?>
    <span class="badge bg-secondary text-white text-capitalize p-2" style="min-width: 85px;">
        <?php echo e($data->status); ?>

    </span>
<?php endif; ?>

<!-- Cancel Modal -->
<div id="cancelModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.2); z-index: 1055; align-items: center; justify-content: center;">

  <div style="background: #fff; width: 500px; max-width: 90%; height: auto; padding: 30px 25px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); position: relative; text-align: center; animation: fadeIn 0.3s ease;">

    <!-- Circle X Icon (centered at the top) -->
    <div style="width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; border: 2px solid #6c8cff;">
      <span style="font-size: 28px; color: #6c8cff; font-weight: 300;">✕</span>
    </div>

    <h5 style="font-weight: 500; font-size: 20px; color: #333; margin-bottom: 10px;"><?php echo e(__('messages.cancel_appointment')); ?></h5>

    <p style="color: #777; font-size: 14px; margin-bottom: 20px; line-height: 1.4;">
      <?php echo e(__('messages.cancel_this_appointment')); ?>

      <br>
      <?php echo e(__('messages.cancellation_charge')); ?>

    </p>

    <p id="cancel_charge_info" class="text-danger fw-semibold text-center mb-3" style="font-size: 14px;"></p>

    <!-- Input Reason -->
    <div style="text-align: left; margin-bottom: 20px;">
      <label for="cancel_reason" style="display: block; font-size: 14px; font-weight: 500; margin-bottom: 5px; color: #333;">
        <?php echo e(__('messages.lbl_reason')); ?><span style="color: red;">*</span>
      </label>
      <input type="text" id="cancel_reason" class="form-control" placeholder=' <?php echo e(__('messages.lbl_emergency')); ?>' style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;" />
    </div>

    <!-- Action Buttons -->
    <div style="display: flex; gap: 12px; margin-top: 5px;">
      <button onclick="cancelAbort()" style="flex: 1; padding: 10px; border-radius: 6px; background: white; border: 1px solid #ddd; cursor: pointer; font-weight: 500; color: #555;">
        <?php echo e(__('messages.cancel')); ?>

      </button>
      <button id="confirm_btn" onclick="submitCancellation()" style="flex: 1; padding: 10px; border-radius: 6px; background: #f87f7f; border: none; cursor: pointer; font-weight: 500; color: white;">
        <?php echo e(__('messages.lbl_confirm')); ?>

      </button>
    </div>

  </div>
</div>






<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/appointment/datatable/select_status.blade.php ENDPATH**/ ?>