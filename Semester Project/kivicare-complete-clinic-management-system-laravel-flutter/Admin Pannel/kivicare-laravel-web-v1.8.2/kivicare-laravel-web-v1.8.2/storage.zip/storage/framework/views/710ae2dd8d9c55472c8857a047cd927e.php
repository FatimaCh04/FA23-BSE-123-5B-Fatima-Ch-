<div class="d-flex gap-3 align-items-center">
   
<?php if(Auth::user()->can('delete_reviews')): ?>
        <a href="<?php echo e(route('backend.doctor.destroy_review', $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="fs-4 text-danger" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->user->full_name) ?? __('Unknown'), 'module' => __('clinic.reviews')])); ?>">  <i class="ph ph-trash align-middle"></i></a>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/doctor/review_action_column.blade.php ENDPATH**/ ?>