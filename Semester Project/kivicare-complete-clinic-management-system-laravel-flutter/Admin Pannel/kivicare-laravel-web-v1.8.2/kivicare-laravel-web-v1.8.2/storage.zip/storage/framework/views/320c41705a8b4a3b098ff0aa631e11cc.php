<?php $__env->startSection('title'); ?>
    <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-content">
    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="d-flex flex-wrap gap-3">
        <?php if(auth()->user()->can('edit_doctors') || auth()->user()->can('delete_doctors')): ?>
            <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route("backend.$module_name.bulk_action")).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route("backend.$module_name.bulk_action")).'']); ?>
                <div class="">
                    <select name="action_type" class="form-select col-12" id="quick-action-type">
                        <option value=""><?php echo e(__('messages.no_action')); ?></option>
                        <?php if(Auth::user()->can('edit_doctors')): ?>
                        <option value="change-status"><?php echo e(__('messages.status')); ?></option>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('delete_doctors')): ?>
                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="select-status d-none quick-action-field" id="change-status-action">
                    <select name="status" class="form-select" id="status">
                        <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
                        <option value="1"><?php echo e(__('messages.active')); ?></option>
                        <option value="0"><?php echo e(__('messages.inactive')); ?></option>
                    </select>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
        <?php endif; ?>
            <div>
                <button type="button" class="btn btn-primary" data-modal="export">
                <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

                </button>
            </div>
        </div>

         <?php $__env->slot('toolbar', null, []); ?> 
            <div>
                <div class="datatable-filter">
                    <select name="column_status" id="column_status" class="form-select"
                        data-filter="select">
                        <option value=""><?php echo e(__('messages.all')); ?></option>
                        <option value="0" <?php echo e($filter['status'] == '0' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.inactive')); ?></option>
                        <option value="1" <?php echo e($filter['status'] == '1' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.active')); ?></option>
                    </select>
                </div>
            </div>
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i
                        class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..."
                    aria-label="Search" aria-describedby="addon-wrapping">
            </div>

            <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"><i class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?></button>

            
            <button type="button"
                class="btn btn-primary d-inline-flex align-items-center gap-2 px-3 py-2 rounded"
                data-mode="create"
                data-bs-toggle="offcanvas"
                data-bs-target="#form-offcanvas"
                id="create-doctor-btn">
                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" fill="none"
                viewBox="0 0 24 24" stroke="white" stroke-width="2">
                <circle cx="12" cy="12" r="9" stroke="white"/>
                <path d="M12 8v8M8 12h8" stroke-linecap="round"/>
                </svg>
                <?php echo e(__('messages.new')); ?>

            </button>

            <!-- Offcanvas -->
            <div class="offcanvas offcanvas-end offcanvas-w-40"
                tabindex="-1"
                id="form-offcanvas"
                aria-labelledby="form-offcanvas-label">

                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="form-offcanvas-label">
                        <span id="offcanvas-title"><?php echo e(__('messages.create')); ?> <?php echo e(__('clinic.doctor_title')); ?></span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body p-3 offcanvas-body-wide">
                    
                    <form id="doctor-form" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('clinic::backend.doctor.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </form>
                </div>
            </div>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>

    <table id="datatable" class="table table-responsive"></table>
</div>

<div data-render="app">

    
    
    <?php echo $__env->make('clinic::backend.doctor.doctor-details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <clinic-list-form-offcanvas></clinic-list-form-offcanvas>
    <employee-slot-mapping-form-offcanvas></employee-slot-mapping-form-offcanvas>
    <?php echo $__env->make('clinic::backend.doctor.change-password', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <customform-offcanvas>
    </customform-offcanvas>

    <div data-render="app">
    <div class="offcanvas offcanvas-end offcanvas-w-40"
        tabindex="-1"
        id="doctor--form-offcanvas"
        aria-labelledby="doctorSessionsLabel">
    <div class="offcanvas-header border-bottom">
        <h6 class="m-0 h5" id="doctorSessionsLabel"><?php echo e(__('clinic.doctor_sessions')); ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0">
        <?php echo $__env->make('clinic::backend.doctor.doctor-session-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    </div>

    <send-push-notification create-title="<?php echo e(__('clinic.send_push_notification')); ?>"></send-push-notification>
</div>
<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
     <?php $__env->endSlot(); ?>
    <?php if (! (auth()->user()->hasRole('doctor'))): ?>
    <div class="form-group datatable-filter">
        <label class="form-label" for="doctor_name"><?php echo e(__('clinic.doctor_name')); ?></label>
        <input type="text" name="doctor_name" id="doctor_name" class="form-control" placeholder="<?php echo e(__('clinic.doctors')); ?>">

      
    </div>
    <div class="form-group datatable-filter">
        <label class="form-label" for="email"><?php echo e(__('clinic.lbl_Email')); ?></label>
        <input type="text" name="email" id="email" class="form-control" placeholder="<?php echo e(__('clinic.Emails')); ?>">
      
    </div>
    <div class="form-group datatable-filter">
        <label class="form-label" for="contact"><?php echo e(__('clinic.lbl_contact_number')); ?></label>
        <input type="text" name="contact" id="contact" class="form-control" placeholder="<?php echo e(__('clinic.contact_numbers')); ?>">
      
    </div>
    
    <div class="form-group datatable-filter">
        <label class="form-label w-100" for="column_clinic"><?php echo e(__('clinic.lbl_gender')); ?></label>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="male" value="male" data-filter="select"/> 
            <label class="form-check-label" for="male"> <?php echo e(__('clinic.lbl_male')); ?> </label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="female" value="female" data-filter="select"/>
            <label class="form-check-label" for="female"> <?php echo e(__('clinic.lbl_female')); ?> </label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="intersex" value="intersex" data-filter="select"/>
            <label class="form-check-label" for="intersex"> <?php echo e(__('Intersex')); ?> </label>
        </div>
    </div>
    <?php endif; ?>
    <?php if (! (auth()->user()->hasRole('receptionist'))): ?>
    <div class="form-group datatable-filter">
        <label class="form-label" for="column_clinic"><?php echo e(__('clinic.lbl_clinic')); ?></label>
        <select name="column_clinic" id="column_clinic" class="form-control">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('clinic.singular_title')); ?></option>
        </select>
    </div>
    <?php endif; ?>
    <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
    <div class="form-group datatable-filter">
        <label class="form-label" for="vendor"><?php echo e(__('clinic.clinic_admin')); ?></label>
        <select name="vendor" id="vendor" class="form-control">
            <option value=""><?php echo e(__('service.all')); ?> <?php echo e(__('clinic.clinic_admin')); ?></option>
        </select>
    </div> 
    <?php endif; ?>
    <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('appointment.reset')); ?></button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<style>
    /* Force hide search box for clinic and vendor Select2 */
    .select2-container--default .select2-search--dropdown {
        display: none !important;
    }
    
    .select2-container--default .select2-search--dropdown .select2-search__field {
        display: none !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/clinic/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>
<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>
<script type="text/javascript" defer>
    const columns = [{
            name: 'check',
            data: 'check',
            title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
            width: '0%',
            exportable: false,
            orderable: false,
            searchable: false,
        },
        {
            data: 'doctor_id',
            name: 'doctor_id',
            title: "<?php echo e(__('clinic.lbl_name')); ?>",
            orderable: true,
            searchable: true,
        },

        {
            data: 'mobile',
            name: 'mobile',
            title: "<?php echo e(__('clinic.lbl_phone_number')); ?>"
        },
        {
            data: 'gender',
            name: 'gender',
            title: "<?php echo e(__('clinic.lbl_gender')); ?>"
        },

        <?php if (! (auth()->user()->hasRole('receptionist'))): ?>
        {
            data: 'clinic_id',
            name: 'clinic_id',
            title: "<?php echo e(__('clinic.lbl_clinic_center')); ?>",
            orderable: false,
            searchable: false,
        },
        <?php endif; ?>
        {
            data: 'email_verified_at',
            name: 'email_verified_at',
            orderable: false,
            searchable: false,
            title: "<?php echo e(__('clinic.lbl_verification_status')); ?>"
        },



        <?php if(auth()->user()->can('edit_doctors')): ?>

        {
            data: 'status',
            name: 'status',
            orderable: true,
            searchable: true,
            title: "<?php echo e(__('clinic.lbl_status')); ?>"
        },

        <?php endif; ?>

        {
            data: 'updated_at',
            name: 'updated_at',
            width: '15%',
            visible: false
        },
    ]

      const actionColumn = [{
        data: 'action',
        name: 'action',
        width:'5%',
        orderable: false,
        searchable: false,
        title: "<?php echo e(__('clinic.lbl_action')); ?>"
    }]

    const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)

    let finalColumns = [
        ...columns,
        ...customFieldColumns,
        ...actionColumn

    ]
    document.addEventListener('DOMContentLoaded', (event) => {
        // Initialize Select2 for all select elements
        $('#quick-action-type').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        $('#status').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        $('#column_status').select2({
            width: '100%',
            minimumResultsForSearch: Infinity,
        });

        let selectedGender = null;

        // Initialize datatable first
        initDatatable({
            url: '<?php echo e(route("backend.$module_name.index_data")); ?>',
            finalColumns,
            orderColumn: [[ 6, 'desc' ]],
            advanceFilter: () => {
                const doctorNameFilter = $('#doctor_name').val();
                const emailFilter = $('#email').val();
                const contactFilter = $('#contact').val();
                return {
                    clinic_name: $('#column_clinic').val(),
                    doctor_name: doctorNameFilter,
                    contact : contactFilter,
                    email : emailFilter,
                    vendor_id : $('#vendor').val(),
                    gender: selectedGender
                }
            }
        });

        // Destroy any existing Select2 on clinic filter before re-initializing
        if ($('#column_clinic').hasClass('select2-hidden-accessible')) {
            $('#column_clinic').select2('destroy');
        }
        
        // Initialize Select2 for clinic filter with AJAX but NO search box
        $('#column_clinic').select2({
            width: '100%',
            placeholder: '<?php echo e(__("service.all")); ?> <?php echo e(__("clinic.singular_title")); ?>',
            allowClear: false,
            minimumResultsForSearch: Infinity,  // Hide search box
            ajax: {
                url: '<?php echo e(route("backend.doctor.get-clinics")); ?>',
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        search: '',  // No search term
                        page: params.page || 1
                    };
                },
                processResults: function (data, params) {
                    params.page = params.page || 1;
                    return {
                        results: data.results,
                        pagination: {
                            more: data.pagination.more
                        }
                    };
                },
                cache: true
            }
        });

        // Destroy any existing Select2 on vendor filter before re-initializing
        if ($('#vendor').hasClass('select2-hidden-accessible')) {
            $('#vendor').select2('destroy');
        }
        
        // Initialize Select2 for vendor filter with AJAX but NO search box
        $('#vendor').select2({
            width: '100%',
            placeholder: '<?php echo e(__("service.all")); ?> <?php echo e(__("clinic.clinic_admin")); ?>',
            allowClear: false,
            minimumResultsForSearch: Infinity,  // Hide search box
            ajax: {
                url: '<?php echo e(route("backend.doctor.get-vendors")); ?>',
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        search: '',  // No search term
                        page: params.page || 1
                    };
                },
                processResults: function (data, params) {
                    params.page = params.page || 1;
                    return {
                        results: data.results,
                        pagination: {
                            more: data.pagination.more
                        }
                    };
                },
                cache: true
            }
        });

        // Add event handlers for filters
        $('#doctor_name').on('input', function() {
            window.renderedDataTable.ajax.reload(null, false);
        });
        
        $('#email').on('input', function() {
            window.renderedDataTable.ajax.reload(null, false);
        });
        
        $('#contact').on('input', function() {
            window.renderedDataTable.ajax.reload(null, false);
        });

        // Gender filter change handler
        $('input[name="gender"]').change(function() {
            selectedGender = $(this).val();
            window.renderedDataTable.ajax.reload(null, false);
        });

        // Trigger datatable reload on clinic/vendor filter change
        $('#column_clinic').on('change', function() {
            window.renderedDataTable.ajax.reload(null, false);
        });

        $('#vendor').on('change', function() {
            window.renderedDataTable.ajax.reload(null, false);
        });

        // Reset filter handler
        $('#reset-filter').on('click', function(e) {
            e.preventDefault();
            
            // Reset Select2 filters without triggering change event
            $('#column_clinic').val(null).trigger('change.select2');
            $('#vendor').val(null).trigger('change.select2');
            
            // Reset text inputs
            $('#doctor_name, #contact, #email').val('');
            
            // Reset gender radio buttons
            $('input[name="gender"]').prop('checked', false); 
            selectedGender = null; 
            
            // Reload datatable once
            window.renderedDataTable.ajax.reload(null, false);
        });
    });

    function resetQuickAction() {
        const actionValue = $('#quick-action-type').val();
        if (actionValue != '') {
            $('#quick-action-apply').removeAttr('disabled');

            if (actionValue == 'change-status') {
                $('.quick-action-field').addClass('d-none');
                $('#change-status-action').removeClass('d-none');
            } else {
                $('.quick-action-field').addClass('d-none');
            }
        } else {
            $('#quick-action-apply').attr('disabled', true);
            $('.quick-action-field').addClass('d-none');
        }
    }

    $('#quick-action-type').change(function() {
        resetQuickAction()
    });

    $(document).on('update_quick_action', function() {
        // resetActionButtons()
    })

    function dispatchCustomEvent(button) {
        const event = new CustomEvent('custom_form_assign', {
            detail: {
            appointment_type: button.getAttribute('data-appointment-type'),
            appointment_id: button.getAttribute('data-appointment-id'),
            form_id: button.getAttribute('data-form-id')
            }
        });

        document.dispatchEvent(event);

        const offcanvasSelector = button.getAttribute('data-assign-target');
        const offcanvasElement = document.querySelector(offcanvasSelector);
        if(offcanvasElement){
            const offcanvas = new bootstrap.Offcanvas(offcanvasElement);
            offcanvas.show();
        }
    }
</script>
<?php $__env->stopPush(); ?>



 
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/doctor/index.blade.php ENDPATH**/ ?>