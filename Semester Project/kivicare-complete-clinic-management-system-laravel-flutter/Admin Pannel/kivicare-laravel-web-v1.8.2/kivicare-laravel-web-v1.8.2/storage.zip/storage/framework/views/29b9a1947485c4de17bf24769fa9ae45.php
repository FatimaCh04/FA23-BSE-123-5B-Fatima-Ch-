<?php if(isset($data->appointmenttransaction)): ?>
    <?php if($data->appointmenttransaction->payment_status == 1): ?>
        <span class="text-capitalize badge bg-success-subtle p-2"><?php echo e(getLocalizedPaymentStatus($data->appointmenttransaction->payment_status)); ?></span>
    <?php elseif(optional($data->appointmenttransaction)->payment_status == 0 && optional($data->appointmenttransaction)->advance_payment_status == 1): ?>
        <span class="text-capitalize badge bg-info-subtle p-2"><?php echo e(getLocalizedPaymentStatus(5)); ?></span>
    <?php else: ?>
        <select name="branch_for" class="select2 change-select" data-token="<?php echo e(csrf_token()); ?>"
            data-url="<?php echo e(route('backend.appointments.updatePaymentStatus', ['id' => $data->id, 'action_type' => 'update-payment-status'])); ?>"
            style="width: 100%;" <?php echo e($data->status !== 'checkout' ? 'disabled' : ''); ?>>
            <?php
                $localizedPaymentStatuses = getLocalizedPaymentStatuses();
            ?>
            <?php $__currentLoopData = $localizedPaymentStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($status['value'] != 5): ?> 
                    <option value="<?php echo e($status['value']); ?>" <?php echo e(optional($data->appointmenttransaction)->payment_status == $status['value'] ? 'selected' : ''); ?>>
                        <?php echo e($status['name']); ?>

                    </option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php endif; ?> 
<?php else: ?>
<span class="text-capitalize badge bg-danger-subtle p-3"><?php echo e(getLocalizedPaymentStatus(2)); ?></span>
<?php endif; ?> <?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/appointment/datatable/select_payment_status.blade.php ENDPATH**/ ?>