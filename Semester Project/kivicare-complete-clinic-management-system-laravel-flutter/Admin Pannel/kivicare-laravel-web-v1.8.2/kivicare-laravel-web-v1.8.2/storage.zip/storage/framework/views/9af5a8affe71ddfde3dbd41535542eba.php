<?php $__env->startSection('title'); ?> <?php echo e(__($module_title)); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-content mb-3">
    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="d-flex flex-wrap gap-3">

        
           <?php
            $permissionsToCheck = ['edit_clinics_center', 'delete_clinics_service'];
           ?>

           <?php if(collect($permissionsToCheck)->contains(fn ($permission) => auth()->user()->can($permission))): ?>

            <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route('backend.clinics.bulk_action')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route('backend.clinics.bulk_action')).'']); ?>
                <div class="">
                    <select name="action_type" class="select2 form-select col-12" id="quick-action-type"
                        style="width:100%">
                        <option value=""><?php echo e(__('messages.no_action')); ?></option>
                        <?php if(Auth::user()->can('edit_clinics_center')): ?>
                        <option value="change-status"><?php echo e(__('messages.status')); ?></option>
                        <?php endif; ?>

                        <?php if(Auth::user()->can('delete_clinics_service')): ?>
                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="select-status d-none quick-action-field" id="change-status-action">
                    <select name="status" class="select2 form-select" id="status" style="width:100%">
                        <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
                        <option value="1" ><?php echo e(__('messages.active')); ?></option>
                        <option value="0"><?php echo e(__('messages.inactive')); ?></option>
                    </select>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
        <?php endif; ?>
            <div>
                <button type="button" class="btn btn-primary" data-modal="export">
                <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

                </button>
            </div>
        </div>
         <?php $__env->slot('toolbar', null, []); ?> 

            <div>
                <div class="datatable-filter">
                    <select name="column_status" id="column_status" class="select2 form-select"
                        data-filter="select" style="width: 100%">
                        <option value=""><?php echo e(__('messages.all')); ?></option>
                        <option value="0" <?php echo e($filter['status'] == '0' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.inactive')); ?></option>
                        <option value="1" <?php echo e($filter['status'] == '1' ? 'selected' : ''); ?>>
                            <?php echo e(__('messages.active')); ?></option>
                    </select>
                </div>
            </div>
                
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i
                        class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..." aria-label="Search"
                    aria-describedby="addon-wrapping">
            </div>
            <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"><i class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?></button>
            <?php if(Auth::user()->can('add_clinics_center')): ?>
                <?php if (isset($component)) { $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.buttons.offcanvas','data' => ['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__('clinic.singular_title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buttons.offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '#form-offcanvas','title' => ''.e(__('messages.create')).' '.e(__('clinic.singular_title')).'']); ?>
                <?php echo e(__('messages.new')); ?>   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $attributes = $__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__attributesOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8)): ?>
<?php $component = $__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8; ?>
<?php unset($__componentOriginalabb0b1ddc4ac4df74eba9fcbd7f771f8); ?>
<?php endif; ?>
            <?php endif; ?>

         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
    <table id="datatable" class="table table-responsive">
    </table>
</div>


<?php echo $__env->make('clinic::backend.clinic.form_offcanvas', [
    'clinic' => null,
    'vendors' => $vendors,
    'systemservicecategories' => $systemservicecategories,
    'countries' => $countries,
    'states' => $states,
    'cities' => $cities,
    'customfields' => $customfields
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div data-render="app">
     <clinic-gallery-offcanvas></clinic-gallery-offcanvas>
   <div id="clinic-session-offcanvas-container"></div>
    <div id="clinic-details-offcanvas-container"></div>
</div>

<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
     <?php $__env->endSlot(); ?>

     

     <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>

    <div class="form-group datatable-filter">
        <label class="form-label" for="form-label"><?php echo e(__('clinic.clinic_admin')); ?></label>
        <select  id="column_clinic_admin" name="column_clinic_admin" data-filter="select"
            class="select2 form-select"
            data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'clinic_admin'])); ?>"
            data-ajax--cache="true" data-placeholder="<?php echo e(__('clinic.select_clinic_admin')); ?>">
        </select>
    </div>

    <?php endif; ?>

     <div class="form-group datatable-filter">
         <label class="form-label" for="form-label"> <?php echo e(__('clinic.speciality')); ?></label>
         <select  id="column_category" name="column_category" data-filter="select"
             class="select2 form-select"
             data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'system_category'])); ?>"
             data-ajax--cache="true" data-placeholder="<?php echo e(__('clinic.specialization_list')); ?>">
         </select>
     </div>

     <div class="form-group datatable-filter">
         <label class="form-label" for="form-label"> <?php echo e(__('clinic.country')); ?></label>
         <select  id="column_country" name="column_country" data-filter="select"
             class="select2 form-select"
             data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'country'])); ?>"
             data-ajax--cache="true" data-placeholder="<?php echo e(__('clinic.select_country')); ?>">
         </select>
     </div>

     <div class="form-group datatable-filter">
         <label class="form-label" for="form-label"> <?php echo e(__('clinic.state')); ?></label>
         <select  id="column_state" name="column_state" data-filter="select"
             class="select2 form-select"
             data-placeholder="<?php echo e(__('clinic.select_state')); ?>">
         </select>
     </div>

     <div class="form-group datatable-filter">
         <label class="form-label" for="form-label"> <?php echo e(__('clinic.city')); ?></label>
         <select  id="column_city" name="column_city" data-filter="select"
             class="select2 form-select"
             data-placeholder="<?php echo e(__('clinic.select_city')); ?>">
         </select>
     </div>

    <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('appointment.reset')); ?></button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-styles'); ?>

<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/clinic/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>

<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
    const columns = [
             <?php if (! (auth()->user()->hasRole('doctor'))): ?>
             {
                 name: 'check',
                 data: 'check',
                 title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
                 width: '0%',
                 exportable: false,
                 orderable: false,
                 searchable: false,
             },
             <?php endif; ?>
             {
                 data: 'updated_at',
                 name: 'updated_at',
                 width: '15%',
                 visible: false
             },
             {
                 data: 'clinic_name',
                 name: 'clinic_name',
                 title: "<?php echo e(__('clinic.lbl_name')); ?>"
             },
 
             {
                 data: 'system_service_category',
                 name: 'system_service_category',
                 title: "<?php echo e(__('clinic.speciality')); ?>"
             },
             <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
             {
                 data: 'vendor_id',
                 name: 'vendor_id',
                 title: "<?php echo e(__('clinic.clinic_admin')); ?>"
             },
             <?php endif; ?>
             {
                 data: 'contact_number',
                 name: 'contact_number',
                 title: "<?php echo e(__('clinic.lbl_contact_number')); ?>"
             },
             { 
                 data: 'description',
                 name: 'description',
                 title: "<?php echo e(__('clinic.lbl_description')); ?>",
                 className: 'description-column'
             },
             <?php if (! (auth()->user()->hasRole('doctor'))): ?>
                {
                    data: 'status',
                    name: 'status',
                    orderable: false,
                    searchable: true,
                    title: "<?php echo e(__('clinic.status')); ?>",
                    width: '5%'
                },
             <?php endif; ?>
     ]
 
     const actionColumn = [{
         data: 'action',
         name: 'action',
         orderable: false,
         searchable: false,
         title: "<?php echo e(__('service.lbl_action')); ?>",
         width: '5%'
     }]
     const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)
 
     let finalColumns = [
         ...columns,
         ...customFieldColumns,
         ...actionColumn
     ]
 
    document.addEventListener('DOMContentLoaded', (event) => {
        // Initialize Select2 for bulk action and status dropdowns
        if (window.jQuery && $.fn.select2) {
            // Bulk action dropdown
            $('#quick-action-type').select2({
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: "<?php echo e(__('messages.no_action')); ?>"
            });

            // Status dropdown inside bulk action
            $('#status').select2({
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: "<?php echo e(__('messages.select_status')); ?>"
            });

            // Status filter dropdown
            $('#column_status').select2({
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: "<?php echo e(__('messages.all')); ?>"
            });

            // Initialize Select2 for advance filter dropdowns with AJAX
            <?php if(multiVendor() && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
            $('#column_clinic_admin').select2({
                width: '100%',
                placeholder: "<?php echo e(__('clinic.select_clinic_admin')); ?>",
                allowClear: true,
                minimumResultsForSearch: 0, // Enable search
                ajax: {
                    url: "<?php echo e(route('backend.get_search_data', ['type' => 'clinic_admin'])); ?>",
                    dataType: 'json',
                    delay: 250,
                    cache: true,
                    data: function (params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results,
                            pagination: data.pagination
                        };
                    }
                },
                dropdownParent: $('#offcanvasExample')
            });
            <?php endif; ?>

            $('#column_category').select2({
                width: '100%',
                placeholder: "<?php echo e(__('clinic.specialization_list')); ?>",
                allowClear: true,
                minimumResultsForSearch: 0, // Enable search
                ajax: {
                    url: "<?php echo e(route('backend.get_search_data', ['type' => 'system_category'])); ?>",
                    dataType: 'json',
                    delay: 250,
                    cache: true,
                    data: function (params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results,
                            pagination: data.pagination
                        };
                    }
                },
                dropdownParent: $('#offcanvasExample')
            });

            $('#column_country').select2({
                width: '100%',
                placeholder: "<?php echo e(__('clinic.select_country')); ?>",
                allowClear: true,
                minimumResultsForSearch: 0, // Enable search
                ajax: {
                    url: "<?php echo e(route('backend.get_search_data', ['type' => 'country'])); ?>",
                    dataType: 'json',
                    delay: 250,
                    cache: true,
                    data: function (params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results,
                            pagination: data.pagination
                        };
                    }
                },
                dropdownParent: $('#offcanvasExample')
            });

            // State and City are populated dynamically via cascade, initialized in stateName() and cityName() functions
        }

        initDatatable({
            url: '<?php echo e(route("backend.clinics.index_data")); ?>',
            finalColumns,
            orderColumn: [
                <?php if(auth()->user()->hasRole('doctor')): ?>
                [0, "desc"]
                <?php else: ?>
                [1, "desc"]
                <?php endif; ?>
            ],
            advanceFilter: () => {
                return {
                    // clinic_name: $('#clinic_name').val(), // Commented out since field is disabled
                    category_name: $('#column_category').val(),
                    clinic_admin: $('#column_clinic_admin').val(),
                    country: $('#column_country').val(),
                    state: $('#column_state').val(),
                    city: $('#column_city').val()
                };
            }
        });

        // Reset filter button functionality
        $('#reset-filter').on('click', function(e) {
            $('#column_category, #column_clinic_admin, #column_country, #column_state, #column_city')
                .val(null).trigger('change'); // clear Select2 properly
            window.renderedDataTable.ajax.reload(null, false);
        });
    });
 
 
     function resetQuickAction () {
         const actionValue = $('#quick-action-type').val();
         if (actionValue != '') {
             $('#quick-action-apply').removeAttr('disabled');
 
             if (actionValue == 'change-status') {
                 $('.quick-action-field').addClass('d-none');
                 $('#change-status-action').removeClass('d-none');
             } else {
                 $('.quick-action-field').addClass('d-none');
             }
         } else {
             $('#quick-action-apply').attr('disabled', true);
             $('.quick-action-field').addClass('d-none');
         }
     }
 
     $('#quick-action-type').change(function () {
         resetQuickAction()
     });
 
     $(document).on('update_quick_action', function() {
         // resetActionButtons()
     })
 
 
     // Country -> State cascade
     $(document).on('change', '#column_country', function() {
         var country = $(this).val();
         $('#column_state').empty().trigger('change');
         $('#column_city').empty().trigger('change');
         if (country) stateName(country);
     });
 
     // State -> City cascade
     $(document).on('change', '#column_state', function() {
         var state = $(this).val();
         $('#column_city').empty().trigger('change');
         if (state) cityName(state);
     });
 
     // Load states
     function stateName(country) {
         var $state = $('#column_state');
         var state_route = "<?php echo e(route('backend.get_search_data', [ 'type' => 'state','sub_type' =>''])); ?>" + country;
         state_route = state_route.replace('amp;', '');
         $.ajax({
             url: state_route,
             success: function(result) {
                 if ($state.data('select2')) {
                     $state.select2('destroy');
                 }
                 $state.empty();
                 $state.append('<option value=""><?php echo e(__("clinic.select_state")); ?></option>');
                 $.each(result.results, function(index, st) {
                     $state.append(new Option(st.text, st.id, false, false));
                 });
                 $state.select2({
                     width: '100%',
                     placeholder: "<?php echo e(__('clinic.select_state')); ?>",
                     allowClear: false,
                     minimumResultsForSearch: 0, // Enable search always
                     dropdownParent: $('#offcanvasExample') // Ensure proper dropdown positioning
                 });
             }
         });
     }
 
     // Load cities
     function cityName(state) {
         var $city = $('#column_city');
         var city_route = "<?php echo e(route('backend.get_search_data', [ 'type' => 'city','sub_type' =>''])); ?>" + state;
         city_route = city_route.replace('amp;', '');
         $.ajax({
             url: city_route,
             success: function(result) {
                 if ($city.data('select2')) {
                     $city.select2('destroy');
                 }
                 $city.empty();
                 $city.append('<option value=""><?php echo e(__("clinic.select_city")); ?></option>');
                 $.each(result.results, function(index, ct) {
                     $city.append(new Option(ct.text, ct.id, false, false));
                 });
                 $city.select2({
                     width: '100%',
                     placeholder: "<?php echo e(__('clinic.select_city')); ?>",
                     allowClear: false,
                     minimumResultsForSearch: 0, // Enable search always
                     dropdownParent: $('#offcanvasExample') // Ensure proper dropdown positioning
                 });
             }
         });
     }
 
     const baseUrl = "<?php echo e(url('/')); ?>";
 
     function editClinic(clinicId) {
         $.ajax({
             url: baseUrl + '/app/clinics/' + clinicId + '/edit',
             type: 'GET',
             success: function(response) {
                 $('#form-offcanvas').remove();
                 $('body').append(response);
                 var offcanvas = document.getElementById('form-offcanvas');
                 if (offcanvas) {
                     var bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
                     bsOffcanvas.show();
                 }
             },
             error: function() {
                 alert('<?php echo e(__("clinic.error_loading_clinic_data")); ?>');
             }
         });
     }
 
     $(document).on('click', '[data-assign-event="clinic-details"]', function() {
         var clinicId = $(this).data('assign-module');
         $.ajax({
             url: baseUrl + '/app/clinics/clinic-details/' + clinicId,
             type: 'GET',
             success: function(response) {
                 $('#clinicDetails-offcanvas').remove();
                 $('#clinic-details-offcanvas-container').html(response);
                 var offcanvas = document.getElementById('clinicDetails-offcanvas');
                 if (offcanvas) {
                     var bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
                     bsOffcanvas.show();
                 }
             }
         });
     });
 
     $(document).on('click', '[data-assign-event="clinic-session"]', function() {
         var clinicId = $(this).data('assign-module');
         $.ajax({
             url: baseUrl + '/app/clinics/clinic-session/' + clinicId,
             type: 'GET',
             success: function(response) {
                 $('#clinic-session-detail').remove();
                 $('#clinic-session-offcanvas-container').html(response);
                 var offcanvas = document.getElementById('clinic-session-detail');
                 if (offcanvas) {
                     var bsOffcanvas = new bootstrap.Offcanvas(offcanvas, { backdrop: false });
                     bsOffcanvas.show();
                 }
             }
         });
     });

     // Debug: Test AJAX endpoints when advance filter opens
     $(document).on('shown.bs.offcanvas', '#offcanvasExample', function() {
         console.log('Advance filter opened');
         
         // Test AJAX endpoints
         $('#offcanvasExample .select2').each(function() {
             var $select = $(this);
             var ajaxUrl = $select.data('ajax--url');
             var selectId = $select.attr('id');
             
             console.log('Select ID:', selectId);
             console.log('AJAX URL:', ajaxUrl);
             
             if (ajaxUrl) {
                 // Test the AJAX endpoint
                 $.ajax({
                     url: ajaxUrl,
                     dataType: 'json',
                     data: { q: '', page: 1 },
                     success: function(data) {
                         console.log('AJAX Success for', selectId, ':', data);
                     },
                     error: function(xhr, status, error) {
                         console.error('AJAX Error for', selectId, ':', error, xhr.responseText);
                     }
                 });
             }
         });
     });
  </script>
<?php $__env->stopPush(); ?>
    
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/clinic/index_datatable.blade.php ENDPATH**/ ?>