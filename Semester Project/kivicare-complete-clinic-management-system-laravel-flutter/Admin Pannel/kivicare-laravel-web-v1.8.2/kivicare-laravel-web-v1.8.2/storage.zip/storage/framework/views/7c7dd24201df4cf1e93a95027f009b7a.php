<?php $__env->startSection('title'); ?>
<?php echo e($module_title); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('after-styles'); ?>
<link rel="stylesheet" href="<?php echo e(mix('modules/service/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0"><?php echo e(__('dashboard.lbl_title_appointment_overview')); ?></h3>
            <div class="d-flex  align-items-center">
                <form action="" class="d-flex align-items-center gap-2">
                    <div class="form-group my-0 ms-3">
                        <input type="text"  name="appointment_date" id="appointment_date" value="" class="booking-date-range form-control" placeholder="<?php echo e(__('setting_sidebar.select_date')); ?>" readonly="readonly">  
                    </div>
                    <button id="reset" class="btn bg-primary rounded" data-bs-toggle="tooltip" title="Reset"> <i class="ph ph-circle-notch"></i> </button>
                    <!-- <button type="submit" name="action" value="filter" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('messages.submit_date_filter')); ?>"><?php echo e(__('dashboard.lbl_filter')); ?></button> -->
                </form>
            </div>
        </div>

    </div>
</div>
<div>
    <table id="datatable" class="table table-responsive">
    </table>
</div>
<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4>Advanced Filter</h4>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
    const range_flatpicker = document.querySelectorAll('.booking-date-range')
    Array.from(range_flatpicker, (elem) => {
        if (typeof flatpickr !== typeof undefined) {
            flatpickr(elem, {
                mode: "range",
                dateFormat: "d-m-Y",
            })
        }
    })

    $('#reset').on('click', function(e) {
        $('#appointment_date').val('');
        window.renderedDataTable.ajax.reload(null, false);
    });
    const columns = [{
            data: 'id',
            name: 'id',
            title: "<?php echo e(__('report.lbl_inv_no')); ?>",
            orderable: false,
            searchable: false
        },
        {
            data: 'user_id',
            name: 'user_id',
            title: "<?php echo e(__('sidebar.patient')); ?>",
            orderable: false,
        },
        {
            data: 'clinic_id',
            name: 'clinic_id',
            title: "<?php echo e(__('clinic.singular_title')); ?>",
        },
        {
            data: 'doctor_id',
            name: 'doctor_id',
            title: "<?php echo e(__('appointment.lbl_doctor')); ?>",
        },
        {
            data: 'status',
            name: 'status',
            title: "<?php echo e(__('appointment.singular_title')); ?> <?php echo e(__('appointment.lbl_status')); ?>",
        },
        {
            data: 'payment_status',
            name: 'payment_status',
            title: "<?php echo e(__('report.lbl_payment_status')); ?>",
            orderable: false,
        },
        {
            data: 'service_amount',
            name: 'service_amount',
            title: "<?php echo e(__('report.lbl_price')); ?>",
        },
        {
            data: 'total_amount',
            name: 'total_amount',
            title: "<?php echo e(__('clinic.total')); ?>",
        },
        {
            data: 'start_date_time',
            name: 'start_date_time',
            title: "<?php echo e(__('report.lbl_date')); ?>",
            width: '10%'
        },
        {
                data: 'updated_at',
                name: 'updated_at',
                title: "<?php echo e(__('service.lbl_update_at')); ?>",
                orderable: true,
                visible: false,
            },
        
    ]

    let finalColumns = [
        ...columns
    ]

    $('#appointment_date').on('change', function() {
        window.renderedDataTable.ajax.reload(null, false)
    })

    document.addEventListener('DOMContentLoaded', (event) => {
        initDatatable({
            url: '<?php echo e(route('backend.reports.appointment-overview.index_data')); ?>',
            finalColumns,
            orderColumn: [[ 9, 'desc' ]],
            advanceFilter: () => {
                return {
                    appointment_date: $('#appointment_date').val(),

                }
            }
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', ['isNoUISlider' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\resources\views/backend/reports/appointment-overview.blade.php ENDPATH**/ ?>