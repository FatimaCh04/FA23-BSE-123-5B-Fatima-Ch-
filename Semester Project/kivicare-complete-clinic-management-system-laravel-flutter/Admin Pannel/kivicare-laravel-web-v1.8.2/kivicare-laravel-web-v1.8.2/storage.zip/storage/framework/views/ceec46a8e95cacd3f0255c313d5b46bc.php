<div class="d-flex gap-3 align-items-center">
    <!-- Offcanvas Trigger Button -->
    <button type="button"
            class="btn p-0 fs-6 text-primary"
            data-bs-toggle="offcanvas"
            data-bs-target="#doctor--form-offcanvas"
            data-doctor-id="<?php echo e($data->id); ?>"
            onclick="document.getElementById('doctor_id').value='<?php echo e($data->id); ?>';"
            title="<?php echo e(__('clinic.session')); ?>">
        <i class="ph ph-clock-user"></i>
    </button>



    

    <button type="button"
        class="btn text-danger p-0 fs-6"
        data-bs-toggle="offcanvas"
        data-bs-target="#doctor-details-form-offcanvas"
        data-doctor-id="<?php echo e($data->id); ?>"
        data-url="<?php echo e(route('backend.doctor.doctor.detail', ['id' => $data->id])); ?>"
        title="<?php echo e(__('clinic.view')); ?>"
        onclick="fetchDoctorDetailsAndOpenOffcanvas(this)">
        <i class="ph ph-eye align-middle"></i>
    </button>
    <script>
        function fetchDoctorDetailsAndOpenOffcanvas(btn) {
            var doctorId = btn.getAttribute('data-doctor-id');
            var url = btn.getAttribute('data-url') || ('/app/doctor/detail/' + doctorId); // fallback
            var offcanvasSelector = btn.getAttribute('data-bs-target');
            var offcanvasEl = document.querySelector(offcanvasSelector);

            fetch(url)
            .then(response => response.text())
            .then(html => {
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, 'text/html');
                var newBody = doc.querySelector('.offcanvas-body');
                var targetBody = offcanvasEl.querySelector('.offcanvas-body');
                if (newBody && targetBody) {
                targetBody.innerHTML = newBody.innerHTML;
                } else {
                offcanvasEl.innerHTML = doc.body.innerHTML;
                }
                var bsOffcanvas = bootstrap.Offcanvas.getOrCreateInstance(offcanvasEl);
                bsOffcanvas.show();
            })
            .catch(() => alert('<?php echo e(__("clinic.failed_to_load_doctor_details")); ?>'));
        }
    </script>
    <?php if (! (auth()->user()->hasRole('receptionist'))): ?>  
        
        <button
            type="button"
            class="btn p-0 fs-6 text-info"
            data-bs-toggle="offcanvas"
            data-bs-target="#doctor_change_password"
            data-doctor-id="<?php echo e($data->id); ?>"
            title="<?php echo e(__('employee.change_password')); ?>">
            <i class="ph ph-key align-middle"></i>
        </button>
    <?php endif; ?>
    <?php if(Auth::user()->can('edit_doctors')): ?>
    <button type="button"
            class="btn text-success p-0 fs-5 edit-doctor-btn"
            data-id="<?php echo e($data->id); ?>"
            data-mode="edit"
            data-bs-toggle="offcanvas"
            data-bs-target="#form-offcanvas"
            title="<?php echo e(__('clinic.edit_doctor')); ?>">
        <i class="ph ph-pencil-simple-line align-middle"></i>
    </button>
    <?php endif; ?>

    <?php if(Auth::user()->can('delete_doctors')): ?>
        <a href="<?php echo e(route("backend.$module_name.destroy", $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>" class="btn text-danger p-0 fs-5" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->full_name) ?? __('Unknown'), 'module' => __('appointment.lbl_doctor')])); ?>">
            <i class="ph ph-trash align-middle"></i>
        </a>
    <?php endif; ?>

    <?php if($customform): ?>
        <?php $__currentLoopData = $customform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $formdata=json_decode($form->formdata);
                $clinic= json_decode($form->appointment_status);
            ?>
            <button type="button"
                data-assign-target="#customform-offcanvas"
                data-assign-event="custom_form_assign"
                data-appointment-type="doctor"
                data-appointment-id="<?php echo e($data->id); ?>"
                data-form-id="<?php echo e($form->id); ?>"
                class="btn text-info p-0 fs-5"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="<?php echo e($formdata->form_title); ?>"
                onclick="dispatchCustomEvent(this)">
                <i class="icon ph ph-file align-middle"></i>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/doctor/action_column.blade.php ENDPATH**/ ?>