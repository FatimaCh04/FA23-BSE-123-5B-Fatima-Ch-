<div class="d-flex gap-3 align-items-center">
 <button type='button' data-assign-module="<?php echo e($data->id); ?>" data-assign-event='clinic-session' class='btn text-primary p-0 fs-5' data-bs-toggle='tooltip' title='<?php echo e(__("clinic.session")); ?>'><i class='ph ph-clock-user align-middle'></i></button>
<?php if(Auth::user()->can('clinics_center_gallery')): ?>
<div class="gallery-tooltip" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('clinic.gallery')); ?>">
<button type='button'
   data-gallery-module="<?php echo e($data->id); ?>"
   data-gallery-target='#clinic-gallery-form'
   data-gallery-event='branch_gallery'
   class='btn text-info p-0 fs-5'
   data-bs-toggle="offcanvas"
   data-bs-target="#clinic-gallery-form">
   <i class="ph ph-image align-middle"></i>
</button>
</div>
<?php endif; ?>
<button type='button' data-assign-module="<?php echo e($data->id); ?>" data-assign-event='clinic-details' class='btn text-secondary p-0 fs-5' data-bs-toggle='tooltip' title='<?php echo e(__("clinic.view")); ?>'><i class="ph ph-eye align-middle"></i>
</button>

 <?php if(Auth::user()->can('edit_clinics_center')): ?>
 <button type="button" class="btn text-success p-0 fs-5" onclick="editClinic(<?php echo e($data->id); ?>)" title="<?php echo e(__('messages.edit')); ?> " data-bs-toggle="tooltip"> <i class="ph ph-pencil-simple-line align-middle"></i></button>
 <?php endif; ?>
<?php if(Auth::user()->can('delete_clinics_center')): ?>
    <a href="<?php echo e(route('backend.clinics.destroy', $data->id)); ?>" id="delete-<?php echo e($module_name); ?>-<?php echo e($data->id); ?>"
        class="btn text-danger p-0 fs-5" data-type="ajax" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>"
        data-bs-toggle="tooltip" title="<?php echo e(__('messages.delete')); ?>" data-confirm="<?php echo e(__('messages.are_you_sure?', ['form' => ($data->name) ?? __('Unknown'), 'module' => __('clinic.lbl_clinic')])); ?>">
        <i class="ph ph-trash align-middle"></i></a>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/clinic/action_column.blade.php ENDPATH**/ ?>