<div class="d-flex gap-3 align-items-center">
  <img src="<?php echo e(optional(optional($data->receptionist)->clinics)->file_url ?? '--'); ?>" alt="avatar" class="avatar avatar-40 rounded-pill">
  <div class="text-start">
    <h6 class="m-0"><?php echo e(optional(optional($data->receptionist)->clinics)->name ?? '--'); ?></h6>
    <span><?php echo e(optional(optional($data->receptionist)->clinics)->email ?? '--'); ?></span>
  </div>
</div><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/receptionist/clinic_id.blade.php ENDPATH**/ ?>