<div class="d-flex gap-3 align-items-center">
  <img src="<?php echo e(optional($data->doctor)->profile_image ?? default_user_avatar()); ?>" alt="avatar" class="avatar avatar-40 rounded-pill">
  <div class="text-start">
    <h6 class="m-0">
      <?php if($data->doctor): ?>
        
          <?php echo e($data->doctor->full_name); ?>

        </a>
      <?php else: ?>
        <?php echo e(default_user_name()); ?>

      <?php endif; ?>
    </h6>
    <span><?php echo e(optional($data->doctor)->email ?? '--'); ?></span>
  </div>
</div>
 
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Appointment/Resources/views/backend/clinic_appointment/doctor_id.blade.php ENDPATH**/ ?>