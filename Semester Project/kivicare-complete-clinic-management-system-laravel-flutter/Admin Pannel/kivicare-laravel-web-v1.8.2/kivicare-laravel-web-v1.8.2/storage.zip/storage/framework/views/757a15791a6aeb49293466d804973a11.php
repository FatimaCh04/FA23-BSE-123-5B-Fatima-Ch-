<?php $__env->startSection('title'); ?>
   <?php echo e(__($module_title)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<link rel="stylesheet" href="<?php echo e(mix('modules/clinic/style.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-content mb-5">
    <?php if (isset($component)) { $__componentOriginal57a22d33ea7984d606412297cfe33b67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57a22d33ea7984d606412297cfe33b67 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.section-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.section-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="d-flex flex-wrap gap-3">
            <?php if(auth()->user()->can('edit_clinics_category') || auth()->user()->can('delete_clinics_category')): ?>
            <?php if (isset($component)) { $__componentOriginal9c2603df095322fce98f15251ab0847f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c2603df095322fce98f15251ab0847f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.quick-action','data' => ['url' => ''.e(route("backend.category.bulk_action")).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.quick-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => ''.e(route("backend.category.bulk_action")).'']); ?>
                <div class="">
                    <select name="action_type" class="select2 form-select col-12" id="quick-action-type" style="width:100%">
                        <option value=""><?php echo e(__('messages.no_action')); ?></option>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_clinics_category')): ?>
                        <option value="change-status"><?php echo e(__('messages.status')); ?></option>
                        <option value="change-featured"><?php echo e(__('messages.featured')); ?></option>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_clinics_category')): ?>
                        <option value="delete"><?php echo e(__('messages.delete')); ?></option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="select-status d-none quick-action-field" id="change-status-action">
                    <select name="status" class="select2 form-select" id="status" style="width:100%">
                        <option value="" selected><?php echo e(__('messages.select_status')); ?></option>
                        <option value="1"><?php echo e(__('messages.active')); ?></option>
                        <option value="0"><?php echo e(__('messages.inactive')); ?></option>
                    </select>
                </div>

                <div class="select-featured d-none quick-action-field" id="change-featured-action">
                    <select name="featured" class="select2 form-select" id="featured" style="width:100%">
                        <option value="1"><?php echo e(__('messages.yes')); ?></option>
                        <option value="0"><?php echo e(__('messages.no')); ?></option>
                    </select>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $attributes = $__attributesOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__attributesOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c2603df095322fce98f15251ab0847f)): ?>
<?php $component = $__componentOriginal9c2603df095322fce98f15251ab0847f; ?>
<?php unset($__componentOriginal9c2603df095322fce98f15251ab0847f); ?>
<?php endif; ?>
            <?php endif; ?>
            <div>
                <button type="button" class="btn btn-primary" data-modal="export">
                    <i class="ph ph-export me-1"></i> <?php echo e(__('messages.export')); ?>

                </button>
                
                
                
            </div>
        </div>
         <?php $__env->slot('toolbar', null, []); ?> 
            <div>
                <div class="datatable-filter" style="width: 100%; display: inline-block;">
                    <?php echo e($filter['status']); ?>

                    <select name="column_status" id="column_status" class="select2 form-select" data-filter="select" style="width:100%">
                        <option value="" disabled selected><?php echo e(__('messages.change_status')); ?></option>
                        <option value=""><?php echo e(__('messages.all')); ?></option>
                        <option value="1" <?php echo e($filter['status'] == '1' ? "selected" : ''); ?>><?php echo e(__('messages.active')); ?></option>
                        <option value="0" <?php echo e($filter['status'] == '0' ? "selected" : ''); ?>><?php echo e(__('messages.inactive')); ?></option>
                    </select>
                </div>
            </div>
            <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" class="form-control dt-search" placeholder="<?php echo e(__('messages.search')); ?>..." aria-label="Search" aria-describedby="addon-wrapping">
            </div>
            <!-- <button class="btn btn-secondary d-flex align-items-center gap-1 btn-group" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"><i class="ph ph-funnel"></i><?php echo e(__('messages.advance_filter')); ?></button> -->
            <?php if(Auth::user()->can('add_clinics_category')): ?>
            <button type="button" class="btn btn-primary d-flex align-items-center gap-1" onclick="createNewCategory()"><i class="ph ph-plus-circle"></i> <?php echo e(__('messages.new')); ?> </button>
            <?php endif; ?>

         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $attributes = $__attributesOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__attributesOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57a22d33ea7984d606412297cfe33b67)): ?>
<?php $component = $__componentOriginal57a22d33ea7984d606412297cfe33b67; ?>
<?php unset($__componentOriginal57a22d33ea7984d606412297cfe33b67); ?>
<?php endif; ?>
    <table id="datatable" class="table table-responsive">
    </table>
</div>
    <?php echo $__env->make('clinic::backend.categories.clinic_category_offcanvas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div data-render="app">
</div>
<?php if (isset($component)) { $__componentOriginalda1c96c62b8380f4858a938b2701631b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda1c96c62b8380f4858a938b2701631b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.advance-filter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.advance-filter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <h4><?php echo e(__('service.lbl_advanced_filter')); ?></h4>
     <?php $__env->endSlot(); ?>
    

    <div class="form-group datatable-filter">
        <label class="form-label" for="form-label"> <?php echo e(__('category.lbl_category')); ?></label>
        <select id="clinic_category" name="clinic_category" data-filter="select" class="select2 form-select" data-ajax--url="<?php echo e(route('backend.get_search_data', ['type' => 'clinic_category'])); ?>" data-ajax--cache="true" data-placeholder="<?php echo e(__('category.lbl_category')); ?>">
        </select>
    </div>

   
    <button type="reset" class="btn btn-danger" id="reset-filter"><?php echo e(__('appointment.reset')); ?></button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $attributes = $__attributesOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__attributesOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda1c96c62b8380f4858a938b2701631b)): ?>
<?php $component = $__componentOriginalda1c96c62b8380f4858a938b2701631b; ?>
<?php unset($__componentOriginalda1c96c62b8380f4858a938b2701631b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
<!-- DataTables Core and Extensions -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script src="<?php echo e(mix('modules/clinic/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/form-offcanvas/index.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form-modal/index.js')); ?>" defer></script>


<!-- DataTables Core and Extensions -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatable/datatables.min.js')); ?>"></script>

<script type="text/javascript" defer>
    const columns = [{
            name: 'check',
            data: 'check',
            title: '<input type="checkbox" class="form-check-input" name="select_all_table" id="select-all-table" onclick="selectAllTable(this)">',
            width: '2%',
            exportable: false,
            orderable: false,
            searchable: false,
        },
        {
            data: 'name',
            name: 'name',
            title: "<?php echo e(__('category.lbl_name')); ?>",
            width: '15%'
        },

        {
            data: 'parent_id',
            name: 'parent_id',
            title: "<?php echo e(__('category.parent_category')); ?>",
            width: '15%'
        },

        {
            data: 'featured',
            name: 'featured',
            orderable: true,
            searchable: false,
            title: "<?php echo e(__('messages.featured')); ?>",
            width: '5%'
        },

        {
            data: 'status',
            name: 'status',
            orderable: false,
            searchable: false,
            title: "<?php echo e(__('category.lbl_status')); ?>",
            width: '5%'
        },
        {
            data: 'updated_at',
            name: 'updated_at',
            title: "<?php echo e(__('service.lbl_update_at')); ?>",
            orderable: true,
            visible: false,
        },


    ]

    const actionColumn = [{
        data: 'action',
        name: 'action',
        orderable: false,
        searchable: false,
        title: "<?php echo e(__('category.lbl_action')); ?>",
        width: '5%'
    }]

    const customFieldColumns = JSON.parse(<?php echo json_encode($columns, 15, 512) ?>)

    let finalColumns = [
        ...columns,
        ...customFieldColumns,
        ...actionColumn
    ]

    document.addEventListener('DOMContentLoaded', (event) => {
        // Initialize Select2 for bulk action and status dropdowns
        if (window.jQuery && $.fn.select2) {
            // Bulk action dropdown
            $('#quick-action-type').select2({ 
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: '<?php echo e(__("messages.no_action")); ?>'
            });
            
            // Status dropdown inside bulk action
            $('#status').select2({ 
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: '<?php echo e(__("messages.select_status")); ?>'
            });
            
            // Featured dropdown inside bulk action
            $('#featured').select2({ 
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: '<?php echo e(__("messages.select_featured")); ?>'
            });
            
            // Status filter dropdown
            $('#column_status').select2({ 
                width: '100%',
                minimumResultsForSearch: Infinity, // Disable search for small dropdown
                placeholder: '<?php echo e(__("messages.change_status")); ?>'
            });
            
            // Clinic category dropdown with AJAX
            $('#clinic_category').select2({
                width: '100%',
                allowClear: true,
                minimumResultsForSearch: 0, // Enable search
                ajax: {
                    url: '<?php echo e(route("backend.get_search_data", ["type" => "clinic_category"])); ?>',
                    dataType: 'json',
                    delay: 250,
                    cache: true,
                    data: function (params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data.results,
                            pagination: data.pagination
                        };
                    }
                },
                placeholder: '<?php echo e(__("category.lbl_category")); ?>',
                dropdownParent: $('#offcanvasExample')
            });
        }
        
        initDatatable({
            url: '<?php echo e(route("backend.$module_name.index_data")); ?>',
            finalColumns,
            orderColumn: [
                [5, "desc"]
            ],
            advanceFilter: () => {
                return {
                    parent_category: $('#column_subcategory').val(),
                    vendor_id: $('#vendor').val(),

                    clinic_category: $('#clinic_category').val(),

                };
            }
        });
        $('#reset-filter').on('click', function(e) {
            $('#column_subcategory').val('');
            $('#clinic_category').val('');
            window.renderedDataTable.ajax.reload(null, false);
        });
    })


    const formOffcanvas = document.getElementById('clinic-category-offcanvas')
    const instance = bootstrap.Offcanvas.getOrCreateInstance(formOffcanvas)

    $(document).on('click', '[data-crud-id]', function() {
        setEditID($(this).attr('data-crud-id'), $(this).attr('data-parent-id'))
    })

    function setEditID(id, parent_id) {
        if (id !== '' || parent_id !== '') {
            const idEvent = new CustomEvent('crud_change_id', {
                detail: {
                    form_id: id,
                    parent_id: parent_id
                }
            })
            document.dispatchEvent(idEvent)
        } else {
            removeEditID()
        }
        instance.show()
    }

    function removeEditID() {
        const idEvent = new CustomEvent('crud_change_id', {
            detail: {
                form_id: 0,
                parent_id: null
            }
        })
        document.dispatchEvent(idEvent)
    }

    formOffcanvas?.addEventListener('hidden.bs.offcanvas', event => {
        removeEditID()
        // Let the offcanvas's own resetForm function handle the reset
        // to avoid conflicts with select2
    })


    function resetQuickAction() {
        const actionValue = $('#quick-action-type').val();
        if (actionValue != '') {
            $('#quick-action-apply').removeAttr('disabled');

            if (actionValue == 'change-status') {
                $('.quick-action-field').addClass('d-none');
                $('#change-status-action').removeClass('d-none');
            } else if (actionValue == 'change-featured') {

                $('.quick-action-field').addClass('d-none');
                $('#change-featured-action').removeClass('d-none');

            } else {
                $('.quick-action-field').addClass('d-none');
            }
        } else {
            $('#quick-action-apply').attr('disabled', true);
            $('.quick-action-field').addClass('d-none');
        }
    }

    $('#quick-action-type').change(function() {
        resetQuickAction()
    });

    $(document).on('update_quick_action', function() {
        // resetActionButtons()
    })
    document.addEventListener('DOMContentLoaded', function() {
        var type = '<?php echo isset($type) ? $type : ''; ?>';
        var data = '<?php echo isset($data) ? json_encode($data) : ''; ?>';
        console.log(type === 'category')
        if (type === 'category') {
            var myOffcanvas = document.getElementById('clinic-category-offcanvas')
            var bsOffcanvas = new bootstrap.Offcanvas(myOffcanvas)
            bsOffcanvas.show()
        } else {

        }
    });

const baseUrl = "<?php echo e(url('/')); ?>";
    function editCategory(id, parentId) {
        if (id > 0) {
            // Use the offcanvas form's loadCategoryData function
            if (typeof loadCategoryData === 'function') {
                loadCategoryData(id);
                const offcanvas = document.getElementById('clinic-category-offcanvas');
                const bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
                bsOffcanvas.show();
            } else {
                // Fallback to direct fetch if loadCategoryData is not available
                fetch(baseUrl + '/app/category/' + id + '/edit')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status) {
                            populateForm(data.data);
                            const offcanvas = document.getElementById('clinic-category-offcanvas');
                            const bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
                            bsOffcanvas.show();
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching category data:', error);
                    });
            }
        }
    }

    function populateForm(categoryData) {
        // Update form action for update
        const form = document.getElementById('clinic-category-form');
        form.action = `<?php echo e(route('backend.category.update', '')); ?>/${categoryData.id}`;
        let methodInput = form.querySelector('input[name="_method"]');
        if (!methodInput) {
            methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            form.appendChild(methodInput);
        }
        methodInput.value = 'PUT';
        if (categoryData.name) {
            const nameInput = form.querySelector('input[name="name"]');
            if (nameInput) nameInput.value = categoryData.name;
        }
        
        if (categoryData.description) {
            const descInput = form.querySelector('textarea[name="description"]');
            if (descInput) descInput.value = categoryData.description;
        }
        
        if (categoryData.parent_id) {
            const parentSelect = form.querySelector('select[name="parent_id"]');
            if (parentSelect) parentSelect.value = categoryData.parent_id;
        }
        
        if (categoryData.featured) {
            const featuredInput = form.querySelector('input[name="featured"]');
            if (featuredInput) featuredInput.checked = categoryData.featured == 1;
        }
        
        if (categoryData.status) {
            const statusInput = form.querySelector('input[name="status"]');
            if (statusInput) statusInput.checked = categoryData.status == 1;
        }
        if (categoryData.file_url) {
            const imgPreview = form.querySelector('.avatar-preview img');
            if (imgPreview) imgPreview.src = categoryData.file_url;
        }
        const titleElement = form.querySelector('.offcanvas-title');
        if (titleElement) {
            titleElement.textContent = categoryData.parent_id ? '<?php echo e(__("clinic.edit_nested_category")); ?>' : '<?php echo e(__("clinic.edit_category")); ?>';
        }
    }

    // Function to create new category
    function createNewCategory() {
        const form = document.getElementById('clinic-category-form');
        form.action = '<?php echo e(route("backend.category.store")); ?>';
        const methodInput = form.querySelector('input[name="_method"]');
        if (methodInput) methodInput.remove();
        form.reset();
        const imgPreview = form.querySelector('.avatar-preview img');
        if (imgPreview) imgPreview.src = '/path/to/default-avatar.jpg';
        const titleElement = form.querySelector('.offcanvas-title');
        if (titleElement) {
            titleElement.textContent = '<?php echo e(__("clinic.create_new_category")); ?>';
        }
        const offcanvas = document.getElementById('clinic-category-offcanvas');
        const bsOffcanvas = new bootstrap.Offcanvas(offcanvas);
        bsOffcanvas.show();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/categories/index_datatable.blade.php ENDPATH**/ ?>