
<?php
    // Ensure $data is always defined as an array to avoid undefined variable errors
    $data = $data ?? [];
?>
<div class="offcanvas offcanvas-end offcanvas-w-40" tabindex="-1" id="doctor-details-form-offcanvas"
    aria-labelledby="doctorDetailsLabel">
    <div class="offcanvas-header border-bottom">
        <h6 class="m-0 h5" id="doctorDetailsLabel"><?php echo e(__('clinic.doctor_details')); ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>

    <div class="offcanvas-body p-0">
        <form id="doctor-details-form" enctype="multipart/form-data" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="doctor_id" name="doctor_id" value="<?php echo e($data['id'] ?? ''); ?>">

            <div>
                <!-- About Doctor -->
                <h5 class="mb-3"><?php echo e(__('clinic.about_doctor')); ?></h5>

                <?php if(empty($data) ||
                        (empty($data['id']) &&
                            empty($data['full_name']) &&
                            empty($data['email']) &&
                            empty($data['mobile']) &&
                            empty($data['profile_image']) &&
                            empty($data['about']) &&
                            empty($data['address']) &&
                            empty($data['gender']) &&
                            empty($data['commissions']) &&
                            empty($data['total_appointment']) &&
                            empty($data['specialization']) &&
                            empty($data['total_sessions']) &&
                            empty($data['experience']))): ?>
                    <div class="card">
                        <div class="card-body p-5">
                            <h6 class="text-muted text-center mb-0"><?php echo e(__('clinic.no_data_available')); ?></h6>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body p-5">
                            <div class="d-flex gap-4 align-items-center flex-wrap">
                                <img id="imagePreview"
                                    src="<?php echo e(!empty($data['profile_image']) ? $data['profile_image'] : asset('img/avatar/avatar.webp')); ?>"
                                    alt="<?php echo e(__('clinic.profile_image')); ?>"
                                    class="img-fluid avatar avatar-80 avatar-rounded">
                                <div>
                                    <h5 class="mb-3">Dr. <?php echo e($data['full_name'] ?? '-'); ?></h5>
                                    <div class="d-flex align-items-center flex-wrap gap-3">
                                        <div class="d-inline-flex align-items-center gap-2 me-sm-2">
                                            <i class="ph ph-envelope mb-0 h5 align-middle"></i>
                                            <a href="mailto:<?php echo e($data['email'] ?? ''); ?>"
                                                class="text-decoration-underline"><?php echo e($data['email'] ?? '-'); ?></a>
                                        </div>
                                        <div class="d-inline-flex align-items-center gap-2">
                                            <i class="ph ph-phone mb-0 h5 align-middle"></i>
                                            <a href="tel:<?php echo e($data['mobile'] ?? ''); ?>"
                                                class="text-decoration-underline"><?php echo e($data['mobile'] ?? '-'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap mt-4">
                                <!-- About -->
                                <?php if(!empty($data['about'])): ?>
                                    <div class="my-5">
                                        <span class="mb-1"><?php echo e(__('clinic.about')); ?> :</span>
                                        <p class="mb-0 text-dark fw-semibold"><?php echo e($data['about']); ?></p>
                                    </div>
                                <?php endif; ?>
    
                                <!-- Address -->
                                <?php if(!empty($data['address'])): ?>
                                    <div class="mt-3">
                                        <p class="mb-1"><?php echo e(__('clinic.lbl_address')); ?> :</p>
                                        <h6 class="mb-0"><?php echo e($data['address']); ?></h6>
                                    </div>
                                <?php endif; ?>
    
                                <!-- Gender -->
                                <?php if(!empty($data['gender'])): ?>
                                    <div class="mt-3">
                                        <p class="mb-1"><?php echo e(__('clinic.lbl_gender')); ?> :</p>
                                        <h6 class="mb-0"><?php echo e(ucfirst($data['gender'])); ?></h6>
                                    </div>
                                <?php else: ?>
                                    <div class="mt-3">
                                        <p class="mb-1"><?php echo e(__('clinic.lbl_gender')); ?> :</p>
                                        <h6 class="mb-0 text-muted"><?php echo e(__('clinic.data_not_found')); ?></h6>
                                    </div>
                                <?php endif; ?>

                                <!-- Commissions -->
                                <?php if(!empty($data['commissions'])): ?>
                                    <div class="d-flex flex-column gap-2 mt-3">
                                        <p class="mb-1"><?php echo e(__('clinic.commission')); ?> :</p>
                                        <?php $__currentLoopData = $data['commissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <h6 class="mb-0"><?php echo e($commission['value'] ?? '-'); ?>

                                                (<?php echo e($commission['title'] ?? '-'); ?>)</h6>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="d-flex flex-column gap-2 mt-3">
                                        <p class="mb-1"><?php echo e(__('clinic.commission')); ?> :</p>
                                        <h6 class="mb-0 text-muted"><?php echo e(__('clinic.data_not_found')); ?></h6>
                                    </div>
                                <?php endif; ?>
                            </div>


                            <!-- Totals / Meta -->
                            <div class="d-flex justify-content-between gap-2 flex-wrap mt-3">
                                <div>
                                    <p class="mb-1"><?php echo e(__('clinic.total_appointment')); ?></p>
                                    <h6 class="mb-0">
                                        <?php if(isset($data['appointment'])): ?>
                                            <?php echo e($data['appointment']); ?>

                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('clinic.data_not_found')); ?></span>
                                        <?php endif; ?>
                                    </h6>
                                </div>
                                <div>
                                    <p class="mb-1"><?php echo e(__('clinic.expertize_in')); ?></p>
                                    <h6 class="mb-0">
                                        <?php if(!empty($data['specialization'])): ?>
                                            <?php echo e($data['specialization']); ?>

                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('clinic.data_not_found')); ?></span>
                                        <?php endif; ?>
                                    </h6>
                                </div>
                                <div>
                                    <p class="mb-1"><?php echo e(__('clinic.available_session_count')); ?></p>
                                    <h6 class="mb-0">
                                        <?php if(isset($data['total_sessions'])): ?>
                                            <?php echo e($data['total_sessions']); ?>

                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('clinic.data_not_found')); ?></span>
                                        <?php endif; ?>
                                    </h6>
                                </div>
                                <div>
                                    <p class="mb-1"><?php echo e(__('clinic.experience')); ?></p>
                                    <h6 class="mb-0">
                                        <?php if(isset($data['experience'])): ?>
                                            <?php echo e($data['experience']); ?>

                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('clinic.data_not_found')); ?></span>
                                        <?php endif; ?>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Services -->
                <div class="d-flex justify-content-between align-items-center mb-2 gap-3 mt-4">
                    <h5 class="mb-0"><?php echo e(__('clinic.services')); ?></h5>
                    
                </div>
                <div class="card">
                    <div class="card-body p-5">
                        <ul class="list-inline m-0 p-0" id="doctor-services-list">
                            <?php if(!empty($data['services']) && count($data['services']) > 0): ?>
                                <?php $__currentLoopData = $data['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="mb-3 doctor-service-item <?php echo e($index > 4 ? 'd-none' : ''); ?>">
                                        <div class="px-3 py-4 bg-body rounded-3">
                                            <div
                                                class="d-flex align-items-sm-center align-items-start justify-content-between flex-sm-row flex-column gap-3">
                                                <div class="flex-grow-1">
                                                    <h5 class="mb-2"><?php echo e($service->servicename ?? '-'); ?></h5>
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <p class="mb-0">
                                                            <?php echo e(__('clinic.total_appointments_done')); ?> :
                                                            <span class="font-title">
                                                                <?php
                                                                    $serviceCount = 0;
                                                                    if (
                                                                        isset($data['total_appointment']) &&
                                                                        is_array($data['total_appointment'])
                                                                    ) {
                                                                        foreach (
                                                                            $data['total_appointment']
                                                                            as $appointment
                                                                        ) {
                                                                            if (
                                                                                isset($appointment['service_id']) &&
                                                                                $appointment['service_id'] ==
                                                                                    $service->service_id
                                                                            ) {
                                                                                $serviceCount = $appointment['count'];
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                ?>
                                                                <?php echo e($serviceCount); ?>

                                                            </span>
                                                        </p>
                                                        <p class="mb-0">
                                                            <?php echo e(__('clinic.clinic')); ?>

                                                            <span class="font-title">
                                                                <?php echo e($service->clinic_name ?? '-'); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                                <h3 class="mb-0 text-primary">
                                                    <?php if(isset($service->charges)): ?>
                                                        <?php echo e(Currency::format($service->charges)); ?>

                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </h3>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li>
                                    <div class="px-3 py-4 bg-body rounded-3">
                                        <div
                                            class="d-flex align-items-sm-center align-items-start justify-content-between flex-sm-row flex-column gap-3">
                                            <div class="flex-grow-1">
                                                <h5 class="mb-2 text-muted"><?php echo e(__('clinic.no_data_available')); ?></h5>
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <p class="mb-0">
                                                        <?php echo e(__('clinic.total_appointments_done')); ?> :
                                                        <span class="font-title text-muted">N/A</span>
                                                    </p>
                                                    <p class="mb-0">
                                                        <?php echo e(__('clinic.clinic')); ?>

                                                        <span class="font-title text-muted">-</span>
                                                    </p>
                                                </div>
                                            </div>
                                            <h3 class="mb-0 text-muted">-</h3>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <?php if(!empty($data['services']) && count($data['services']) > 5): ?>
                            <div class="text-center mt-3">
                                <button type="button" class="btn btn-link px-0 position-relative"
                                    id="show-more-services-btn" tabindex="0">
                                    
                                    <?php echo e(__('clinic.show_more')); ?>

                                </button>
                                <button type="button" class="btn btn-link px-0 position-relative d-none"
                                    id="show-less-services-btn" tabindex="0">
                                    <?php echo e(__('clinic.show_less')); ?>

                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

                <!-- Reviews -->
                <div class="d-flex justify-content-between align-items-center mb-2 gap-3 mt-4">
                    <h5 class="mb-0"><?php echo e(__('clinic.reviews')); ?></h5>
                </div>
                <div>
                    <?php if(!empty($data['ratings']) && count($data['ratings']) > 0): ?>
                        <?php $__currentLoopData = $data['ratings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3">
                                <div class="card-body p-3">
                                    <div
                                        class="d-flex align-items-sm-center align-items-start justify-content-between gap-3">
                                        <div class="d-flex align-items-center gap-3">
                                            <span class="badge rounded-4 bg-body heading-color border">
                                                <div class="d-flex gap-1 align-items-center">
                                                    <span class="text-warning">&#9733;</span>
                                                    <span class="mb-0 text-primary lh-sm fs-12 fw-bold">
                                                        <?php if(isset($review->rating)): ?>
                                                            <?php echo e($review->rating); ?>

                                                        <?php else: ?>
                                                            <span class="text-muted">-</span>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </span>
                                            <h5 class="mb-0"><?php echo e($review->title ?? 'Review'); ?></h5>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="fs-12 fw-semibold">
                                                <?php if(isset($review->created_at)): ?>
                                                    <?php echo e(\Carbon\Carbon::parse($review->created_at)->diffForHumans()); ?>

                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="mt-4">
                                        <h6 class="mb-0 lh-1">
                                            By
                                            <?php if(isset($review->user) && isset($review->user->first_name)): ?>
                                                <?php echo e($review->user->first_name); ?> <?php echo e($review->user->last_name); ?>

                                            <?php else: ?>
                                                Anonymous
                                            <?php endif; ?>
                                        </h6>
                                        <p class="mt-2 mb-0 fs-12">
                                            <?php echo e($review->comment ?? ''); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="card mb-3">
                            <div class="card-body p-3">
                                <div class="d-flex justify-content-center align-items-center py-5">
                                    <h5 class="mb-0 text-muted text-center"><?php echo e(__('clinic.no_data_available')); ?></h5>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var servicesList = document.getElementById('doctor-services-list');
        var showMoreBtn = document.getElementById('show-more-services-btn');
        var showLessBtn = document.getElementById('show-less-services-btn');
        var itemsPerPage = 5;

        function getVisibleCount() {
            var items = document.querySelectorAll('#doctor-services-list .doctor-service-item:not(.d-none)');
            return items.length;
        }

        function getTotalCount() {
            var items = document.querySelectorAll('#doctor-services-list .doctor-service-item');
            return items.length;
        }

        function showMoreHandler(e) {
            e.preventDefault();
            var items = document.querySelectorAll('#doctor-services-list .doctor-service-item.d-none');
            var count = 0;
            items.forEach(function(item) {
                if (count < itemsPerPage) {
                    item.classList.remove('d-none');
                    count++;
                }
            });

            // Update button visibility after showing more items
            var remaining = document.querySelectorAll('#doctor-services-list .doctor-service-item.d-none');
            var visibleCount = getVisibleCount();
            var totalCount = getTotalCount();

            // Hide "Show More" button if no more items to show
            if (remaining.length === 0 && showMoreBtn) {
                showMoreBtn.classList.add('d-none');
            }

            // Show "Show Less" button if more than itemsPerPage are visible OR all items are visible
            console.log('After show more - Visible:', visibleCount, 'Total:', totalCount, 'ItemsPerPage:',
                itemsPerPage);
            if (showLessBtn && (visibleCount > itemsPerPage || visibleCount === totalCount)) {
                showLessBtn.classList.remove('d-none');
                console.log('Show Less button shown after show more');
            } else {
                console.log('Show Less button NOT shown - condition not met');
            }
        }

        function showLessHandler(e) {
            e.preventDefault();
            var items = document.querySelectorAll('#doctor-services-list .doctor-service-item:not(.d-none)');
            var total = items.length;

            // Only hide if more than itemsPerPage are visible
            if (total > itemsPerPage) {
                // Hide items beyond the first itemsPerPage
                for (var i = itemsPerPage; i < total; i++) {
                    items[i].classList.add('d-none');
                }
            }

            // Update button visibility
            if (showMoreBtn) {
                showMoreBtn.classList.remove('d-none');
            }
            if (showLessBtn) {
                showLessBtn.classList.add('d-none');
            }
        }

        // Remove any previous event listeners to avoid duplicate triggers
        if (showMoreBtn) {
            showMoreBtn.removeEventListener('click', showMoreHandler);
            showMoreBtn.addEventListener('click', showMoreHandler);
        }
        if (showLessBtn) {
            showLessBtn.removeEventListener('click', showLessHandler);
            showLessBtn.addEventListener('click', showLessHandler);
        }

        // Also handle if the button is re-rendered (e.g., via AJAX), use event delegation as fallback
        document.body.addEventListener('click', function(e) {
            if (e.target && e.target.id === 'show-more-services-btn') {
                showMoreHandler(e);
            }
            if (e.target && e.target.id === 'show-less-services-btn') {
                showLessHandler(e);
            }
        });

        // On load, ensure correct button visibility
        function updateButtonsOnLoad() {
            if (!showMoreBtn || !showLessBtn) return;
            var total = getTotalCount();
            var visible = getVisibleCount();

            console.log('Initial state - Total:', total, 'Visible:', visible, 'ItemsPerPage:', itemsPerPage);

            if (total > itemsPerPage) {
                // Show "Show More" button if there are hidden items
                if (visible < total) {
                    showMoreBtn.classList.remove('d-none');
                    console.log('Show More button shown');
                } else {
                    showMoreBtn.classList.add('d-none');
                    console.log('Show More button hidden');
                }

                // Show "Show Less" button if more than itemsPerPage are visible OR all items are visible
                if (visible > itemsPerPage || visible === total) {
                    showLessBtn.classList.remove('d-none');
                    console.log('Show Less button shown');
                } else {
                    showLessBtn.classList.add('d-none');
                    console.log('Show Less button hidden');
                }
            } else {
                // Hide both buttons if total items <= itemsPerPage
                showMoreBtn.classList.add('d-none');
                showLessBtn.classList.add('d-none');
                console.log('Both buttons hidden - not enough items');
            }
        }
        updateButtonsOnLoad();
    });
</script>
<?php /**PATH C:\Users\Asif Computers\Desktop\kivicare-182(1)\codecanyon-53137285-kivicare-complete-clinic-management-system-laravel-flutter\Admin Panel\kivicare-laravel-web-v1.8.2\kivicare-laravel-web-v1.8.2\Modules/Clinic\Resources/views/backend/doctor/doctor-details.blade.php ENDPATH**/ ?>