import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:kivicare_clinic_admin/utils/colors.dart';
import '../../../components/cached_image_widget.dart';
import '../../../generated/assets.dart';
import '../../../main.dart';
import '../../../utils/app_common.dart';
import '../../../utils/common_base.dart';
import '../../../utils/constants.dart';
import '../../clinic/model/clinics_res_model.dart';
import '../../doctor/clinic_center/clinic_center_screen.dart';
import '../receptionist_list_screen_controller.dart';

class AddReceptionistComponent extends StatelessWidget {
  AddReceptionistComponent({super.key});
  final ReceptionistsController reqListCont = Get.put(ReceptionistsController());

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
      decoration: boxDecorationDefault(
        color: context.cardColor,
        borderRadius: const BorderRadius.only(topLeft: Radius.circular(35), topRight: Radius.circular(35)),
      ),
      child: Obx(
        () => Form(
          key: reqListCont.addReqFormKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                2.height,
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(locale.value.addReceptionist, style: secondaryTextStyle(size: 16, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor)).expand(),
                  ],
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.firstNameCont,
                  focus: reqListCont.firstNameFocus,
                  nextFocus: reqListCont.lastNameFocus,
                  textFieldType: TextFieldType.NAME,
                  decoration: inputDecoration(
                    context,
                    hintText: locale.value.firstName,
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                  suffix: commonLeadingWid(imgPath: Assets.navigationIcUserOutlined, color: secondaryTextColor, size: 12).paddingAll(16),
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.lastNameCont,
                  focus: reqListCont.lastNameFocus,
                  nextFocus: reqListCont.emailFocus,
                  textFieldType: TextFieldType.NAME,
                  decoration: inputDecoration(
                    context,
                    hintText: locale.value.lastName,
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                  suffix: commonLeadingWid(imgPath: Assets.navigationIcUserOutlined, color: secondaryTextColor, size: 12).paddingAll(16),
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.clinicCenterCont,
                  focus: reqListCont.clinicCenterFocus,
                  nextFocus: reqListCont.emailFocus,
                  textFieldType: TextFieldType.MULTILINE,
                  minLines: 1,
                  readOnly: true,
                  onTap: () {
                    Get.to(() => ClinicCenterScreen(), arguments: reqListCont.selectedClinic.value)?.then((value) {
                      if (value is ClinicData) {
                        reqListCont.selectClinics(clinic: value);
                      }
                    });
                  },
                  decoration: inputDecoration(
                    context,
                    hintText: locale.value.selectClinicCenters,
                    fillColor: context.cardColor,
                    filled: true,
                    prefixIconConstraints: BoxConstraints.loose(const Size.square(60)),
                    prefixIcon: (reqListCont.selectedClinic.value.clinicImage.isEmpty && reqListCont.selectedClinic.value.id.isNegative).obs.value
                        ? null
                        : CachedImageWidget(
                            url: reqListCont.selectedClinic.value.clinicImage,
                            height: 35,
                            width: 35,
                            firstName: reqListCont.selectedClinic.value.name,
                            fit: BoxFit.cover,
                            circle: true,
                            usePlaceholderIfUrlEmpty: true,
                          ).paddingOnly(left: 12, top: 8, bottom: 8, right: 12),
                    suffixIcon: Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: darkGray.withOpacity(0.5)),
                  ),
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.emailCont,
                  focus: reqListCont.emailFocus,
                  nextFocus: reqListCont.addressFocus,
                  textFieldType: TextFieldType.EMAIL_ENHANCED,
                  decoration: inputDecoration(
                    context,
                    hintText: locale.value.email,
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                  suffix: commonLeadingWid(imgPath: Assets.iconsIcMail, color: secondaryTextColor, size: 12).paddingAll(16),
                ),
                16.height,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(locale.value.gender, style: primaryTextStyle()),
                    8.height,
                    Obx(
                      () => HorizontalList(
                        itemCount: genders.length,
                        spacing: 16,
                        runSpacing: 16,
                        padding: EdgeInsets.zero,
                        itemBuilder: (context, index) {
                          return Obx(
                            () => InkWell(
                              onTap: () {
                                reqListCont.selectedGender(genders[index]);
                              },
                              borderRadius: radius(),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                decoration: boxDecorationDefault(
                                  color: reqListCont.selectedGender.value.id == genders[index].id ? appColorPrimary : context.scaffoldBackgroundColor,
                                ),
                                child: Text(
                                  genders[index].name,
                                  style: secondaryTextStyle(
                                    color: reqListCont.selectedGender.value.id == genders[index].id ? white : null,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.addressCont,
                  focus: reqListCont.addressFocus,
                  nextFocus: reqListCont.phoneFocus,
                  textFieldType: TextFieldType.MULTILINE,
                  minLines: 1,
                  decoration: inputDecoration(
                    context,
                    hintText: locale.value.address,
                    fillColor: context.cardColor,
                    filled: true,
                  ),
                  suffix: commonLeadingWid(imgPath: Assets.iconsIcLocation, size: 12).paddingAll(16),
                ),
                16.height,
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Obx(
                      () => AppTextField(
                        textStyle: primaryTextStyle(size: 12),
                        textFieldType: TextFieldType.OTHER,
                        controller: TextEditingController(text: "  +${reqListCont.pickedPhoneCode.value.phoneCode}"),
                        focus: reqListCont.phoneCodeFocus,
                        nextFocus: reqListCont.phoneFocus,
                        errorThisFieldRequired: locale.value.thisFieldIsRequired,
                        readOnly: true,
                        onTap: () {
                          pickCountry(context, onSelect: (Country country) {
                            reqListCont.pickedPhoneCode(country);
                            reqListCont.phoneCodeCont.text = reqListCont.pickedPhoneCode.value.phoneCode;
                          });
                        },
                        textAlign: TextAlign.center,
                        decoration: inputDecoration(
                          context,
                          hintText: "",
                          prefixIcon: Text(
                            reqListCont.pickedPhoneCode.value.flagEmoji,
                          ).paddingOnly(top: 2, left: 8),
                          prefixIconConstraints: BoxConstraints.tight(const Size(24, 24)),
                          suffixIcon: const Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: dividerColor,
                            size: 22,
                          ).paddingOnly(right: 32),
                          suffixIconConstraints: BoxConstraints.tight(const Size(32, 24)),
                          fillColor: context.cardColor,
                          filled: true,
                        ),
                      ),
                    ).expand(flex: 3),
                    16.width,
                    AppTextField(
                      textStyle: primaryTextStyle(size: 12),
                      textFieldType: TextFieldType.PHONE,
                      controller: reqListCont.phoneCont,
                      focus: reqListCont.phoneFocus,
                      nextFocus: reqListCont.passwordFocus,
                      // maxLength: 10,
                      errorThisFieldRequired: locale.value.thisFieldIsRequired,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp('[0-9]')),
                      ],
                      decoration: inputDecoration(
                        context,
                        hintText: locale.value.contactNumber,
                        fillColor: context.cardColor,
                        filled: true,
                      ),
                      suffix: commonLeadingWid(imgPath: Assets.iconsIcCall, color: secondaryTextColor, size: 12).paddingAll(16),
                    ).expand(flex: 8),
                  ],
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.passwordCont, // Optional
                  focus: reqListCont.passwordFocus,
                  nextFocus: reqListCont.confirmPasswordFocus,
                  textFieldType: TextFieldType.PASSWORD, obscureText: true,
                  decoration: inputDecoration(
                    context,
                    fillColor: context.cardColor,
                    filled: true,
                    hintText: locale.value.password,
                  ),
                  suffixPasswordVisibleWidget: commonLeadingWid(imgPath: Assets.iconsIcEye, color: appColorPrimary, size: 12).paddingAll(14),
                  suffixPasswordInvisibleWidget: commonLeadingWid(imgPath: Assets.iconsIcEyeSlash, color: appColorPrimary, size: 12).paddingAll(14),
                ),
                16.height,
                AppTextField(
                  textStyle: primaryTextStyle(size: 12),
                  controller: reqListCont.confirmPasswordCont, // Optional
                  focus: reqListCont.confirmPasswordFocus,
                  textFieldType: TextFieldType.PASSWORD, obscureText: true,
                  decoration: inputDecoration(
                    context,
                    fillColor: context.cardColor,
                    filled: true,
                    hintText: locale.value.confirmNewPassword,
                  ),
                  suffixPasswordVisibleWidget: commonLeadingWid(imgPath: Assets.iconsIcEye, color: appColorPrimary, size: 12).paddingAll(14),
                  suffixPasswordInvisibleWidget: commonLeadingWid(imgPath: Assets.iconsIcEyeSlash, color: appColorPrimary, size: 12).paddingAll(14),
                ),
                32.height,
                AppButton(
                  width: Get.width,
                  text: locale.value.save,
                  color: appColorSecondary,
                  textStyle: appButtonTextStyleWhite,
                  shapeBorder: RoundedRectangleBorder(borderRadius: radius(defaultAppButtonRadius / 2)),
                  onTap: () {
                    if (reqListCont.addReqFormKey.currentState!.validate()) {
                      hideKeyboard(context);
                      reqListCont.saveReceptionist();
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
