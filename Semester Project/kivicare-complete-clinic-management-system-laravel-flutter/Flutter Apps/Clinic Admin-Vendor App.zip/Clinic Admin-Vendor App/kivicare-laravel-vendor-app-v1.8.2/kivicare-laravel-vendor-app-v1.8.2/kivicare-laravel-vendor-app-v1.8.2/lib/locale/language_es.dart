import 'package:kivicare_clinic_admin/locale/languages.dart';

class LanguageEs extends BaseLanguage {
  @override
  String get language => 'Idioma';

  @override
  String get badRequest => '400: Solicitud incorrecta';

  @override
  String get forbidden => '403: Prohibido';

  @override
  String get pageNotFound => '404: Página no encontrada';

  @override
  String get tooManyRequests => '429: Demasiadas solicitudes';

  @override
  String get internalServerError => '500: Error interno del servidor';

  @override
  String get badGateway => '502 Puerta de enlace no válida';

  @override
  String get serviceUnavailable => '503: Servicio no disponible';

  @override
  String get gatewayTimeout => '504: Tiempo de espera de la puerta de enlace';

  @override
  String get hey => 'Ey';

  @override
  String get hello => 'Hola';

  @override
  String get thisFieldIsRequired => 'Este campo es obligatorio';

  @override
  String get contactNumber => 'Número de contacto';

  @override
  String get gallery => 'Galería';

  @override
  String get camera => 'Cámara';

  @override
  String get editProfile => 'Editar perfil';

  @override
  String get update => 'Actualizar';

  @override
  String get reload => 'Recargar';

  @override
  String get address => 'DIRECCIÓN';

  @override
  String get viewAll => 'Ver todo';

  @override
  String get pressBackAgainToExitApp => 'Presione atrás nuevamente para salir de la aplicación';

  @override
  String get invalidUrl => 'URL no válida';

  @override
  String get cancel => 'Cancelar';

  @override
  String get delete => 'Borrar';

  @override
  String get somethingWentWrong => 'Algo salió mal';

  @override
  String get yourInternetIsNotWorking => 'Tu internet no funciona';

  @override
  String get profileUpdatedSuccessfully => 'Perfil actualizado exitosamente';

  @override
  String get location => 'Ubicación';

  @override
  String get yes => 'Sí';

  @override
  String get submit => 'Entregar';

  @override
  String get firstName => 'Nombre de pila';

  @override
  String get lastName => 'Apellido';

  @override
  String get changePassword => 'Cambiar la contraseña';

  @override
  String get password => 'Contraseña';

  @override
  String get newPassword => 'Nueva contraseña';

  @override
  String get confirmNewPassword => 'Confirmar nueva contraseña';

  @override
  String get email => 'Correo electrónico';

  @override
  String get mainStreet => 'Calle principal';

  @override
  String get signIn => 'Iniciar sesión';

  @override
  String get explore => 'Explorar';

  @override
  String get settings => 'Ajustes';

  @override
  String get rateApp => 'Califica la aplicación';

  @override
  String get aboutApp => 'Acerca de la aplicación';

  @override
  String get logout => 'Cerrar sesión';

  @override
  String get rememberMe => 'Acuérdate de mí';

  @override
  String get forgotPassword => 'Has olvidado tu contraseña';

  @override
  String get registerNow => 'Regístrate ahora';

  @override
  String get createYourAccount => 'Crea tu cuenta';

  @override
  String get signUp => 'Inscribirse';

  @override
  String get alreadyHaveAnAccount => '¿Ya tienes una cuenta?';

  @override
  String get done => 'Hecho';

  @override
  String get deleteAccount => 'Eliminar cuenta';

  @override
  String get merry => 'Alegre';

  @override
  String get doe => 'Gama';

  @override
  String get welcomeBackToThe => 'Bienvenido de nuevo a';

  @override
  String get welcomeToThe => 'Bienvenido a la';

  @override
  String get doYouWantToLogout => '¿Quieres cerrar la sesión?';

  @override
  String get appTheme => 'Tema de la aplicación';

  @override
  String get guest => 'Invitado';

  @override
  String get notifications => 'Notificaciones';

  @override
  String get newUpdate => 'Nueva actualización';

  @override
  String get anUpdateTo => 'Una actualización de';

  @override
  String get later => 'Más tarde';

  @override
  String get closeApp => 'Cerrar aplicación';

  @override
  String get updateNow => 'Actualizar ahora';

  @override
  String get signInFailed => 'Error al iniciar sesión';

  @override
  String get userCancelled => 'Usuario cancelado';

  @override
  String get eventStatus => 'Estado del evento';

  @override
  String get eventAddedSuccessfully => 'Evento añadido exitosamente';

  @override
  String get notRegistered => '¿No estás registrado?';

  @override
  String get signInWithGoogle => 'Iniciar sesión con Google';

  @override
  String get signInWithApple => 'Iniciar sesión con Apple';

  @override
  String get orSignInWith => 'O inicia sesión con';

  @override
  String get ohNoYouAreLeaving => '¡Oh no! ¡Te vas!';

  @override
  String get oldPassword => 'Contraseña anterior';

  @override
  String get personalizeYourProfile => 'Personaliza tu perfil';

  @override
  String get themeAndMore => 'Tema y más';

  @override
  String get showSomeLoveShare => '¡Muestra algo de amor, comparte!';

  @override
  String get securelyLogOutOfAccount => 'Cerrar sesión de forma segura en la cuenta';

  @override
  String get termsOfService => 'Condiciones de servicio';

  @override
  String get successfully => 'Exitosamente';

  @override
  String get clearAll => 'Borrar todo';

  @override
  String get notificationDeleted => 'notificación eliminada';

  @override
  String get doYouWantToRemoveNotification => '¿Quieres eliminar la notificación?';

  @override
  String get doYouWantToRemoveImage => '¿Quieres eliminar la imagen?';

  @override
  String get locationPermissionDenied => 'permiso de ubicación denegado';

  @override
  String get enableLocation => 'habilitar ubicación';

  @override
  String get permissionDeniedPermanently => 'permiso denegado permanentemente';

  @override
  String get chooseYourLocation => 'Elija su ubicación';

  @override
  String get setAddress => 'Establecer dirección';

  @override
  String get iAgreeToThe => 'Estoy de acuerdo con el';

  @override
  String get logIn => 'ACCESO';

  @override
  String get country => 'País';

  @override
  String get selectCountry => 'Seleccionar país';

  @override
  String get state => 'Estado';

  @override
  String get selectState => 'Seleccione Estado';

  @override
  String get city => 'Ciudad';

  @override
  String get pinCode => 'Código PIN';

  @override
  String get selectCity => 'Seleccionar ciudad';

  @override
  String get addressLine => 'Línea de dirección';

  @override
  String get searchHere => 'Buscar aquí';

  @override
  String get noDataFound => 'No se encontraron datos';

  @override
  String get checkout => 'Verificar';

  @override
  String get pending => 'Pendiente';

  @override
  String get completed => 'Terminado';

  @override
  String get confirmed => 'Confirmado';

  @override
  String get cancelled => 'Cancelado';

  @override
  String get rejected => 'Rechazado';

  @override
  String get reject => 'Rechazar';

  @override
  String get processing => 'Tratamiento';

  @override
  String get delivered => 'Entregado';

  @override
  String get placed => 'Metido';

  @override
  String get paid => 'Pagado';

  @override
  String get failed => 'Fallido';

  @override
  String get approved => 'Aprobado';

  @override
  String get aboutSelf => 'Acerca de mí mismo';

  @override
  String get doYouWantToCancelBooking => '¿Quieres cancelar la reserva?';

  @override
  String get appliedTaxes => 'Impuestos aplicados';

  @override
  String get appointment => 'Cita';

  @override
  String get online => 'En línea';

  @override
  String get inClinic => 'En la clínica';

  @override
  String get patient => 'Paciente';

  @override
  String get doctor => 'Doctor';

  @override
  String get payment => 'Pago';

  @override
  String get videoCallLinkIsNotFound => '¡No se encuentra el enlace de la videollamada!';

  @override
  String get thisIsNotAOnlineService => '¡Éste no es un servicio en línea!';

  @override
  String get oppsThisAppointmentIsNotConfirmedYet => '¡Ups! ¡Esta cita aún no está confirmada!';

  @override
  String get oppsThisAppointmentHasBeenCancelled => '¡Ups! ¡Esta cita ha sido cancelada!';

  @override
  String get oppsThisAppointmentHasBeenCompleted => '¡Ups! ¡Esta cita ya se ha completado!';

  @override
  String get dateTime => 'Fecha y hora';

  @override
  String get appointmentType => 'Tipo de cita';

  @override
  String get searchAppoinmentHere => 'Buscar cita aquí';

  @override
  String get noClinicsFoundAtAMoment => 'No se encontraron clínicas en este momento';

  @override
  String get looksLikeThereIsNoClinicsWellKeepYouPostedWhe => 'Parece que no hay clínicas. Te mantendremos informado cuando haya una actualización.';

  @override
  String get searchDoctorHere => 'Busque un médico aquí';

  @override
  String get searchPatientHere => 'Buscar paciente aquí';

  @override
  String get noPatientFound => '¡No se encontró ningún paciente!';

  @override
  String get oppsNoPatientFoundAtMomentTryAgainLater => '¡Ups! No se encontró ningún paciente en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get searchServiceHere => 'Servicio de búsqueda aquí';

  @override
  String get noServiceFound => '¡No se encontró ningún servicio!';

  @override
  String get oppsNoServiceFoundAtMomentTryAgainLater => '¡Ups! No se encontró ningún servicio en este momento. Inténtalo más tarde.';

  @override
  String get filterBy => 'Filtrar por';

  @override
  String get clearFilter => 'Limpiar filtro';

  @override
  String get doYouWantToPerformThisAction => '¿Quieres realizar esta acción?';

  @override
  String get statusHasBeenUpdated => '¡El estado ha sido actualizado!';

  @override
  String get sessionSummary => 'Resumen de la sesión';

  @override
  String get clinicInfo => 'Información de la clínica';

  @override
  String get doctorInfo => 'Información del médico';

  @override
  String get patientInfo => 'Información del paciente';

  @override
  String get aboutService => 'Acerca del servicio';

  @override
  String get encounterDetails => 'Detalles del encuentro';

  @override
  String get doctorName => 'Nombre del doctor';

  @override
  String get active => 'ACTIVO';

  @override
  String get closed => 'CERRADO';

  @override
  String get clinicName => 'Nombre de la clínica';

  @override
  String get description => 'Descripción';

  @override
  String get usersMustClearPaymentBeforeAccessingCheckout => 'Los usuarios deben liquidar el pago antes de acceder al pago.';

  @override
  String get paymentDetails => 'Detalles del pago';

  @override
  String get price => 'Precio';

  @override
  String get discount => 'Descuento';

  @override
  String get off => 'apagado';

  @override
  String get subtotal => 'Total parcial';

  @override
  String get tax => 'Impuesto';

  @override
  String get total => 'Total';

  @override
  String get appointments => 'Equipo';

  @override
  String get noAppointmentsFound => 'No se encontraron citas';

  @override
  String get thereAreCurrentlyNoAppointmentsAvailable => 'Actualmente no hay citas disponibles.';

  @override
  String get resetYourPassword => 'Restablecer su contraseña';

  @override
  String get enterYourEmailAddressToResetYourNewPassword => 'Introduzca su dirección de correo electrónico para restablecer su nueva contraseña.';

  @override
  String get sendCode => 'Enviar código';

  @override
  String get edit => 'EDITAR';

  @override
  String get gender => 'Género';

  @override
  String get profile => 'Perfil';

  @override
  String get clinics => 'Clínicas';

  @override
  String get manageClinics => 'Administrar clínicas';

  @override
  String get manageSessions => 'Administrar sesiones';

  @override
  String get changeOrAddYourSessions => 'Cambiar o agregar tus sesiones';

  @override
  String get doctors => 'Doctores';

  @override
  String get manageDoctors => 'Gestionar médicos';

  @override
  String get requests => 'Solicitudes';

  @override
  String get requestForServiceCategoryAndSpecialization => 'Solicitud de servicio, categoría y especialización';

  @override
  String get receptionists => 'Recepcionistas';

  @override
  String get allReceptionist => 'Todas las recepcionistas';

  @override
  String get encounters => 'Encuentros';

  @override
  String get manageEncouterData => 'Administrar datos de Encouter';

  @override
  String get userNotCreated => 'Usuario no creado';

  @override
  String get pleaseSelectRoleToLogin => '¡Seleccione un rol para iniciar sesión!';

  @override
  String get pleaseSelectRoleToRegister => '¡Seleccione el rol para registrarse!';

  @override
  String get pleaseSelectClinicToRegister => '¡Por favor seleccione una clínica para registrarse!';

  @override
  String get chooseYourRole => 'Elige tu rol';

  @override
  String get demoAccounts => 'Cuentas de demostración';

  @override
  String get notAMember => '¿No eres miembro?';

  @override
  String get registerYourAccountForBetterExperience => 'Registre su cuenta para una mejor experiencia';

  @override
  String get selectUserRole => 'Seleccionar rol de usuario';

  @override
  String get selectClinic => 'Seleccione Clínica';

  @override
  String get termsConditions => 'Términos y condiciones';

  @override
  String get and => 'Y';

  @override
  String get privacyPolicy => 'política de privacidad';

  @override
  String get save => 'Ahorrar';

  @override
  String get allCategory => 'Todas las categorías';

  @override
  String get noCategoryFound => 'No se encontró ninguna categoría';

  @override
  String get editClinic => 'Editar Clínica';

  @override
  String get addClinic => 'Agregar clínica';

  @override
  String get clinicImage => 'Imagen de la clínica';

  @override
  String get chooseImageToUpload => 'Elige la imagen que quieres subir';

  @override
  String get chooseSpecialization => 'Elija Especialización';

  @override
  String get searchForSpecialization => 'Búsqueda de especialización';

  @override
  String get specialization => 'Especialización';

  @override
  String get timeSlot => 'Franja horaria';

  @override
  String get chooseCountry => 'Elija país';

  @override
  String get searchForCountry => 'Buscar por país';

  @override
  String get chooseState => 'Elija el estado';

  @override
  String get searchForState => 'Buscar estado';

  @override
  String get chooseCity => 'Elija ciudad';

  @override
  String get searchForCity => 'Buscar ciudad';

  @override
  String get postalCode => 'Código Postal';

  @override
  String get latitude => 'Latitud';

  @override
  String get longitude => 'Longitud';

  @override
  String get writeHere => 'Escribe aquí';

  @override
  String get status => 'Estado';

  @override
  String get pleaseSelectAClinicImage => 'Por favor seleccione una imagen de la clínica';

  @override
  String get addBreak => 'Agregar descanso';

  @override
  String get editBreak => 'Salto de edición';

  @override
  String get selectTime => 'Seleccionar hora';

  @override
  String get startDateMustBeBeforeEndDate => 'La fecha de inicio debe ser anterior a la fecha de finalización';

  @override
  String get endDateMustBeAfterStartDate => 'La fecha de finalización debe ser posterior a la fecha de inicio';

  @override
  String get breakTimeIsOutsideShiftTime => 'El tiempo de descanso está fuera del horario de turno.';

  @override
  String get clinicSessions => 'Sesiones clínicas';

  @override
  String get noSessionsFound => '¡No se encontraron sesiones!';

  @override
  String get oppsNoSessionsFoundAtMomentTryAgainLater => '¡Ups! No se encontraron sesiones en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get unavailable => 'Indisponible';

  @override
  String get sessions => 'Sesiones';

  @override
  String get clinicSessionsInformation => 'Información sobre las sesiones clínicas';

  @override
  String get services => 'Servicios';

  @override
  String get clinicDetail => 'Detalle de la clínica';

  @override
  String get readMore => 'Leer más';

  @override
  String get readLess => 'Leer menos';

  @override
  String get clinicGalleryDeleteSuccessfully => 'Galería de la Clínica eliminada exitosamente';

  @override
  String get noGalleryFoundAtAMoment => 'No se encontró ninguna galería en este momento';

  @override
  String get looksLikeThereIsNoGalleryForThisClinicWellKee => 'Parece que no hay galería para esta clínica. Le mantendremos informado cuando haya una actualización.';

  @override
  String get pleaseSelectImages => '¡¡¡Por favor seleccione imágenes!!!';

  @override
  String get noClinicsFound => '¡No se encontraron clínicas!';

  @override
  String get addNewClinic => 'Agregar nueva clínica';

  @override
  String get areYouSureYouWantToDeleteThisClinic => '¿Está seguro de que desea eliminar esta clínica?';

  @override
  String get clinicDeleteSuccessfully => 'Clínica eliminada exitosamente';

  @override
  String get totalAppointments => 'Total de citas';

  @override
  String get totalServices => 'Servicios totales';

  @override
  String get totalPatient => 'Paciente total';

  @override
  String get totalEarning => 'Ganancia total';

  @override
  String get welcomeBack => 'Bienvenido de nuevo';

  @override
  String get totalDoctors => 'Doctores totales';

  @override
  String get doYouWantToPerformThisChange => '¿Quieres realizar este cambio?';

  @override
  String get statusUpdatedSuccessfully => 'Estado actualizado exitosamente';

  @override
  String get chooseClinic => 'Elija Clínica';

  @override
  String get pleaseChooseClinic => '¡¡¡Por favor elija clínica!!!';

  @override
  String get oppsNoClinicsFoundAtMomentTryAgainLater => '¡Ups! No se encontraron clínicas en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get change => 'Cambiar';

  @override
  String get analytics => 'Analítica';

  @override
  String get youDontHaveAnyServicesnPleaseAddYourServices => 'No tienes ningún servicio.\n Por favor añade tus servicios';

  @override
  String get addService => 'Agregar servicio';

  @override
  String get recentAppointment => 'Nombramiento reciente';

  @override
  String get yourService => 'Su servicio';

  @override
  String get patients => 'Pacientes';

  @override
  String get noPatientsFound => '¡No se encontraron pacientes!';

  @override
  String get patientDetail => 'Detalle del paciente';

  @override
  String get appointmentsTillNow => 'citas hasta ahora';

  @override
  String get payoutHistory => 'Historial de pagos';

  @override
  String get noPayout => '¡¡¡Sin pago!!!';

  @override
  String get addReceptionist => 'Agregar recepcionista';

  @override
  String get selectClinicCenters => 'Centros clínicos selectos';

  @override
  String get noReceptionistsFound => '¡No se encontraron recepcionistas!';

  @override
  String get addRequest => 'Agregar solicitud';

  @override
  String get name => 'Nombre';

  @override
  String get selectType => 'Seleccionar tipo';

  @override
  String get requestList => 'Lista de solicitudes';

  @override
  String get noRequestsFound => '¡No se encontraron solicitudes!';

  @override
  String get oppsNoRequestsFoundAtMomentTryAgainLater => '¡Ups! No se encontraron solicitudes en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get changePrice => 'Cambiar precio';

  @override
  String get assignDoctor => 'Asignar médico';

  @override
  String get priceUpdatedSuccessfully => '¡¡¡Precio actualizado exitosamente!!!';

  @override
  String get charges => 'Cargos';

  @override
  String get doctorsAssignSuccessfully => '¡¡¡Los médicos asignaron con éxito!!!';

  @override
  String get pleaseSelectClinic => '¡¡Por favor seleccione clínica!!';

  @override
  String get searchForClinic => 'Buscar clínica';

  @override
  String get noDoctorsFound => '¡No se encontraron médicos!';

  @override
  String get socialMedia => 'Redes sociales';

  @override
  String get revenue => 'Ganancia';

  @override
  String get yearly => 'Anual';

  @override
  String get service => 'Servicio';

  @override
  String get searchClinicHere => 'Buscar clínica aquí';

  @override
  String get home => 'Hogar';

  @override
  String get payouts => 'Pagos';

  @override
  String get editDoctor => 'Editar Doctor';

  @override
  String get addDoctor => 'Agregar Doctor';

  @override
  String get aboutMyself => 'Acerca de mí';

  @override
  String get experienceSpecializationContactInfo => 'Experiencia, Especialización, Información de Contacto';

  @override
  String get doctorSessionsInformation => 'Información de las sesiones médicas';

  @override
  String get noServicesTillNow => 'No hay servicios hasta ahora';

  @override
  String get oopsThisDoctorDoesntHaveAnyServicesYet => '¡Ups! Este doctor aún no tiene ningún servicio.';

  @override
  String get reviews => 'Reseñas';

  @override
  String get noReviewsTillNow => 'No hay reseñas hasta ahora';

  @override
  String get oopsThisDoctorDoesntHaveAnyReviewsYet => '¡Ups! Este doctor aún no tiene ninguna reseña.';

  @override
  String get qualification => 'Calificación';

  @override
  String get qualificationInDetail => 'Calificación en detalle';

  @override
  String get year => 'Año';

  @override
  String get degree => 'Grado';

  @override
  String get university => 'Universidad';

  @override
  String get by => 'Por';

  @override
  String get breaks => 'Descansos';

  @override
  String get noWeekListFound => '¡No se encontró ninguna lista de semanas!';

  @override
  String get oppsNoWeekListFoundAtMomentTryAgainLater => '¡Ups! No se encontró la lista de la semana en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get addDayOff => 'Añadir día libre';

  @override
  String get assignClinics => 'Asignar clínicas';

  @override
  String get oppsNoDoctorFoundAtMomentTryAgainLater => '¡Ups! No se encontró ningún médico en este momento. Inténtalo más tarde.';

  @override
  String get sessionSavedSuccessfully => 'Sesión guardada exitosamente';

  @override
  String get doctorSession => 'Sesión médica';

  @override
  String get selectDoctor => 'Seleccionar Doctor';

  @override
  String get pleaseSelectDoctor => 'Por favor seleccione doctor...!!';

  @override
  String get allSession => 'Toda la sesión';

  @override
  String get addSession => 'Agregar sesión';

  @override
  String get noDoctorSessionFound => '¡No se encontró ninguna sesión de Doctor!';

  @override
  String get thereAreCurrentlyNoDoctorSessionAvailable => 'Actualmente no hay sesiones médicas disponibles.';

  @override
  String get oppsNoReviewFoundAtMomentTryAgainLater => '¡Ups! No hay ninguna reseña en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get noServicesFound => '¡No se encontraron servicios!';

  @override
  String get oppsNoServicesFoundAtMomentTryAgainLater => '¡Ups! No se encontraron servicios en este momento. Inténtalo más tarde.';

  @override
  String get invoice => 'Factura';

  @override
  String get encounter => 'Encontrar';

  @override
  String get totalPayableAmountWithTax => 'Importe total a pagar con impuestos';

  @override
  String get discountAmount => 'Monto del descuento';

  @override
  String get servicePrice => 'Precio del servicio';

  @override
  String get contactInfo => 'Información de contacto';

  @override
  String get experience => 'Experiencia';

  @override
  String get about => 'Acerca de';

  @override
  String get myProfile => 'Mi perfil';

  @override
  String get doctorDetail => 'Detalle del doctor';

  @override
  String get areYouSureYouWantToDeleteThisDoctor => '¿Estás seguro que deseas eliminar este Doctor?';

  @override
  String get doctorDeleteSuccessfully => 'Doctor eliminado exitosamente';

  @override
  String get noQualificationsFound => '¡No se encontraron calificaciones!';

  @override
  String get looksLikeThereAreNoQualificationsAddedByThisD => 'Parece que no hay cualificaciones añadidas por este doctor.';

  @override
  String get addEncounter => 'Añadir encuentro';

  @override
  String get fillPatientEncounterDetails => 'Complete los detalles del encuentro con el paciente';

  @override
  String get dateIsNotSelected => 'La fecha no está seleccionada';

  @override
  String get date => 'Fecha';

  @override
  String get chooseDoctor => 'Elija Doctor';

  @override
  String get choosePatient => 'Elija Paciente';

  @override
  String get searchForPatient => 'Búsqueda de pacientes';

  @override
  String get bodyChart => 'Diagrama corporal';

  @override
  String get imageDetails => 'Detalles de la imagen';

  @override
  String get reset => 'Reiniciar';

  @override
  String get imageTitle => 'Título de la imagen';

  @override
  String get imageDescription => 'Descripción de la imagen';

  @override
  String get pleaseUploadTheImage => '¡¡¡Por favor sube la imagen!!!';

  @override
  String get patientName => 'Nombre del paciente';

  @override
  String get lastUpdate => 'Última actualización';

  @override
  String get noBodyChartsFound => '¡No se encontraron gráficos corporales!';

  @override
  String get oppsNoBodyChartsFoundAtMomentTryAgainLater => '¡Ups! No se encontraron gráficos corporales en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get areYouSureYouWantToDeleteThisBodyChart => '¿Está seguro de que desea eliminar este gráfico corporal?';

  @override
  String get editPrescription => 'Editar receta';

  @override
  String get addPrescription => 'Agregar receta';

  @override
  String get frequency => 'Frecuencia';

  @override
  String get duration => 'Duración';

  @override
  String get instruction => 'Instrucción';

  @override
  String get noNotesAdded => 'No hay notas añadidas';

  @override
  String get chooseOrAddNotes => 'Elija o agregue notas';

  @override
  String get writeNotes => 'Escribir notas';

  @override
  String get add => 'Agregar';

  @override
  String get notes => 'Notas';

  @override
  String get observations => 'Observaciones';

  @override
  String get chooseOrAddObservation => 'Elija o agregue una observación';

  @override
  String get writeObservation => 'Escribir observación';

  @override
  String get noObservationAdded => 'No se ha añadido ninguna observación';

  @override
  String get otherInformation => 'Otra información';

  @override
  String get write => 'Escribir...';

  @override
  String get prescription => 'Prescripción';

  @override
  String get noPrescriptionAdded => 'Sin receta añadida';

  @override
  String get days => 'Días';

  @override
  String get problems => 'Problemas';

  @override
  String get chooseOrAddProblems => 'Elija o agregue problemas';

  @override
  String get writeProblem => 'Escribir problema';

  @override
  String get noProblemAdded => 'No hay problema añadido';

  @override
  String get clinicalDetail => 'Detalle clínico';

  @override
  String get moreInformation => 'Más información';

  @override
  String get patientHealthInformation => 'Información de salud del paciente';

  @override
  String get showBodyChartRelatedInformation => 'Mostrar información relacionada con el gráfico corporal';

  @override
  String get viewReport => 'Ver informe';

  @override
  String get showReportRelatedInformation => 'Mostrar información relacionada con el informe';

  @override
  String get billDetails => 'Detalles de la factura';

  @override
  String get showBillDetailsRelatedInformation => 'Mostrar información relacionada con los detalles de la factura';

  @override
  String get clinic => 'Clínica';

  @override
  String get encounterDate => 'Fecha del encuentro';

  @override
  String get unpaid => 'No pagado';

  @override
  String get totalPrice => 'Precio total';

  @override
  String get enterDiscount => 'Introducir descuento';

  @override
  String get enterPayableAmount => 'Ingrese el importe a pagar';

  @override
  String get paymentStatus => 'Estado del pago';

  @override
  String get toCloseTheEncounterInvoicePaymentIsMandatory => 'Para cerrar el encuentro es obligatorio el pago de factura.';

  @override
  String get noInvoiceDetailsFound => '¡No se encontraron detalles de factura!';

  @override
  String get oppsNoInvoiceDetailsFoundAtMomentTryAgainLate => '¡Ups! No se encontraron detalles de la factura en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get invoiceDetail => 'Detalle de la factura';

  @override
  String get noInvoiceFound => '¡No se encontró ninguna factura!';

  @override
  String get generateInvoice => '¡¡¡Generar factura!!!';

  @override
  String get invoiceId => 'Identificación de la factura';

  @override
  String get patientDetails => 'Datos del paciente';

  @override
  String get editMedicalReport => 'Editar informe médico';

  @override
  String get addMedicalReport => 'Agregar informe médico';

  @override
  String get uploadMedicalReport => 'Subir informe médico';

  @override
  String get pleaseUploadAMedicalReport => 'Por favor, cargue un informe médico.';

  @override
  String get medicalReports => 'Informes médicos';

  @override
  String get noMedicalReportsFound => '¡¡No se encontraron informes médicos!!';

  @override
  String get areYouSureYouWantToDeleteThisMedicalReport => '¿Está seguro de que desea eliminar este informe médico?';

  @override
  String get medicalReportDeleteSuccessfully => 'Informe médico eliminado correctamente';

  @override
  String get noEncountersFound => '¡No se encontraron encuentros!';

  @override
  String get areYouSureYouWantToDeleteThisEncounter => '¿Estás seguro de que deseas eliminar este encuentro?';

  @override
  String get totalClinic => 'Clínica Total';

  @override
  String get subjectiveObjectiveAssessmentAndPlan => 'Subjetivo, Objetivo, Evaluación y Plan.';

  @override
  String get noteTheAcronymSoapStandsForSubjectiveObjectiv =>
      'Nota: El acrónimo SOAP significa Subjetivo, Objetivo, Evaluación y Plan. Este método estandarizado para documentar las consultas con pacientes permite a los profesionales sanitarios registrar la información del paciente de forma concisa.';

  @override
  String get subjective => 'Subjetivo';

  @override
  String get objective => 'Objetivo';

  @override
  String get assessment => 'Evaluación';

  @override
  String get plan => 'Plan';

  @override
  String get clearAllFilters => 'Borrar todos los filtros';

  @override
  String get apply => 'Aplicar';

  @override
  String get reportDetails => 'Detalles del informe';

  @override
  String get yearIsRequired => 'Se requiere año';

  @override
  String get enterAValidYearBetween1900And => 'Introduzca un año válido entre 1900 y';

  @override
  String get pleaseEnterYourDegree => 'Por favor ingrese su título';

  @override
  String get pleaseEnterDegree => 'Por favor, introduzca su título';

  @override
  String get pleaseEnterUniversity => 'Por favor ingrese a la Universidad';

  @override
  String get selectYear => 'Seleccione año';

  @override
  String get somethingWentWrongPleaseTryAgainLater => 'Algo salió mal. Inténtalo de nuevo más tarde.';

  @override
  String get advancePayableAmount => 'Monto a pagar por adelantado';

  @override
  String get advancePaidAmount => 'Monto pagado por adelantado';

  @override
  String get remainingPayableAmount => 'Importe restante a pagar';

  @override
  String get addYourSignature => 'Añade tu firma';

  @override
  String get verifyWithEaseYourDigitalMark => 'Verifique con facilidad: su marca digital';

  @override
  String get clear => 'Claro';

  @override
  String get doctorImage => 'Imagen del doctor';

  @override
  String get serviceTotal => 'Total de servicios';

  @override
  String get expert => 'Experto';

  @override
  String get percent => 'Por ciento';

  @override
  String get fixed => 'Fijado';

  @override
  String get discoutValue => 'Valor de descuento';

  @override
  String get editDiscount => 'Editar descuento';

  @override
  String get addDiscount => 'Añadir descuento';

  @override
  String get totalAmount => 'Importe total';

  @override
  String get addBillingItem => 'Agregar elemento de facturación';

  @override
  String get serviceImage => 'Imagen de servicio';

  @override
  String get editService => 'Servicio de edición';

  @override
  String get great => 'Excelente';

  @override
  String get bookingSuccessful => 'Reserva realizada con éxito';

  @override
  String get yourAppointmentHasBeenBookedSuccessfully => 'Su cita ha sido reservada exitosamente';

  @override
  String get totalPayment => 'Pago total';

  @override
  String get goToAppointments => 'Ir a Citas';

  @override
  String get addAppointment => 'Agregar cita';

  @override
  String get selectService => 'Seleccionar servicio';

  @override
  String get chooseDate => 'Elija fecha';

  @override
  String get noTimeSlotsAvailable => 'No hay franjas horarias disponibles';

  @override
  String get chooseTime => 'Elige la hora';

  @override
  String get asPerDoctorCharges => '*según cargos del médico';

  @override
  String get remainingAmount => 'Cantidad restante';

  @override
  String get refundableAmount => 'Monto reembolsable';

  @override
  String get version => 'Versión';

  @override
  String get passwordLengthShouldBe8To14Characters => 'La longitud de la contraseña debe ser de 8 a 14 caracteres.';

  @override
  String get theConfirmPasswordAndPasswordMustMatch => 'La contraseña de confirmación y la contraseña deben coincidir.';

  @override
  String get chooseCommission => 'Elija Comisión';

  @override
  String get searchForCommission => 'Búsqueda de comisión';

  @override
  String get noCommissionFound => 'No se encontró ninguna comisión';

  @override
  String get commission => 'Comisión';

  @override
  String get selectServices => 'Seleccionar servicios';

  @override
  String get facebookLink => 'Enlace de Facebook';

  @override
  String get instagramLink => 'Enlace de Instagram';

  @override
  String get twitterLink => 'Enlace de Twitter';

  @override
  String get dribbleLink => 'Enlace de Dribble';

  @override
  String get signature => 'Firma';

  @override
  String get addNew => 'Agregar nuevo';

  @override
  String get pleaseSelectADoctorImage => 'Por favor seleccione una imagen de Doctor';

  @override
  String get remove => 'Eliminar';

  @override
  String get degreecertification => 'Título/Certificación';

  @override
  String get noReviewsFoundAtAMoment => 'No se encontraron reseñas en este momento';

  @override
  String get looksLikeThereIsNoReviewsWellKeepYouPostedWhe => 'Parece que no hay reseñas. Te mantendremos informado cuando haya una actualización.';

  @override
  String get addNewDoctor => 'Agregar nuevo doctor';

  @override
  String get bodyChartDeleteSuccessfully => 'Gráfico corporal eliminado exitosamente';

  @override
  String get editBillingItem => 'Editar elemento de facturación';

  @override
  String get quantity => 'Cantidad';

  @override
  String get areYouSureYouWantToDeleteThisBillingItem => '¿Está seguro de que desea eliminar este elemento de facturación?';

  @override
  String get pleaseWaitWhileItsLoading => 'Por favor espere mientras se carga...';

  @override
  String get billingItemRemovedSuccessfully => 'Elemento de facturación eliminado correctamente';

  @override
  String get closeCheckoutEncounter => 'Encuentro de cierre y pago';

  @override
  String get file => 'Archivo';

  @override
  String get serviceName => 'Nombre del servicio';

  @override
  String get serviceDurationMin => 'Duración del servicio (min)';

  @override
  String get defaultPrice => 'Precio predeterminado';

  @override
  String get chooseCategory => 'Elija una categoría';

  @override
  String get searchForCategory => 'Buscar por categoría';

  @override
  String get category => 'Categoría';

  @override
  String get enterDescription => 'Introducir descripción';

  @override
  String get pleaseSelectAServiceImage => 'Por favor seleccione una imagen de servicio';

  @override
  String get sServices => 'Servicios s';

  @override
  String get bookedForWithColon => 'Reservado para:';

  @override
  String get bookedFor => 'Reservado para';

  @override
  String get dateOfBirth => 'Fecha de nacimiento';

  @override
  String get pleaseAddService => 'Por favor añadir servicio';

  @override
  String get editReceptionist => 'Editar Recepcionista';

  @override
  String get receptionistDeleteSuccessfully => 'Recepcionista Eliminar exitosamente';

  @override
  String get goBack => 'Volver';

  @override
  String get includesInclusiveTax => 'Incluye Impuesto Incluido';

  @override
  String get inclusiveTaxes => 'Impuestos Inclusivos';

  @override
  String get exclusiveTax => 'Impuesto exclusivo';

  @override
  String encounterWithId(int id) => "Encuentro #$id";

  @override
  String get cancelAppointment => 'Cancelar cita';

  @override
  String cancellationFeesWillBeAppliedIfYouCancelWithinHoursOfScheduledTime(String hours, bool isCancellationChargesEnabled) =>
      '¿Desea cancelar esta cita? ${isCancellationChargesEnabled ? 'Se aplicarán cargos por cancelación si cancela dentro de $hours horas de la hora programada' : ''}  ';

  @override
  String get yourAppointmentHasBeenSuccessfullyCancelled => 'Su cita ha sido cancelada exitosamente';

  @override
  String get appointmentRefundWillBeProcessedWithingHoursIfApplicable => 'El reembolso de la cita se procesará dentro de las 24 horas si corresponde.';

  @override
  String get ok => 'De acuerdo';

  @override
  String get hintReason => 'p. ej. Ya hay otra cita programada, etc.';

  @override
  String get confirm => 'Confirmar';

  @override
  String get medicalHistory => 'Historial médico';

  @override
  String get aVertionUpdateIsAvailable => '¡Ya está disponible una versión más nueva con características emocionantes!¡Ya está disponible una versión más nueva con características emocionantes!';

  @override
  String get addFiles => 'Agregar archivos';

  @override
  String get addFile => 'Agregar archivo';

  @override
  String get addMedicalHistory => 'Agregar historial médico';

  @override
  String get appleSigninIsNot => 'El inicio de sesión de Apple no está disponible para tu dispositivo';

  @override
  String get appliedExclusiveTaxes => 'Impuestos Inclusivos Aplicados';

  @override
  String get appliedInclusiveTaxes => 'Incluye Impuesto Incluido';

  @override
  String get areYouSureYou => '¿Seguro que desea cancelar? Se podría aplicar un cargo por cancelación basado en el precio del servicio.';

  @override
  String get areYouSureYouWantTonupdateTheService => '¿Está seguro que desea actualizar el servicio?';

  @override
  String get available => 'Disponible';

  @override
  String get bookingCancelled => 'Reserva cancelada';

  @override
  String get cancellationFee => 'Tarifa de cancelación';

  @override
  String get checkIn => 'Registrarse';

  @override
  String get continueText => 'Continuar';

  @override
  String get createYourAccountFor => 'Crea tu cuenta para una mejor experiencia';

  @override
  String get deleteAccountConfirmation => 'Su cuenta será eliminada permanentemente. Sus datos no se restaurarán.';

  @override
  String get demoUserCannotBeGrantedForThis => 'No se puede conceder el usuario de demostración para esta acción';

  @override
  String get doYouWantToClearAllNotification => '¿Quieres borrar todas las notificaciones?';

  @override
  String get doctorsAvaliable => 'Médicos disponibles';

  @override
  String get eG => 'p.ej.';

  @override
  String get emailRequired => 'Se requiere correo electrónico';

  @override
  String get encounterId => 'Identificación del encuentro';

  @override
  String get forgotPasswordTitle => 'Has olvidado tu contraseña';

  @override
  String get goToHistory => 'Ir al historial';

  @override
  String get inAppUpdate => 'Actualización en la aplicación';

  @override
  String get inProgress => 'En curso';

  @override
  String get inclusiveTax => 'Impuesto Inclusivo';

  @override
  String get isAvailableGoTo => 'Está disponible. Vaya a Play Store y descargue la nueva versión de la aplicación.';

  @override
  String get lblBreak => 'Romper';

  @override
  String get lblCancelBooking => 'Cancelar reserva';

  @override
  String get looksLikeThereAreNoDoctorsAvilableToAssign => 'Parece que no hay médicos disponibles para asignar.';

  @override
  String get no => 'No';

  @override
  String get noNewNotificationsAt => 'No hay notificaciones nuevas por el momento. Te mantendremos informado cuando haya una actualización.';

  @override
  String get noteCheckYourAppointmentHistoryForRefundDetailsIfApplicable => '*Nota: Consulte su historial de citas para obtener detalles de reembolso si corresponde.';

  @override
  String get noteCheckYourBooking => 'Nota: Consulte su historial de reservas para obtener detalles del reembolso.';

  @override
  String get oldAndNewPassword => 'La contraseña antigua y la nueva son la misma.';

  @override
  String get enterReason => 'Especifique su motivo aquí';

  @override
  String get oppsLooksLikeThereIsNoPayoutsAvailable => '¡Ups! Parece que no hay ningún pago disponible.';

  @override
  String get oppsNoInvoiceFoundAtMomentTryAgainLater => '¡Ups! No se encontraron facturas en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get oppsNoPatientsFoundAtMomentTryAgainLater => '¡Ups! No se encontró ningún paciente en este momento. Inténtalo de nuevo más tarde.';

  @override
  String get oppsNoReceptionistsFoundAtMomentTryAgainLater => '¡Ups! No hay recepcionista disponible en este momento. Inténtalo más tarde.';

  @override
  String get optional => '(Opcional)';

  @override
  String get otherDetails => 'Otros detalles';

  @override
  String get otp => 'Contraseña';

  @override
  String get otpFromAuthenticatorApp => 'OTP de la aplicación Authenticator';

  @override
  String get passwordDoesNotMeetRequirements => 'La contraseña no cumple con las reglas requeridas';

  @override
  String get passwordIsRequired => 'Se requiere contraseña';

  @override
  String get passwordMustIncludeAtLeastOneCapitalCharacter => 'La contraseña debe incluir al menos un carácter en mayúscula';

  @override
  String get passwordMustIncludeAtLeastOneLowercaseCharacter => 'La contraseña debe incluir al menos un carácter en minúscula';

  @override
  String get passwordMustIncludeAtLeastOneNumber => 'La contraseña debe incluir al menos un número';

  @override
  String get passwordMustIncludeSpacialCharacter => 'La contraseña debe incluir al menos un carácter especial';

  @override
  String get passwordTooShort => 'La contraseña debe tener al menos 8 caracteres.';

  @override
  String get photosAvaliable => 'Fotos disponibles';

  @override
  String get pleaseAcceptTermsAnd => 'Por favor acepte los términos y condiciones';

  @override
  String get pleaseEnterOTP => 'Por favor ingrese la OTP';

  @override
  String get pleaseEnterValid6digitOTP => 'Ingrese un OTP válido de 6 dígitos';

  @override
  String get pleaseEnterValidEmail => 'Por favor, introduzca un correo electrónico válido';

  @override
  String get privacyPolicyTerms => 'Política de privacidad, términos y condiciones';

  @override
  String get qualificationDetailIsNotAvilable => 'Los detalles de la calificación no están disponibles';

  @override
  String get readAll => 'Leer todo';

  @override
  String get reason => 'Razón';

  @override
  String get reply => 'Responder';

  @override
  String get selectMedicine => 'Seleccionar Medicina';

  @override
  String get serviceAvaliable => 'servicio disponible';

  @override
  String get sorryUserCannotSignin => 'Lo sentimos, el usuario no puede iniciar sesión.';

  @override
  String get stayTunedNoNew => '¡Estén atentos! No hay notificaciones nuevas.';

  @override
  String get thereIsNoMedicalReportsAvilableAtThisMoment => 'No hay informes médicos disponibles en este momento.';

  @override
  String get toResetYourNew => 'Para restablecer su nueva contraseña, ingrese su dirección de correo electrónico';

  @override
  String get totalCancellationFee => 'Tarifa total de cancelación';

  @override
  String get tryToAnotherWay => 'Inténtalo de otra manera';

  @override
  String get updateTo => 'Actualizar a';

  @override
  String get verify => 'Verificar';

  @override
  String get viewCommissions => 'Ver comisiones';

  @override
  String get wouldYouLikeToProceedAndConfirmPayment => '¿Desea continuar y confirmar el pago?';

  @override
  String get wouldYouLikeToSetProfilePhotoAs => '¿Quieres establecer esta foto como tu foto de perfil?';

  @override
  String get youCanNowLog => 'Ahora puedes iniciar sesión en tu nueva cuenta con tu nueva contraseña';

  @override
  String get yourBookingHasBeen => 'Su reserva se ha cancelado correctamente. El reembolso correspondiente se procesará en un plazo de 24 horas.';

  @override
  String get yourNewPasswordDoesnT => '¡Tu nueva contraseña no coincide! ¡Confirma tu contraseña!';

  @override
  String get yourNewPasswordMust => 'Su nueva contraseña debe ser diferente a su contraseña anterior';

  @override
  String get yourOldPasswordDoesnT => '¡Tu contraseña anterior no es correcta!';

  @override
  String get yourPasswordHasBeen => 'Su contraseña se ha restablecido correctamente';

  @override
  String get selectedFileShouldBeLessThan5MB => 'Por favor seleccione una imagen menor a 5 MB';

  @override
  String get dosage => 'Dosierung';

  @override
  String get form => 'Forma';

  @override
  String get viewAndManageTheListOfServicesYouProvide => 'Ver y administrar la lista de servicios que ofreces.';

  @override
  String get manageServices => 'Administrar servicios';

  @override
  String get supportedFormat => 'Formatos compatibles: jpg, jpeg, png, doc, docx, pdf';

  @override
  String get noFileSelected => 'noFileSelected';

  @override
  String get areYouSureYouWantToDeleteThisReceptionist => '¿Está seguro de que desea eliminar a este recepcionista?';

  @override
  String get open => 'Abierto';

  @override
  String get close => 'Cerca';
}
