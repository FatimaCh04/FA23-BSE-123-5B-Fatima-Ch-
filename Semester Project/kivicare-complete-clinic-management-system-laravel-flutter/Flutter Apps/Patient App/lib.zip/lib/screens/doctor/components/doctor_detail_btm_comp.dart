import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../../components/loader_widget.dart';
import '../../../main.dart';
import '../../../utils/colors.dart';
import '../../../utils/empty_error_state_widget.dart';
import '../../service/components/service_card.dart';
import '../doctor_detail_controller.dart';

class DoctorDetailBtmComp extends StatelessWidget {
  final DoctorDetailController doctorDetailCont;

  const DoctorDetailBtmComp({super.key, required this.doctorDetailCont});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          locale.value.services,
          style: boldTextStyle(size: 18),
        ),
        16.height,
        Obx(
          () => SnapHelperWidget(
            future: doctorDetailCont.serviceListFuture.value,
            errorBuilder: (error) {
              return NoDataWidget(
                title: error,
                retryText: locale.value.reload,
                imageWidget: const ErrorStateWidget(),
                onRetry: () {
                  doctorDetailCont.servicesPage(1);
                  doctorDetailCont.getServiceList();
                },
              ).paddingSymmetric(horizontal: 16);
            },
            loadingWidget: doctorDetailCont.isServicesLoading.value ? const Offstage() : const LoaderWidget(),
            onSuccess: (data) {
              if (doctorDetailCont.serviceList.isEmpty) {
                return NoDataWidget(
                  title: locale.value.noServicesFoundAtAMoment,
                  subTitle: locale.value.looksLikeThereIsNoServicesProvidedByThisDocto,
                  titleTextStyle: primaryTextStyle(),
                  imageWidget: const EmptyStateWidget(),
                  retryText: locale.value.reload,
                  onRetry: () {
                    doctorDetailCont.servicesPage(1);
                    doctorDetailCont.getServiceList();
                  },
                ).paddingSymmetric(horizontal: 16);
              }

              return AnimatedWrap(
                spacing: 16,
                runSpacing: 16,
                children: List.generate(
                  doctorDetailCont.serviceList.length,
                  (index) => ServiceCard(
                    serviceElement: doctorDetailCont.serviceList[index],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

