import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../api/core_apis.dart';
import '../category/model/category_list_model.dart';
import '../home/model/system_service_res.dart';

class SystemServiceListController extends GetxController {
  Rx<Future<RxList<SystemService>>> systemServiceListFuture = Future(() => RxList<SystemService>()).obs;
  RxBool isLoading = false.obs;
  RxList<SystemService> systemServiceList = RxList();
  RxBool isLastPage = false.obs;
  RxInt page = 1.obs;
  Rx<CategoryElement> category = CategoryElement().obs;

  ///Search
  TextEditingController searchCont = TextEditingController();
  RxBool isSearchText = false.obs;
  StreamController<String> searchStream = StreamController<String>();
  final scrollController = ScrollController();

  @override
  void onInit() {
    if (Get.arguments is CategoryElement) {
      category(Get.arguments);
    }
    getSystemServiceList();
    super.onInit();
  }

  Future<void> getSystemServiceList({bool showLoader = true}) async {
    if (showLoader) {
      isLoading(true);
    }
    await systemServiceListFuture(
      CoreServiceApis.getSystemService(
        page: page.value,
        systemServiceList: systemServiceList,
        categoryId: category.value.id,
        lastPageCallBack: (p0) {
          isLastPage(p0);
        },
      ),
    ).then((value) {
      log('value.length ==> ${value.length}');
    }).catchError((e) {
      isLoading(false);
      log('SystemServiceList getSystemServiceList err ==> $e');
    }).whenComplete(() => isLoading(false));
  }

  @override
  void onClose() {
    searchStream.close();
    page(1);
    searchCont.clear();
    if (Get.context != null) {
      scrollController.removeListener(() => hideKeyboard(Get.context));
    }
    super.onClose();
  }
}

