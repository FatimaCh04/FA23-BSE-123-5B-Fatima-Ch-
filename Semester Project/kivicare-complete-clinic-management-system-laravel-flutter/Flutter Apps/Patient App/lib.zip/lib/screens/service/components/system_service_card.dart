import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../../components/cached_image_widget.dart';
import '../../../utils/colors.dart';
import '../../home/model/system_service_res.dart';
import '../service_list_controller.dart';
// ServiceListScreen is imported from services_list_screen.dart
import 'package:kivicare_patient/screens/service/services_list_screen.dart';

class SystemServiceCard extends StatelessWidget {
  final SystemService systemServiceElement;

  const SystemServiceCard({super.key, required this.systemServiceElement});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.delete<ServiceListController>(force: true);
        Get.to(() => ServiceListScreen(), arguments: systemServiceElement);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: boxDecorationDefault(
          color: context.cardColor,
          borderRadius: radius(8),
        ),
        child: Row(
          children: [
            CachedImageWidget(
              url: systemServiceElement.systemServiceImage,
              height: 80,
              width: 80,
              fit: BoxFit.cover,
              topLeftRadius: 8,
              bottomLeftRadius: 8,
            ),
            16.width,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  systemServiceElement.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: boldTextStyle(size: 14),
                ),
                8.height,
                Text(
                  systemServiceElement.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: secondaryTextStyle(size: 12),
                ).visible(systemServiceElement.description.isNotEmpty),
                8.height,
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: boxDecorationDefault(
                    color: extraLightPrimaryColor,
                    borderRadius: radius(22),
                  ),
                  child: Text(
                    '${systemServiceElement.totalServices} Services',
                    style: boldTextStyle(size: 10, color: appColorPrimary),
                  ),
                ),
              ],
            ).expand(),
            16.width,
          ],
        ),
      ),
    );
  }
}

