class EncounterListRes {
  bool status;
  List<EncounterElement> data;
  String message;

  EncounterListRes({
    this.status = false,
    this.data = const <EncounterElement>[],
    this.message = "",
  });

  factory EncounterListRes.fromJson(Map<String, dynamic> json) {
    return EncounterListRes(
      status: json['status'] is bool ? json['status'] : false,
      data: json['data'] is List ? List<EncounterElement>.from(json['data'].map((x) => EncounterElement.fromJson(x))) : [],
      message: json['message'] is String ? json['message'] : "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'data': data.map((e) => e.toJson()).toList(),
      'message': message,
    };
  }
}

class EncounterElement {
  int id;
  int appointmentId;
  String doctorName;
  String clinicName;
  String encounterDate;
  bool status;
  int patientId;
  int doctorId;
  int clinicId;
  String description;
  int createdBy;
  int updatedBy;
  int deletedBy;
  String createdAt;
  String updatedAt;
  String deletedAt;

  EncounterElement({
    this.id = -1,
    this.appointmentId = -1,
    this.doctorName = "",
    this.clinicName = "",
    this.encounterDate = "",
    this.status = false,
    this.patientId = -1,
    this.doctorId = -1,
    this.clinicId = -1,
    this.description = "",
    this.createdBy = -1,
    this.updatedBy = -1,
    this.deletedBy = -1,
    this.createdAt = "",
    this.updatedAt = "",
    this.deletedAt = "",
  });

  factory EncounterElement.fromJson(Map<String, dynamic> json) {
    return EncounterElement(
      id: json['id'] is int ? json['id'] : -1,
      appointmentId: json['appointment_id'] is int ? json['appointment_id'] : -1,
      doctorName: json['doctor_name'] is String ? json['doctor_name'] : "",
      clinicName: json['clinic_name'] is String ? json['clinic_name'] : "",
      encounterDate: json['encounter_date'] is String ? json['encounter_date'] : "",
      status: json['status'] is bool ? json['status'] : json['status'] == 1,
      patientId: json['patient_id'] is int ? json['patient_id'] : -1,
      doctorId: json['doctor_id'] is int ? json['doctor_id'] : -1,
      clinicId: json['clinic_id'] is int ? json['clinic_id'] : -1,
      description: json['description'] is String ? json['description'] : "",
      createdBy: json['created_by'] is int ? json['created_by'] : -1,
      updatedBy: json['updated_by'] is int ? json['updated_by'] : -1,
      deletedBy: json['deleted_by'] is int ? json['deleted_by'] : -1,
      createdAt: json['created_at'] is String ? json['created_at'] : "",
      updatedAt: json['updated_at'] is String ? json['updated_at'] : "",
      deletedAt: json['deleted_at'] is String ? json['deleted_at'] : "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'appointment_id': appointmentId,
      'doctor_name': doctorName,
      'clinic_name': clinicName,
      'encounter_date': encounterDate,
      'status': status,
      'patient_id': patientId,
      'doctor_id': doctorId,
      'clinic_id': clinicId,
      'description': description,
      'created_by': createdBy,
      'updated_by': updatedBy,
      'deleted_by': deletedBy,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'deleted_at': deletedAt,
    };
  }
}

