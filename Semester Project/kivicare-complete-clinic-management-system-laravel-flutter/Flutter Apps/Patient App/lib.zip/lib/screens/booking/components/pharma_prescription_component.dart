import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import '../../../main.dart';
import '../../../utils/app_common.dart';
import '../../../utils/colors.dart';
import '../../../utils/view_all_label_component.dart';
import '../encounter_detail_controller.dart';
import '../model/encounter_detail_model.dart';

class PharmaPrescriptionComponent extends StatelessWidget {
  const PharmaPrescriptionComponent({
    super.key,
    required this.encounterDetailCont,
  });

  final EncounterDetailController encounterDetailCont;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        16.height,
        ViewAllLabel(label: locale.value.prescription, isShowAll: false).paddingOnly(left: 16, right: 8),
        AnimatedWrap(
          runSpacing: 8,
          itemCount: encounterDetailCont.encounterDetail.value.prescriptions.length,
          itemBuilder: (ctx, index) {
            final Prescriptions prescriptionsData = encounterDetailCont.encounterDetail.value.prescriptions[index];

            return Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: boxDecorationDefault(
                color: context.cardColor,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        prescriptionsData.medicine.name,
                        style: boldTextStyle(size: 14, color: isDarkMode.value ? null : darkGrayTextColor),
                      ).expand(),
                    ],
                  ),
                  16.height,
                  Divider(color: isDarkMode.value ? borderColor.withValues(alpha: 0.2) : context.dividerColor.withValues(alpha: 0.2), height: 1),
                  16.height,
                  Row(
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: 'Dosage: ',
                              style: primaryTextStyle(color: dividerColor, size: 12),
                            ),
                            TextSpan(
                              text: prescriptionsData.medicine.dosage,
                              style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                            ),
                          ],
                        ),
                      ).expand(),
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: 'Form: ',
                              style: primaryTextStyle(color: dividerColor, size: 12),
                            ),
                            TextSpan(
                              text: prescriptionsData.medicine.form.name,
                              style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                            ),
                          ],
                        ),
                      ).expand(),
                    ],
                  ),
                  8.height,
                  Row(
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: '${locale.value.quantity}: ',
                              style: primaryTextStyle(color: dividerColor, size: 12),
                            ),
                            TextSpan(
                              text: prescriptionsData.quantity.toString(),
                              style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                            ),
                          ],
                        ),
                      ).expand(),
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: '${locale.value.days}: ',
                              style: primaryTextStyle(color: dividerColor, size: 12),
                            ),
                            TextSpan(
                              text: prescriptionsData.duration,
                              style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                            ),
                          ],
                        ),
                      ).expand(),
                    ],
                  ),
                  8.height,
                  Row(
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: '${locale.value.frequency}: ',
                              style: primaryTextStyle(color: dividerColor, size: 12),
                            ),
                            TextSpan(
                              text: prescriptionsData.frequency,
                              style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                            ),
                          ],
                        ),
                      ).expand(),
                    ],
                  ),
                  8.height,
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: '${locale.value.instruction}: ',
                          style: primaryTextStyle(color: dividerColor, size: 12),
                        ),
                        TextSpan(
                          text: prescriptionsData.instruction,
                          style: secondaryTextStyle(size: 12, weight: FontWeight.w600, color: isDarkMode.value ? null : darkGrayTextColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ).paddingSymmetric(horizontal: 16);
          },
        ),
      ],
    );
  }
}
