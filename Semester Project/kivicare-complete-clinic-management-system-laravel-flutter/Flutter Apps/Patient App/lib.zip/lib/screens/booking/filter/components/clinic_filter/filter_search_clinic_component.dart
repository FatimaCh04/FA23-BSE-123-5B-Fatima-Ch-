import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../../../../main.dart';
import '../../../../../utils/colors.dart';
import '../../filter_controller.dart';

class FilterSearchClinicComponent extends StatelessWidget {
  final FilterController filterClinicController;
  final Function(String)? onFieldSubmitted;

  const FilterSearchClinicComponent({
    super.key,
    required this.filterClinicController,
    this.onFieldSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return AppTextField(
      controller: filterClinicController.searchClinicCont,
      textFieldType: TextFieldType.OTHER,
      decoration: InputDecoration(
        hintText: locale.value.searchHere,
        hintStyle: secondaryTextStyle(),
        prefixIcon: const Icon(Icons.search, color: iconColor, size: 20),
        filled: true,
        fillColor: context.cardColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: appColorPrimary, width: 1),
        ),
      ),
      onFieldSubmitted: onFieldSubmitted,
      onChanged: (value) {
        filterClinicController.searchClinicStream.add(value);
      },
    );
  }
}

